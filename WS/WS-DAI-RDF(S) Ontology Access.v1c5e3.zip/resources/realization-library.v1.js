// JavaScript Document

    var sectionCounter=0;
	  var subsectionCounter=0;
	  var subsubsectionCounter=0;
	  
	  var appendixCounter=-1;
    var letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";    
    function ndash() {
      return "&ndash;"
    }
	  
	  function xsdAppendix() {
	    appendixCounter++;
	    document.write("Appendix "+letters.substr(appendixCounter,1)+".1 "+ndash()+" ");
	  }
	  function wsdlAppendix() {
	    document.write("Appendix "+letters.substr(appendixCounter,1)+".2 "+ndash()+" ");
	  }
	  
	  function section() {
	    sectionCounter++;
		  subsectionCounter=0;
	    document.write(sectionCounter+". ");
	  }

	  function subsection() {
	    subsectionCounter++;
		  subsubsectionCounter=0;
	    document.write(sectionCounter+"."+subsectionCounter+". ");
	  }

	  function subsubsection() {
		  subsubsectionCounter++;
	    document.write(sectionCounter+"."+subsectionCounter+"."+subsubsectionCounter+". ");
	  }

    function property(path,summary) {
	    document.write("&lt;table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"&gt;");
	    document.write("&lt;tr&gt;");
	    document.write("&lt;td colspan=\"2\"&gt;"+path+"&lt;/td&gt;");
	    document.write("&lt;/tr&gt;");
	    document.write("&lt;tr&gt;");
	    document.write("&lt;td width=\"24pt\"&gt;&amp;nbsp;&lt;/td&gt;");
	    document.write("&lt;td&gt;"+summary+"&lt;/td&gt;");
	    document.write("&lt;/tr&gt;");
	    document.write("&lt;/table&gt;");
	  }
