#!/bin/sh

config="client.conf"
server="ng.example.org"
ng_services="iop/add_service iop/sleep_service iop/exit_service iop/loop_service"
gs_services="iop_add_service iop_sleep_service iop_exit_service iop_loop_service"

# ninf-g
./standard-test-ng $config $server $ng_services 2> ng.err

# gridsolve
#./standard-test-gs $config $server $gs_services 2> gs.err
