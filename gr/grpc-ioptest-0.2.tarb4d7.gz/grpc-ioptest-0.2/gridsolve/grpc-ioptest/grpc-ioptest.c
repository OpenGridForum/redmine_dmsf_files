#include <stdlib.h>
#include <unistd.h>

void iop_add_service(int x, int *y)
{
  x += 1;
  *y = x;
}

void iop_sleep_service(int x)
{
  sleep(x);
}

void iop_exit_service(int x)
{
  sleep(x);
  exit(1);
}

void iop_loop_service(int x)
{
  while (1) sleep(x);
}
