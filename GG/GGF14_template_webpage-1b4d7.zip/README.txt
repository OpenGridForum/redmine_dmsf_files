
Suggestions and guidelines for creating a GGF14 Area/Group summary page from the given template.  

- documents is a directory in which to put your materials.  documents directory is on the same level as your page.  It is suggested to create a seperate directory named after your Area/Group under the documents directory for material specific to your page.  Name any directory you create under the documents directory consistent with the name of your page.

- Header should be the name of your Area/Group prefixed by GGF14. (In the template it is set to GGF14)

- There are two stylesheet examples in the template, SubHeader and Content.  Please render your topic headers and content within these stylesheets.  

- Supplemental document names should begin with GGF14_ and end in _Speakername, ie. GGF14_ScienceGateways_Wilkins-Diehr.ppt

- Try and follow an "abstract" format but add the presentations near the top.

- Ensure links somewhere to speaker/organizer emails and major project URL's

- Add links if possible to the corresponding GGF groups

- Title is fixed to "Global Grid Forum" to be consistent with the rest of ggf.org .  Please do not change.
 
- All links, images and stylesheets are absolute in the template so they should show up in your browser while testing.

- Any questions, comments: kdrew@ggf.org