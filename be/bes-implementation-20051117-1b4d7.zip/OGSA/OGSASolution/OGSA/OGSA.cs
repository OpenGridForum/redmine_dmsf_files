using System;
using System.Collections;

using GBG.OGSA.OGSACommon.Client;
using GBG.OGSA.OGSACommon.Logging;
using GBG.OGSA.OGSACommon.Configuration;

namespace OGSA
{
	public class OGSA
	{
		static private Hashtable _COMMANDS;

		static OGSA()
		{
			_COMMANDS = new Hashtable();

			ITool tool;

			tool = new ContextSpaceTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new ContextLSTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new ContextPWDTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new ContextMkdirTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new FactoryConfigureTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new ContextCDTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new CPTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new LNTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new RMTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new CatTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new TreeTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new RByteIODebugTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new RunTool();
			_COMMANDS[tool.ToolName] = tool;
			tool = new CreateTool();
			_COMMANDS[tool.ToolName] = tool;
		}

		static public void Main(string []args)
		{
			int exitCode = 0;
			int lcv;
			bool debug = false;
			bool help = false;
			string command = null;

			for (lcv = 0; lcv < args.Length; lcv++)
			{
				if (args[lcv].Equals("--debug"))
				{
					debug = true;
				} 
				else if (args[lcv].Equals("--help"))
				{
					help = true;
				}
				else
				{
					command = args[lcv];
					break;
				}
			}

			if (help || (command == null))
			{
				if (command == null)
				{
					usage();
					exitCode = 0;
				} 
				else
				{
					ITool tool = (ITool)_COMMANDS[command];
					if (tool == null)
					{
						usage();
						exitCode = 1;
					} 
					else
					{
						usage(tool);
						exitCode = 0;
					}
				}
			} 
			else
			{
				ITool tool = (ITool)_COMMANDS[command];
				if (tool == null)
				{
					usage();
					exitCode = 1;
				} 
				else
				{
					try
					{
						tool.execute(new DefaultCommandLine(args, lcv+1), Console.In,
							Console.Out, Console.Error, createSessionManager(debug));
					}
					catch (ToolUsageException tue)
					{
						Console.Error.WriteLine(tue.Message);
						exitCode = 1;
					}
				}
			}

			Environment.Exit(exitCode);
		}

		static private ILogger createLogger(bool debug)
		{
			if (debug)
				return new LogLevelFilter(
					new DefaultLogger(new TextWriterDevice(Console.Out)), LogLevel.Debug);
			else
				return new LogLevelFilter(
					new DefaultLogger(new TextWriterDevice(Console.Out)), LogLevel.Warning);
		}

		static private IClientSessionManager createSessionManager(bool debug)
		{
			return new FileBasedClientSession(createLogger(debug));
		}

		static private void usage()
		{
			Console.Error.WriteLine("USAGE:  OGSA [--debug] [--help] <ogsa-command> <command-options>\n" +
				"\tWHERE <ogsa-command> is one of:");
			
			int lcv = 0;
			string []commands = new string[_COMMANDS.Keys.Count];
			foreach (string command in _COMMANDS.Keys)
			{
				commands[lcv++] = command;
			}

			Array.Sort(commands);

			foreach (string command in commands)
			{
				Console.Error.WriteLine("\t\t{0}", command);
			}
		}

		static private void usage(ITool tool)
		{
			Console.Error.WriteLine(tool.ToolHelp);
		}
	}
}