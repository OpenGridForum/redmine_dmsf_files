using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Logging;
using GBG.OGSA.OGSACommon.ByteIO;

namespace GBG.FTP
{
	public class FTPServer
	{
		static public void Main(string []args)
		{
			if (args.Length != 1)
			{
				Console.Error.WriteLine("USAGE:  GFTPServer <port>");
				Environment.Exit(1);
			}

			TcpListener listener = new TcpListener(IPAddress.Any, Int32.Parse(args[0]));
			listener.Start();
			while (true)
			{
				try
				{
					TcpClient client = listener.AcceptTcpClient();
					FTPSession session = new FTPSession(client);
					Thread th = new Thread(new ThreadStart(session.run));
					th.Start();
				}
				catch (Exception e)
				{
					Console.Error.WriteLine("Error:  {0}", e);
				}
			}
		}
	}
}