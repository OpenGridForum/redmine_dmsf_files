using System;

namespace GFTPServer
{
	/// <summary>
	/// Summary description for IFTPSession.
	/// </summary>
	public class IFTPSession
	{
		public IFTPSession()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
