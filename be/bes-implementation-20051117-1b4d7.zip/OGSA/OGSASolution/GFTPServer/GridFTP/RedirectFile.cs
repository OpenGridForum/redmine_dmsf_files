using System;
using System.IO;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.FTP.GridFTP
{
	public class RedirectFile
	{
		private MemoryStream _content;
		private StreamWriter _writer;

		public RedirectFile(EndpointReferenceType epr)
		{
			_content = new MemoryStream();
			_writer = new StreamWriter(_content);

			_writer.WriteLine("<HTML>");
			_writer.WriteLine("<HEAD>");
            _writer.WriteLine("<META HTTP-EQUIV=\"Refresh\"");
            _writer.WriteLine("CONTENT=\"0; URL={0}\">", epr.Address.Value);
			_writer.WriteLine("</HEAD>");
			_writer.WriteLine("<BODY>");
            _writer.WriteLine("If you are not automatically redirected, please click");
            _writer.WriteLine("<A HREF=\"{0}\"> here</A>", epr.Address.Value);
			_writer.WriteLine("</BODY>");
			_writer.WriteLine("</HTML>");

			_writer.Flush();
		}

		public long Size
		{
			get
			{
				return _content.Length;
			}
		}

		public MemoryStream Stream
		{
			get
			{
				return _content;
			}
		}
	}
}