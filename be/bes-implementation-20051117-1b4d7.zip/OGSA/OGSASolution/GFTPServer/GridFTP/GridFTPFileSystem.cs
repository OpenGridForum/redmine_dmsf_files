using System;

using GBG.FTP.IFTP;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;
using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Logging;

namespace GBG.FTP.GridFTP
{
	public class GridFTPFileSystem : IFTPFileSystem
	{
		static private ILogger createLogger(bool debug)
		{
			if (debug)
				return new LogLevelFilter(
					new DefaultLogger(new TextWriterDevice(Console.Out)), LogLevel.Debug);
			else
				return new LogLevelFilter(
					new DefaultLogger(new TextWriterDevice(Console.Out)), LogLevel.Warning);
		}

		static private IClientSessionManager createSessionManager(bool debug)
		{
			return new FileBasedClientSession(createLogger(debug));
		}

		private ContextPath _currentPath;

		public GridFTPFileSystem()
		{
			_currentPath = createSessionManager(false).Session.CurrentPath.lookup("/", true)[0];
		}

		#region IFTPFileSystem Members

		public string Greeting
		{
			get
			{
				return "Mark Morgan's Grid FTP Server.";
			}
		}

		public string pwd()
		{
			return _currentPath.FullPath;
		}

		public void cwd(string path)
		{
			ContextPath []paths = _currentPath.lookup(path, true);
			if (paths.Length != 1)
				throw new PathDoesNotExistException(path);

			_currentPath = paths[0];
		}

		public ListEntry[] list()
		{
			FilePermissions.RWXPerms rx = FilePermissions.RWXPerms.READ |
				FilePermissions.RWXPerms.EXECUTE;
			FilePermissions.RWXPerms rwx = FilePermissions.RWXPerms.READ |
				FilePermissions.RWXPerms.WRITE | FilePermissions.RWXPerms.EXECUTE;
			FilePermissions perms = new FilePermissions(rwx, rwx, rwx);

			ContextPath []paths = _currentPath.lookup("./*", true);
			ListEntry []ret = new ListEntry[paths.Length];
			for (int lcv = 0; lcv < paths.Length; lcv++)
			{
				RandomByteIOObject robj = (RandomByteIOObject)OGSAObject.attach(
					paths[lcv], ByteIOConstants._RBYTEIO_QNAME);
				if (robj.ImplementsDirectory)
					ret[lcv] = new ListEntry(paths[lcv].Name, DateTime.Now, 0, "mmm2a", "gbg",
						perms, 1, true);
				else if (robj.ImplementsFile)
					ret[lcv] = new ListEntry(paths[lcv].Name, robj.ModificationTime, robj.Size,
						"mmm2a", "gbg", perms, 1, false);
				else
				{
					RedirectFile rd = new RedirectFile(paths[lcv]);
					ret[lcv] = new ListEntry(string.Format("{0}.html", paths[lcv].Name),
						DateTime.Now, rd.Size, "mmm2a", "gbg", new FilePermissions(rx, rx, rx), 
						1, false);
				}
			}

			return ret;
		}

		public string mkdir(string newDir)
		{
			ContextPath newPath = _currentPath.mkdir(newDir, false);
			return newPath.FullPath;
		}

		public void removeDirectory(string dir)
		{
			ContextPath []paths = _currentPath.lookup(dir, true);
			if (paths.Length != 1)
				throw new PathDoesNotExistException(dir);

			paths[0].remove(true, true);
		}

		public bool authenticate(string user, string password)
		{
			if (password == null)
				return false;

			// TODO:  Add GridFTPFileSystem.authenticate implementation
			return true;
		}

		public void delete(string entry)
		{
			ContextPath []paths = _currentPath.lookup(entry, true);
			if (paths.Length != 1)
				throw new PathDoesNotExistException(entry);

			paths[0].remove(true, true);
		}

		public void rename(string oldEntry, string newEntry)
		{
			ContextPath []paths = _currentPath.lookup(oldEntry, true);
			if (paths.Length != 1)
				throw new PathDoesNotExistException(oldEntry);

			ContextPath []newPaths = _currentPath.lookup(newEntry, false);
			if (newPaths.Length != 1 || newPaths[0].Exists)
				throw new PathAlreadyExistsException(newEntry);

			paths[0].rename(newPaths[0]);
		}

		public void retrieve(string entry, System.IO.Stream outputStream)
		{
			ContextPath []paths = _currentPath.lookup(entry, true);
			if (paths.Length != 1)
			{
				if (entry.EndsWith(".html"))
					paths = _currentPath.lookup(entry.Substring(0, entry.Length - 5), true);
				if (paths.Length != 1)
					throw new PathDoesNotExistException(entry);
			}

			OGSAObject obj = new OGSAObject(paths[0]);

			System.IO.Stream inputStream = null;
			if (obj.ImplementsFile)
				inputStream = new RandomByteIOStream(paths[0], System.IO.FileMode.Open,
					System.IO.FileAccess.Read);
			else
			{
				RedirectFile rd = new RedirectFile(paths[0]);
				inputStream = rd.Stream;
				inputStream.Seek(0, System.IO.SeekOrigin.Begin);
			}

			try
			{
				byte []data = new byte[1024 * 1024];
				int read;
				while ( (read = inputStream.Read(data, 0, 1024 * 1024)) > 0)
				{
					outputStream.Write(data, 0, read);
				}
			}
			finally
			{
				inputStream.Close();
				outputStream.Flush();
			}
		}

		public void store(string entry, System.IO.Stream inputStream)
		{
			ContextPath []paths = _currentPath.lookup(entry, true);
			if (paths.Length != 1)
			{
				if (entry.EndsWith(".html"))
					paths = _currentPath.lookup(entry.Substring(0, entry.Length - 5), true);
			}

			if (paths.Length != 0)
			{
				OGSAObject obj = new OGSAObject(paths[0]);
				if (!obj.ImplementsFile)
					throw new FTPException("451 Path is not a file.");
			}

			paths = _currentPath.lookup(entry, false);
			if (paths.Length != 1)
				throw new FTPException("451 Unknown internal error.");

			using (System.IO.Stream outputStream = new RandomByteIOStream(paths[0], System.IO.FileMode.OpenOrCreate,
				System.IO.FileAccess.Write))
			{
				byte []data = new byte[1024 * 1024];
				int read;
				while ( (read = inputStream.Read(data, 0, 1024 * 1024)) > 0)
				{
					outputStream.Write(data, 0, read);
				}

				outputStream.Flush();
			}
		}

		public bool exists(string entry)
		{
			ContextPath []paths = _currentPath.lookup(entry, true);
			if (paths.Length != 1)
				return false;

			return true;
		}

		#endregion
	}
}