using System;

namespace GBG.FTP.IFTP
{
	public class PermissionDeniedException : FTPException
	{
		public PermissionDeniedException()
			: base(530, "Permission denied.")
		{
		}
	}
}
