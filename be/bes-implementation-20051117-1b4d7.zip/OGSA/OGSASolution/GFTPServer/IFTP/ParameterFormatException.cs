using System;

namespace GBG.FTP.IFTP
{
	public class ParameterFormatException : FTPException
	{
		public ParameterFormatException(string parameter)
			: base(501, string.Format("Format of parameter \"{0}\" is invalid.", parameter))
		{
		}
	}
}