using System;

using System.IO;

namespace GBG.FTP.IFTP
{
	public interface IFTPFileSystem
	{
		string Greeting { get; }

		string pwd();
		void cwd(string path);
		ListEntry[] list();
		string mkdir(string newDir);
		void removeDirectory(string dir);

		/// <summary>
		/// Authenticates (or doesn't) the user with the given password.  Password might be null
		/// </summary>
		/// <param name="user"></param>
		/// <param name="password"></param>
		/// <returns></returns>
		bool authenticate(string user, string password);

		void delete(string entry);
		void rename(string oldEntry, string newEntry);

		void retrieve(string entry, Stream outputStream);
		void store(string entry, Stream inputStream);

		bool exists(string entry);
	}
}