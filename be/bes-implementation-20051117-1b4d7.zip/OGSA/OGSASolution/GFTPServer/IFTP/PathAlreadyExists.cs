using System;

namespace GBG.FTP.IFTP
{
	public class PathAlreadyExistsException : FTPException
	{
		public PathAlreadyExistsException(string path)
			: base(550, string.Format("{0}: Path already exists.", path))
		{
		}
	}
}
