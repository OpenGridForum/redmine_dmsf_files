using System;
using System.IO;

namespace GBG.FTP.IFTP
{
	public class FTPException : Exception
	{
		private string []_ftpLines;

		public FTPException(string []ftpLines)
		{
			_ftpLines = ftpLines;
		}

		public FTPException(string line)
			: this(new string[] {line})
		{
		}

		public FTPException(int number, string line)
			: this(string.Format("{0} {1}", number, line))
		{
		}

		public void communicate(TextWriter writer)
		{
			foreach (string line in _ftpLines)
			{
				writer.WriteLine(line);
			}

			writer.Flush();
		}
	}
}