using System;

namespace GBG.FTP.IFTP
{
	public class PathDoesNotExistException : FTPException
	{
		public PathDoesNotExistException(string path)
			: base(550, string.Format("{0}: No such file or directory.", path))
		{
		}
	}
}