using System;

namespace GBG.FTP.IFTP
{
	public class ListEntry
	{
		private bool _isDirectory;
		private int _hardLinkCount;
		private FilePermissions _permissions;
		private string _user;
		private string _group;
		private long _size;
		private DateTime _lastMod;
		private string _name;

		public ListEntry(string name, DateTime lastMod, long size,
			string user, string group, FilePermissions permissions, int hardLinkCount,
			bool isDirectory)
		{
			_isDirectory = isDirectory;
			_hardLinkCount = hardLinkCount;
			_permissions = permissions;
			_user = user;
			_group = group;
			_size = size;
			_lastMod = lastMod;
			_name = name;
		}

		public override string ToString()
		{
			return string.Format("{0}{1} {2} {3} {4} {5} {6} {7}",
				(_isDirectory ? "d" : "-"),
				_permissions, _hardLinkCount, _user, _group, _size,
				(((DateTime.Now - _lastMod) < (new TimeSpan(180, 0, 0, 0))) ?
				_lastMod.ToString(@"MMM\ d\ HH\:mm") : _lastMod.ToString(@"MMM\ d\ yyyy")),
				_name);
		}
	}
}