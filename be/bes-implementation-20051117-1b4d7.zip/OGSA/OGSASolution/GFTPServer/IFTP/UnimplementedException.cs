using System;

namespace GBG.FTP.IFTP
{
	public class UnimplementedException : FTPException
	{
		public UnimplementedException(string verb)
			: base(502, string.Format("The verb \"{0}\" is unimplemented.", verb))
		{
		}

		public UnimplementedException(string verb, string parameterName)
			: base(504, string.Format("The verb \"{0}\" with parameter \"{1}\" is unimplemented.",
				verb, parameterName))
		{
		}
	}
}