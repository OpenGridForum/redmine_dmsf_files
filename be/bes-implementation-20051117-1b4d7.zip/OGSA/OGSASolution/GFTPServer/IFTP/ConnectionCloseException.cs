using System;

namespace GBG.FTP.IFTP
{
	public class ConnectionCloseException : FTPException
	{
		public ConnectionCloseException()
			: base(400, "The server is about to close the connection.")
		{
		}
	}
}
