using System;

namespace GBG.FTP.IFTP
{
	public class InternalParseException : FTPException
	{
		public InternalParseException(string msg)
			: base(500, msg)
		{
		}
	}
}