using System;

namespace GBG.FTP.IFTP
{
	public class FilePermissions
	{
		[Flags]
		public enum RWXPerms
		{
			EXECUTE = 0x1,
			WRITE = 0x2,
			READ = 0x4
		}

		public enum UserGroupOther
		{
			USER = 0,
			GROUP = 1,
			OTHER = 2
		}

		private RWXPerms _userPerms;
		private RWXPerms _groupPerms;
		private RWXPerms _otherPerms;

		public FilePermissions(RWXPerms userPerms,
			RWXPerms groupPerms, RWXPerms otherPerms)
		{
			_userPerms = userPerms;
			_groupPerms = groupPerms;
			_otherPerms = otherPerms;
		}

		public string ToString(RWXPerms perms)
		{
			return string.Format("{0}{1}{2}",
				(((perms & RWXPerms.READ) > 0) ? "r" : "-"),
				(((perms & RWXPerms.WRITE) > 0) ? "w" : "-"),
				(((perms & RWXPerms.EXECUTE) > 0) ? "x" : "-"));
		}

		public override string ToString()
		{
			return string.Format("{0}{1}{2}", ToString(_userPerms),
				ToString(_groupPerms), ToString(_otherPerms));
		}
	}
}