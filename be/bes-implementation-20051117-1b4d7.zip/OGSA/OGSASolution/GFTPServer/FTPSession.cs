using System;

using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;

using GBG.FTP.IFTP;
using GBG.FTP.GridFTP;

namespace GBG.FTP
{
	public class FTPSession : IDisposable
	{
		private string _renameFrom = null;
		private string _user = null;

		private bool _disposed = false;
		private TcpClient _client;
		private NetworkStream _stream;
		private StreamReader _reader;
		private StreamWriter _writer;
		private IFTPFileSystem _fileSystem;

		private TcpListener _dataListener = null;
		private TcpClient _dataClient = null;

		public FTPSession(TcpClient client)
		{
			_client = client;
			_fileSystem = new GridFTPFileSystem();
		}

		~FTPSession()
		{
			Dispose();
		}

		public void run()
		{
			string line;
			Regex verbExtractor = new Regex(@"\s*(?<verb>[a-zA-Z0-9]+)\s*(?<parameters>.*)");

			Console.Out.WriteLine("New session running.");
			_stream = _client.GetStream();
			_reader = new StreamReader(_stream);
			_writer = new StreamWriter(_stream);

			_writer.WriteLine("220 {0}", _fileSystem.Greeting);
			_writer.Flush();

			while ( (line = _reader.ReadLine()) != null)
			{
				Console.Out.WriteLine("Read \"{0}\".", line);
				Match m = verbExtractor.Match(line);
	
				try
				{
					switch (m.Groups["verb"].Value)
					{
						case "USER" :
							user(m.Groups["parameters"].Value);
							break;

						case "PASS" :
							pass(m.Groups["parameters"].Value);
							break;

						case "PWD" :
							pwd();
							break;

						case "TYPE" :
							type(m.Groups["parameters"].Value);
							break;

						case "CWD" :
						case "XCWD" :
							cwd(m.Groups["parameters"].Value);
							break;

						case "PASV" :
							pasv();
							break;

						case "LIST" :
							list();
							break;

						case "RETR" :
							retrieve(m.Groups["parameters"].Value);
							break;

						case "RMD" :
							rmdir(m.Groups["parameters"].Value);
							break;

						case "DELE" :
							delete(m.Groups["parameters"].Value);
							break;

						case "STOR" :
							store(m.Groups["parameters"].Value);
							break;

						case "RNFR" :
							renameFrom(m.Groups["parameters"].Value);
							break;

						case "RNTO" :
							renameTo(m.Groups["parameters"].Value);
							break;

						case "MKD" :
							mkdir(m.Groups["parameters"].Value);
							break;

						default :
							throw new UnimplementedException(m.Groups["verb"].Value);
					}
				}
				catch (FTPException ftpe)
				{
					ftpe.communicate(Console.Error);
					ftpe.communicate(_writer);
				}
			}
		}

		#region IDisposable Members

		public void Dispose()
		{
			lock(this)
			{
				if (_disposed)
					return;
				_disposed = true;
			}

			GC.SuppressFinalize(this);

			if (_stream != null)
			{
				try
				{
					_stream.Close();
				}
				catch (Exception)
				{
				}
			}

			if (_client != null)
			{
				try
				{
					_client.Close();
				}
				catch (Exception)
				{
				}
			}
		}

		#endregion

		private void user(string username)
		{
			_user = username;
			if (_fileSystem.authenticate(_user, null))
				_writer.WriteLine("230 User {0} OK.", _user);
			else
				_writer.WriteLine("331 Need a password for user {0}", _user);
			_writer.Flush();
		}

		private void pass(string passwd)
		{
			// Codes
			// 230 means good user and pass
			// 202, meaning that permission was already granted in response to USER
			// 332, meaning that permission might be granted after an ACCT request. 
			// 503 means reject becase previous request not a user.
			// 530 if this username and password are jointly unacceptable.

			if (_user == null)
				_writer.WriteLine("503 No user given.");
			else
			{
				if (_fileSystem.authenticate(_user, passwd))
					_writer.WriteLine("230 Authenticated.");
				else
					_writer.WriteLine("530 Couldn't authenticate user.");
			}

			_writer.Flush();
		}

		private void pwd()
		{
			_writer.WriteLine("257 \"{0}\"", _fileSystem.pwd());
			_writer.Flush();
		}

		private void cwd(string path)
		{
			_fileSystem.cwd(path);
			_writer.WriteLine("250 OK");
			_writer.Flush();
		}

		private void type(string param)
		{
			if (param.Equals("A") || param.Equals("A N"))
			{
				_writer.WriteLine("200 OK");
				_writer.Flush();
			} 
			else if (param.Equals("I") || param.Equals("L 8"))
			{
				_writer.WriteLine("200 OK");
				_writer.Flush();
			} else
				throw new UnimplementedException("TYPE", "type");
		}

		private void pasv()
		{
			if (_dataClient != null)
				_dataClient.Close();

			if (_dataListener != null)
				_dataListener.Stop();

			_dataListener = new TcpListener(IPAddress.Any, 0);
			_dataListener.Start();

			byte []ip = getGlobalAddress().GetAddressBytes();
			IPEndPoint endpoint = (IPEndPoint)_dataListener.LocalEndpoint;
			string response = string.Format("227 ={0},{1},{2},{3},{4},{5}",
				ip[0], ip[1], ip[2], ip[3], endpoint.Port / 256, endpoint.Port % 256);
			
			Console.WriteLine("Opened up port -- responding with \"{0}\".", response);
			
			_writer.WriteLine(response);
			_writer.Flush();

			_dataClient = _dataListener.AcceptTcpClient();
		}

		private IPAddress getGlobalAddress()
		{
			IPHostEntry entry = Dns.Resolve(Dns.GetHostName());

			foreach (IPAddress addr in entry.AddressList)
			{
				if (addr.Equals(IPAddress.Loopback))
					continue;

				return addr;
			}

			return entry.AddressList[0];
		}

		private void list()
		{
			if (_dataClient == null)
				throw new FTPException(425, "Data connection not established.");

			_writer.WriteLine("150 Beginning Directory Listing.");
			_writer.Flush();

			try
			{
				ListEntry []entries = _fileSystem.list();
				using (StreamWriter writer = new StreamWriter(_dataClient.GetStream()))
				{
					foreach (ListEntry entry in entries)
					{
						Console.WriteLine("Returning \"{0}\".", entry);
						writer.WriteLine("{0}", entry);
					}
					writer.Flush();
				}

				_writer.WriteLine("226 Listing complete.");
				_writer.Flush();
			}
			catch (FTPException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FTPException(451, e.Message);
			}
			finally
			{
				_dataClient.Close();
				_dataClient = null;
				_dataListener.Stop();
				_dataListener = null;
			}
		}

		private void retrieve(string path)
		{
			if (_dataClient == null)
				throw new FTPException(425, "Data connection not established.");

			_writer.WriteLine("150 Beginning to retrieve file.");
			_writer.Flush();

			try
			{
				using (Stream stream = _dataClient.GetStream())
				{
					_fileSystem.retrieve(path, stream);
					stream.Flush();
				}

				_writer.WriteLine("226 File transferred.");
				_writer.Flush();
			}
			catch (FTPException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FTPException(451, e.Message);
			}
			finally
			{
				_dataClient.Close();
				_dataClient = null;
				_dataListener.Stop();
				_dataListener = null;
			}
		}

		private void rmdir(string path)
		{
			_fileSystem.removeDirectory(path);
			_writer.WriteLine("250 Removed.");
			_writer.Flush();
		}

		private void delete(string path)
		{
			_fileSystem.delete(path);
			_writer.WriteLine("250 Removed.");
			_writer.Flush();
		}

		private void store(string path)
		{
			if (_dataClient == null)
				throw new FTPException(425, "Data connection not established.");

			_writer.WriteLine("150 Beginning to store file.");
			_writer.Flush();

			try
			{
				using (Stream stream = _dataClient.GetStream())
				{
					_fileSystem.store(path, stream);
					stream.Flush();
				}

				_writer.WriteLine("226 File transferred.");
				_writer.Flush();
			}
			catch (FTPException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FTPException(451, e.Message);
			}
			finally
			{
				_dataClient.Close();
				_dataClient = null;
				_dataListener.Stop();
				_dataListener = null;
			}
		}

		private void renameFrom(string from)
		{
			if (_fileSystem.exists(from))
			{
				_writer.WriteLine("350 OK");
				_renameFrom = from;
			}
			else
				throw new PathDoesNotExistException(from);
			_writer.Flush();
		}

		private void renameTo(string entry)
		{
			if (_renameFrom == null)
			{
				_writer.WriteLine("503 Must have RNFR first.");
				_writer.Flush();
				return;
			}

			_fileSystem.rename(_renameFrom, entry);
			_writer.WriteLine("250 OK");
			_writer.Flush();
		}

		private void mkdir(string dir)
		{
			string newPath = _fileSystem.mkdir(dir);
			_writer.WriteLine("257 \"{0}\"", newPath);
			_writer.Flush();
		}
	}
}