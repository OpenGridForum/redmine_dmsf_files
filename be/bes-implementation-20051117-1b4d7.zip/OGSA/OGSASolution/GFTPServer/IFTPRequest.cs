using System;

namespace GFTPServer
{
	public interface IFTPRequest
	{
		string Verb { get; }

		void handle(string parameters);
	}
}