using System;

namespace GBG.FTP.FtpStreams
{
	public class FtpException : Exception
	{
		private ResponseLine []_responses = null;

		public FtpException(string msg)
			: base(msg)
		{
		}

		public FtpException(string msg, ResponseLine []responses)
			: base(msg)
		{
			_responses = responses;
		}

		public FtpException(string msg, Exception cause)
			: base(msg, cause)
		{
		}

		public override string ToString()
		{
			string ret = base.ToString();

			if (_responses != null)
			{
				foreach (ResponseLine line in _responses)
				{
					ret += string.Format("\n{0}", line);
				}
			}

			return ret;
		}

		public ResponseLine[] Responses
		{
			get
			{
				return _responses;
			}
		}
	}
}