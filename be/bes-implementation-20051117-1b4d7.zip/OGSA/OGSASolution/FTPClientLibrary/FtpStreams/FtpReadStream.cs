using System;

using System.IO;

namespace GBG.FTP.FtpStreams
{
	public class FtpReadStream : FtpBaseStream
	{
		public FtpReadStream(Uri connectString)
			: base(connectString)
		{
		}

		public override bool CanRead
		{
			get
			{
				return true;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}

		protected override string CommandName
		{
			get
			{
				return "RETR";
			}
		}
	}
}