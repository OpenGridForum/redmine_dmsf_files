using System;

using System.Collections;

using System.IO;

using System.Net;
using System.Net.Sockets;

using System.Text.RegularExpressions;

namespace GBG.FTP.FtpStreams
{
	public abstract class FtpBaseStream  : Stream
	{
		static private Regex _USER_REGEX = new Regex(@"(?<username>[^:]+)(:(?<password>.+))?");
		static private Regex _PASSIVE_RESPONSE_PARSER = new Regex(
			@"\D+(?<h1>\d+)\D(?<h2>\d+)\D(?<h3>\d+)\D(?<h4>\d+)\D(?<p1>\d+)\D(?<p2>\d+).*");

		private string _hostName;
		private int _port;
		private string _user;
		private string _password;
		private string _path;
		private string _dir;
		private string _file;

		private TcpClient _commandClient = null;
		private Stream _commandStream = null;

		private TextReader _commandReader = null;
		private TextWriter _commandWriter = null;

		private TcpClient _dataClient = null;
		private Stream _dataStream = null;

		protected FtpBaseStream(Uri connectURI)
		{
			_hostName = connectURI.Host;
			_path = connectURI.LocalPath;
			_dir = Path.GetDirectoryName(_path).Replace('\\', '/').Substring(1);
			_file = Path.GetFileName(_path);
			_port = connectURI.Port;

			Match m = _USER_REGEX.Match(connectURI.UserInfo);
			if (!m.Success)
				_user = _password = null;
			else
			{
				_user = m.Groups["username"].Value;
				_password = m.Groups["password"].Value;
			}

			if (_user == null || _user.Length == 0)
				_user = "anonymous";
			if (_password != null && _password.Length == 0)
				_password = null;

			_commandClient = new TcpClient(_hostName, _port);
			_commandStream = _commandClient.GetStream();

			_commandReader = new StreamReader(_commandStream);
			_commandWriter = new StreamWriter(_commandStream);

			acceptGreeting();
			authenticate();
			setBinaryType();
			changeDirectory();

			setupTransfer();
		}

		private ResponseLine[] receiveResponses()
		{
			string lineText;
			ResponseLine line;

			ArrayList aList = new ArrayList();

			while (true)
			{
				lineText = _commandReader.ReadLine();
				if (lineText == null)
					return null;

				line = new ResponseLine(lineText);
				aList.Add(line);

				if (line.ResponseCode >= 0)
					break;
			}

			ResponseLine []ret = new ResponseLine[aList.Count];
			aList.CopyTo(ret);

			return ret;
		}

		protected abstract string CommandName { get; }

		private void setupTransfer()
		{
			try
			{
				startPasv();
				_commandWriter.WriteLine("{0} {1}", CommandName, _file);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 150 :
						break;

					case 425 :
					case 426 :
						throw new FtpException("Client close the connection too early.", responses);

					case 450 :
					case 451 :
					case 452 :
					case 551 :
					case 552 :
						throw new FtpException(
							"Server had trouble reading/storing the remote file.", responses);

					default :
						throw new FtpException("Unable to read/store remote file.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to transfer files.", e);
			}
		}

		private void acceptGreeting()
		{
			try
			{
				ResponseLine []lines = receiveResponses();
				if (lines == null)
					throw new FtpException("Server didn't send reasonable greeting.");

				switch (lines[lines.Length - 1].ResponseCode)
				{
					case 220 :
						return;

					case 421 :
						throw new FtpException("Server denied request.", lines);

					default :
						throw new FtpException("Server sent back unrecognized response.", lines);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to handshake with server.", e);
			}
		}

		private void authenticate()
		{
			try
			{
				_commandWriter.WriteLine("USER {0}", _user);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 230 :
						return;

					case 331 :
					case 332 :
						if (_password == null)
							throw new FtpException("Unable to authenticate with server.");

						sendPassword();
						break;

					default :
						throw new FtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to authenticate with server.", e);
			}
		}

		private void sendPassword()
		{
			try
			{
				_commandWriter.WriteLine("PASS {0}", _password);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 230 :
					case 202 :
						return;

					case 332 :
					case 503 :
					case 530 :
						throw new FtpException("Server rejected user name and password.", responses);
					default :
						throw new FtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to authenticate with server.", e);
			}
		}

		private void setBinaryType()
		{
			try
			{
				_commandWriter.WriteLine("TYPE I");
				_commandWriter.Flush();
			
				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 200 :
						return;

					default :
						throw new FtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to change transfer type.", e);
			}
		}

		private void changeDirectory()
		{
			try
			{
				_commandWriter.WriteLine("CWD {0}", _dir);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 200 :
					case 250 :
						return;

					case 550 :
						throw new FtpException("Server rejected cwd request.", responses);

					default :
						throw new FtpException("Server set back unrecognized response.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to change current working directory.", e);
			}
		}

		private void startPasv()
		{
			try
			{
				if (_dataStream != null)
					_dataStream.Close();
				if (_dataClient != null)
					_dataClient.Close();

				_commandWriter.WriteLine("PASV");
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 227 :
						Match m = _PASSIVE_RESPONSE_PARSER.Match(
							responses[responses.Length - 1].ResponseText);
						if (!m.Success)
							throw new FtpException("Server sent back an unparseable response.",
								responses);

						string ipaddr = string.Format("{0}.{1}.{2}.{3}",
							m.Groups["h1"].Value, m.Groups["h2"].Value,
							m.Groups["h3"].Value, m.Groups["h4"].Value);
						int port = Int32.Parse(m.Groups["p1"].Value) * 256 +
							Int32.Parse(m.Groups["p2"].Value);

						_dataClient = new TcpClient(ipaddr, port);
						_dataStream = _dataClient.GetStream();
						return;

					default :
						throw new FtpException("Server sent back an uncrecognized response.", responses);
				}
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to create passive connection.", e);
			}
		}

		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		public override void Close()
		{
			try
			{
				if (_dataStream != null)
					_dataStream.Close();

				if (_dataClient != null)
					_dataClient.Close();

				ResponseLine []responses = receiveResponses();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 226 :
						break;

					case 425 :
					case 426 :
						throw new FtpException("Client closed the connection too early.", responses);

					case 450 :
					case 451 :
					case 452 :
					case 551 :
					case 552 :
						throw new FtpException(
							"Server had trouble reading/storing the remote file.", responses);

					default :
						throw new FtpException("Unable to read/store remote file.", responses);
				}

				if (_commandStream != null)
					_commandStream = null;

				if (_commandClient != null)
					_commandClient.Close();
			}
			catch (FtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new FtpException("Unable to finish ftp transfer.", e);
			}
		}

		public override void Flush()
		{
			_dataStream.Flush();
		}

		public override long Length
		{
			get
			{
				return _dataStream.Length;
			}
		}

		public override long Position
		{
			get
			{
				return _dataStream.Position;
			}

			set
			{
				_dataStream.Position = value;
			}
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			return _dataStream.Read(buffer, offset, count);
		}

		public override int ReadByte()
		{
			return _dataStream.ReadByte();
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			return _dataStream.Seek(offset, origin);
		}

		public override void SetLength(long value)
		{
			_dataStream.SetLength(value);
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			_dataStream.Write(buffer, offset, count);
		}

		public override void WriteByte(byte value)
		{
			_dataStream.WriteByte(value);
		}
	}
}