using System;

using System.IO;

namespace GBG.FTP.FtpStreams
{
	public class FtpWriteStream : FtpBaseStream
	{
		public FtpWriteStream(Uri connectString)
			: base(connectString)
		{
		}

		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return true;
			}
		}

		protected override string CommandName
		{
			get
			{
				return "STOR";
			}
		}
	}
}