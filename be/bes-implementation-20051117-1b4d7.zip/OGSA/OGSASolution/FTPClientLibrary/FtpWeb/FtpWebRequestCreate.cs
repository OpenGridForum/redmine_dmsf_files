using System;

using System.Net;

namespace GBG.FTP.FtpWeb
{
	public class FtpWebRequestCreate : IWebRequestCreate
	{
		#region IWebRequestCreate Members

		public WebRequest Create(Uri uri)
		{
			return new FtpWebRequest(uri);
		}

		#endregion
	}
}