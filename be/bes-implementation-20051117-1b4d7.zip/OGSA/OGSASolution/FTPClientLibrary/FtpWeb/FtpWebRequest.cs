using System;

using System.IO;
using System.Net;

using GBG.FTP.FtpStreams;

namespace GBG.FTP.FtpWeb
{
	public class FtpWebRequest : WebRequest
	{
		private Uri _request;

		public FtpWebRequest(Uri request)
		{
			_request = request;
		}

		public override Uri RequestUri
		{
			get
			{
				return _request;
			}
		}

		public override Stream GetRequestStream()
		{
			return new FtpWriteStream(_request);
		}

		public override WebResponse GetResponse()
		{
			return new FtpWebResponse(_request);
		}
	}
}