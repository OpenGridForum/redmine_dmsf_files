using System;

using System.IO;
using System.Net;

using GBG.FTP.FtpStreams;

namespace GBG.FTP.FtpWeb
{
	public class FtpWebResponse : WebResponse
	{
		private Uri _responseURI;

		public FtpWebResponse(Uri responseURI)
		{
			_responseURI = responseURI;
		}

		public override Stream GetResponseStream()
		{
			return new FtpReadStream(_responseURI);
		}

		public override Uri ResponseUri
		{
			get
			{
				return _responseURI;
			}
		}

		public override void Close()
		{
		}
	}
}