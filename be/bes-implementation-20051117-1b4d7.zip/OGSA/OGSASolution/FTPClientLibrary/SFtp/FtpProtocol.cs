using System;
using System.Collections;

using System.IO;

using System.Net;
using System.Net.Sockets;

using System.Text.RegularExpressions;

namespace GBG.FTP.SFtp
{
	public class FtpProtocol
	{
		private TextWriter _logger;
		private TextReader _commandReader;
		private TextWriter _commandWriter;

		private ResponseLine[] receiveResponse()
		{
			string lineText;
			ResponseLine line;

			ArrayList aList = new ArrayList();

			while (true)
			{
				lineText = _commandReader.ReadLine();
				if (lineText == null)
					return null;

				line = new ResponseLine(lineText);
				aList.Add(line);

				_logger.WriteLine(lineText);

				if (line.ResponseCode >= 0)
					break;
			}

			ResponseLine []ret = new ResponseLine[aList.Count];
			aList.CopyTo(ret);

			return ret;
		}

		public FtpProtocol(TextReader commandReader, TextWriter commandWriter, TextWriter logger)
		{
			_logger = logger;
			_commandReader = commandReader;
			_commandWriter = commandWriter;
		}

		public void acceptGreeting()
		{
			try
			{
				_logger.WriteLine("Connecting to FTP server.");

				ResponseLine []lines = receiveResponse();
				if (lines == null)
					throw new SFtpException("Server didn't send reasonable greeting.");

				switch (lines[lines.Length - 1].ResponseCode)
				{
					case 220 :
						return;
					case 421 :
						throw new SFtpException("Server denied request.", lines);
					default :
						throw new SFtpException("Server sent back unrecognized response.", lines);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to handshake with server.", e);
			}
		}

		public void authenticate(string user, SFtp.AuthenticationDelegate authHandler)
		{
			try
			{
				_logger.WriteLine("Sending user name \"{0}\".", user);
				_commandWriter.WriteLine("USER {0}", user);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 230 :
						_logger.WriteLine("Server accepted user name.");
						return;
					case 331 :
					case 332 :
						sendPassword(user, authHandler);
						break;
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to authenticate with server.", e);
			}
		}

		public void type(SFtp.TransferTypes transType)
		{
			string command = string.Format("TYPE {0}",
				(transType == SFtp.TransferTypes.BINARY) ? "I" : "A");

			try
			{
				_logger.WriteLine("Changing transfer type to {0}", transType);
				_commandWriter.WriteLine(command);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 200:
						_logger.WriteLine("Server accepted type change.");
						return;
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to change transfer type.", e);
			}
		}

		static private Regex _pwdResponseParser = new Regex("\"(?<path>[^\"]*)\"");
		public string pwd()
		{
			try
			{
				_logger.WriteLine("Getting current working directory.");
				_commandWriter.WriteLine("PWD");
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 257:
						_logger.WriteLine("Server responded with {0}.",
							responses[responses.Length - 1].ResponseText);
						Match m = _pwdResponseParser.Match(
							responses[responses.Length - 1].ResponseText);
						if (!m.Success)
							throw new SFtpException("Server sent back an unrecognized response.",
								responses);

						return m.Groups["path"].Value;
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to get current working directory.", e);
			}
		}

		public void cwd(string newPath)
		{
			try
			{
				_logger.WriteLine("Changing current working directory to \"{0}\".", newPath);
				_commandWriter.WriteLine("CWD {0}", newPath);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 200 :
					case 250 :
						_logger.WriteLine("Server changed the directory.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 550 :
						throw new SFtpException("Server rejected cwd request.");
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to change current working directory.", e);
			}
		}

		public void mkdir(string path)
		{
			try
			{
				_logger.WriteLine("Making a new directory.");
				_commandWriter.WriteLine("MKD {0}", path);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 250 :
					case 257 :
						_logger.WriteLine("Server made the directory.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 550 :
						throw new SFtpException("Server rejected mkdir request.");

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to make the new directory.", e);
			}
		}

		public void rmdir(string path)
		{
			try
			{
				_logger.WriteLine("Removing a directory.");
				_commandWriter.WriteLine("RMD {0}", path);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 250 :
					case 257 :
						_logger.WriteLine("Server removed the directory.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 550 :
						throw new SFtpException("Server rejected rmdir request.");

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to remove the directory.", e);
			}
		}

		public void delete(string path)
		{
			try
			{
				_logger.WriteLine("Deleting a file.");
				_commandWriter.WriteLine("DELE {0}", path);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 250 :
						_logger.WriteLine("Server removed the file.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 450 :
					case 550 :
						throw new SFtpException("Server rejected delete request.");

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to remove the file.", e);
			}
		}

		public void rename(string source, string target)
		{
			try
			{
				_logger.WriteLine("Renaming a file.");
				_commandWriter.WriteLine("RNFR {0}", source);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 350 :
						_logger.WriteLine("Server accepted the RNFR command.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 450 :
					case 550 :
						throw new SFtpException("Server rejected RNFR request.");

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}

				_commandWriter.WriteLine("RNTO {0}", target);
				_commandWriter.Flush();

				responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 250 :
						_logger.WriteLine("Server accepted the RNTO command.",
							responses[responses.Length - 1].ResponseText);
						break;

					case 503 :
					case 550 :
					case 553 :
						throw new SFtpException("Server rejected RNTO request.");

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}

			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to rename the file.", e);
			}
		}

		public void download(string sourceFile, Stream targetStream)
		{
			ResponseLine []responses;

			try
			{
				using (TcpClient client = startPasv())
				{
					Stream cliStream = client.GetStream();

					_logger.WriteLine("Getting file.");

					_commandWriter.WriteLine("RETR {0}", sourceFile);
					_commandWriter.Flush();

					responses = receiveResponse();
					switch (responses[responses.Length - 1].ResponseCode)
					{
						case 150 :
							_logger.WriteLine("Read a mark -- have to read some more.");
							break;

						case 425 :
						case 426 :
							throw new SFtpException("Client closed the connection too early.", responses);

						case 450 :
						case 451 :
						case 550 :
						case 551 :
							throw new SFtpException("Server had trouble reading the remote file.", 
								responses);

						default :
							throw new SFtpException("Server sent back unrecognized response.", responses);
					}

					transfer(cliStream, targetStream);
				}

				responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 226 :
						_logger.WriteLine("Read all of the contents.");
						return;

					case 425 :
					case 426 :
						throw new SFtpException("Client closed the connection too early.", responses);

					case 451 :
					case 551 :
						throw new SFtpException("Server had trouble reading the remote file.", 
							responses);

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to read file contents.", e);
			}
		}

		private void transfer(Stream source, Stream target)
		{
			byte []buffer = new byte[1024 * 4];
			int read;

			while ( (read = source.Read(buffer, 0, 1024 * 4)) > 0)
			{
				target.Write(buffer, 0, read);
			}
		}

		public void upload(Stream sourceStream, string targetFile)
		{
			ResponseLine []responses;
			try
			{
				using (TcpClient client = startPasv())
				{
					Stream cliStream = client.GetStream();

					_logger.WriteLine("Storing file.");

					_commandWriter.WriteLine("STOR {0}", targetFile);
					_commandWriter.Flush();

					responses = receiveResponse();
					switch (responses[responses.Length - 1].ResponseCode)
					{
						case 150 :
							_logger.WriteLine("Read a mark -- have to read some more.");
							break;

						case 425 :
						case 426 :
							throw new SFtpException("Client closed the connection too early.", responses);

						case 451 :
						case 551 :
							throw new SFtpException("Server had trouble writing the remote file.", 
								responses);

						default :
							throw new SFtpException("Server sent back unrecognized response.", responses);
					}

					transfer(sourceStream, cliStream);
					cliStream.Close();
				}

				responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 226 :
						_logger.WriteLine("Wrote all of the contents.");
						return;

					case 425 :
					case 426 :
						throw new SFtpException("Client closed the connection too early.", responses);

					case 450 :
					case 451 :
					case 452 :
					case 551 :
					case 552 :
						throw new SFtpException("Server had trouble storing the remote file.", 
							responses);

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to store file contents.", e);
			}
		}

		public string[] list()
		{
			ArrayList aList = new ArrayList();
			ResponseLine []responses;

			try
			{
				using (TcpClient client = startPasv())
				{
					using (StreamReader reader = new StreamReader(client.GetStream()))
					{
						_logger.WriteLine("Listing contents.");

						_commandWriter.WriteLine("NLST");
						_commandWriter.Flush();

						responses = receiveResponse();
						switch (responses[responses.Length - 1].ResponseCode)
						{
							case 150 :
								_logger.WriteLine("Read a mark -- have to read some more.");
								break;

							case 425 :
							case 426 :
								throw new SFtpException("Client closed the connection too early.", responses);

							case 450 :
							case 451 :
							case 550 :
							case 551 :
								throw new SFtpException("Server had trouble reading remote directory.", 
									responses);

							default :
								throw new SFtpException("Server sent back unrecognized response.", responses);
						}

						string line;
						while ( (line = reader.ReadLine()) != null)
						{
							aList.Add(line.Trim());
						}
					}
				}

				responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 226 :
						_logger.WriteLine("Read all of the contents.");
						string []ret = new string[aList.Count];
						aList.CopyTo(ret);

						return ret;

					case 425 :
					case 426 :
						throw new SFtpException("Client closed the connection too early.", responses);

					case 451 :
					case 551 :
						throw new SFtpException("Server had trouble reading the remote directory.", 
							responses);

					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to read file contents.", e);
			}
		}

		static private Regex _passiveResponseParser = new Regex(
			@"\D+(?<h1>\d+)\D(?<h2>\d+)\D(?<h3>\d+)\D(?<h4>\d+)\D(?<p1>\d+)\D(?<p2>\d+).*");
		private TcpClient startPasv()
		{
			try
			{
				_logger.WriteLine("Starting a passive connection.");

				_commandWriter.WriteLine("PASV");
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 227 :
						Match m = _passiveResponseParser.Match(
							responses[responses.Length - 1].ResponseText);
						if (!m.Success)
							throw new SFtpException("Servered sent back an unparseable response.",
								responses);

						string ipaddr = string.Format("{0}.{1}.{2}.{3}",
							m.Groups["h1"].Value, m.Groups["h2"].Value,
							m.Groups["h3"].Value, m.Groups["h4"].Value);
						int port = Int32.Parse(m.Groups["p1"].Value) * 256 +
									Int32.Parse(m.Groups["p2"].Value);

						_logger.WriteLine("Attempting to connect to {0}:{1}", ipaddr, port);
						return new TcpClient(ipaddr, port);
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to create passive connection.", e);
			}
		}

		private void sendPassword(string user, SFtp.AuthenticationDelegate authHandler)
		{
			string password;

			try
			{
				_logger.WriteLine("Server requires a password.");
				if (!authHandler(user, out password))
					throw new SFtpException("User cancelled authentication.");
				_commandWriter.WriteLine("PASS {0}", password);
				_commandWriter.Flush();

				ResponseLine []responses = receiveResponse();
				switch (responses[responses.Length - 1].ResponseCode)
				{
					case 230 :
					case 202 :
						_logger.WriteLine("Server accepted user name and password.");
						return;
					case 332 :
					case 503 :
					case 530 :
						throw new SFtpException("Server rejected user name and password.", responses);
					default :
						throw new SFtpException("Server sent back unrecognized response.", responses);
				}
			}
			catch (SFtpException)
			{
				throw;
			}
			catch (Exception e)
			{
				throw new SFtpException("Unable to authenticate with server.", e);
			}
		}
	}
}