using System;

using System.IO;

using System.Net;
using System.Net.Sockets;

using System.Text.RegularExpressions;

namespace GBG.FTP.SFtp
{
	public class SFtp : IDisposable
	{
		static private Regex _userPasswordParser = new Regex("(?<username>[^:]*)(:(?<password>.*))?");

		/// <summary>
		/// This delegate is used by the FTP client when authentication needs to be done.  The
		/// user might be null or might be filled in with a default value if available but he password
		/// is strictly an output parameter.  Further, the result is a boolean indicating whether or
		/// not any information was entered.  True means that there was so information, false means there
		/// wasn't (it was cancelled).
		/// </summary>
		public delegate bool AuthenticationDelegate(string user, out string password);

		private bool _disposed = false;
		private TcpClient _clientSocket = null;
		private FtpProtocol _protocolHandler;

		private SFtp(string host, int port, string path, string user, 
			AuthenticationDelegate authHandler, TextWriter logger)
		{
			if (logger == null)
				logger = TextWriter.Null;

			_clientSocket = new TcpClient(host, port);

			_protocolHandler = new FtpProtocol(new StreamReader(_clientSocket.GetStream()),
				new StreamWriter(_clientSocket.GetStream()), logger);

			_protocolHandler.acceptGreeting();
			_protocolHandler.authenticate(user, authHandler);
		}

		~SFtp()
		{
			Dispose();
		}

		static public SFtp connect(Uri connectionString, TextWriter logger)
		{
			return connect(connectionString, (AuthenticationDelegate)null, logger);
		}

		static public SFtp connect(Uri connectionString, string password, TextWriter logger)
		{
			DefaultAuthenticationHandler handler = new DefaultAuthenticationHandler(password);
			return connect(connectionString,
				new AuthenticationDelegate(handler.handleAuthenticateRequest), logger);
		}

		static public SFtp connect(Uri connectionString, AuthenticationDelegate authHandler,
			TextWriter logger)
		{
			if (!connectionString.Scheme.Equals(Uri.UriSchemeFtp))
				throw new SFtpException(
					string.Format("Scheme for URI is not \"{0}\".", Uri.UriSchemeFtp));

			Match m = _userPasswordParser.Match(connectionString.UserInfo);
			string user = m.Groups["username"].Value;
			string password = m.Groups["password"].Value;
			string host = connectionString.Host;
			string path = connectionString.AbsolutePath;
			int port = connectionString.Port;

			DefaultAuthenticationHandler handler = new DefaultAuthenticationHandler(password);
			
			if (password != null && password.Length > 0)
				authHandler = new AuthenticationDelegate(handler.handleAuthenticateRequest);

			return new SFtp(host, port, path, user, authHandler, logger);
		}

		public enum TransferTypes
		{
			BINARY,
			TEXT
		}

		public TransferTypes TransferType
		{
			set
			{
				_protocolHandler.type(value);
			}
		}

		public string CWD
		{
			get
			{
				return _protocolHandler.pwd();
			}

			set
			{
				_protocolHandler.cwd(value);
			}
		}

		public void download(string sourceFile, string targetFile)
		{
			using (FileStream outputFile = new FileStream(targetFile, FileMode.Create))
			{
				download(sourceFile, outputFile);
			}
		}

		public void download(string sourceFile, Stream output)
		{
			_protocolHandler.download(sourceFile, output);
		}

		public void upload(string sourceFile, string targetFile)
		{
			using (FileStream inputFile = new FileStream(sourceFile, FileMode.Open))
			{
				upload(inputFile, targetFile);
			}
		}

		public void upload(Stream sourceFile, string targetFile)
		{
			_protocolHandler.upload(sourceFile, targetFile);
		}

		public void mkdir(string dir)
		{
			_protocolHandler.mkdir(dir);
		}

		public void rmdir(string dir)
		{
			_protocolHandler.rmdir(dir);
		}

		public void delete(string file)
		{
			_protocolHandler.delete(file);
		}

		public void rename(string source, string target)
		{
			_protocolHandler.rename(source, target);
		}

		public string[] list()
		{
			return _protocolHandler.list();
		}
		public void close()
		{
			lock (this)
			{
				if (_clientSocket != null)
					_clientSocket.Close();
			}
		}

		#region IDisposable Members

		public void Dispose()
		{
			lock (this)
			{
				if (_disposed)
					return;

				_disposed = true;
			}

			close();
			GC.SuppressFinalize(this);
		}

		#endregion

		private class DefaultAuthenticationHandler
		{
			private string _givenPassword;

			public DefaultAuthenticationHandler(string givenPassword)
			{
				_givenPassword = givenPassword;
			}

			public bool handleAuthenticateRequest(string user, out string password)
			{
				password = _givenPassword;
				return true;
			}
		}
	}
}