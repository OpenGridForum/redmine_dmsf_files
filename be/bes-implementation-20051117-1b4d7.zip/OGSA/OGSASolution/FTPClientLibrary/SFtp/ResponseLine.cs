using System;

using System.Text.RegularExpressions;

namespace GBG.FTP.SFtp
{
	public class ResponseLine
	{
		static private Regex _responsePattern = 
			new Regex(@"(?<code>[0-9]+)\s*(?<hyphen>-)?\s*(?<text>.*)");

		static private int parseResponseLine(string line, out string text)
		{
			Match m = _responsePattern.Match(line);
			
			if (!m.Success)
				throw new SFtpException("Received unparseable response from server.");

			text = m.Groups["text"].Value;

			int multiplier = (m.Groups["hyphen"].Success) ? -1 : 1;

			return multiplier * Int32.Parse(m.Groups["code"].Value);
		}

		private string _text;
		private int _code;

		public ResponseLine(string line)
		{
			_code = parseResponseLine(line, out _text);
		}

		public int ResponseCode
		{
			get
			{
				return _code;
			}
		}

		public string ResponseText
		{
			get
			{
				return _text;
			}
		}

		public override string ToString()
		{
			if (_code < 0)
				return string.Format("{0}-{1}", -1 * _code, _text);
			else
				return string.Format("{0} {1}", _code, _text);
		}

	}
}