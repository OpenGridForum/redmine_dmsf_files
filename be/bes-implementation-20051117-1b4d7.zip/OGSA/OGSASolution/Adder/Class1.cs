using System;

using System.IO;

namespace Adder
{
	public class Class1
	{
		static public void Main(string []args)
		{
			if (args.Length != 4)
			{
				Console.Error.WriteLine("USAGE:  Adder <sleep-seconds> <input1> <input2> <output>");
				Environment.Exit(1);
			}

			int seconds = Int32.Parse(args[0]);
			int a;
			int b;
			
			using (StreamReader aStream = new StreamReader(new FileStream(args[1], FileMode.Open)))
			{
				a = Int32.Parse(aStream.ReadLine());
			}
			using (StreamReader bStream = new StreamReader(new FileStream(args[2], FileMode.Open)))
			{
				b = Int32.Parse(bStream.ReadLine());
			}

			System.Threading.Thread.Sleep(1000 * seconds);

			using (StreamWriter output = new StreamWriter(new FileStream(args[3], FileMode.Create)))
			{
				output.WriteLine("Total:  {0}", a + b);
			}
		}
	}
}