using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public class DefaultLogger : ILogger
	{
		private ILogDevice _device;

		public DefaultLogger(ILogDevice device)
		{
			_device = device;
		}

		#region ILogger Members

		public void log(string msg, LogLevel level)
		{
			_device.logMessage(msg);
		}

		#endregion
	}
}