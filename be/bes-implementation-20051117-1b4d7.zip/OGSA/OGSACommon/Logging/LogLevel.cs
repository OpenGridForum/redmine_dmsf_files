using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public enum LogLevel
	{
		Debug = 0,
		Information = 1,
		Warning = 2,
		Error = 3
	}
}