using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public interface ILogger
	{
		void log(string msg, LogLevel level);
	}
}