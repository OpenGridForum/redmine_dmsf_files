using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public abstract class AbstractFilterLogger : ILogger
	{
		private ILogger _logger;

		protected AbstractFilterLogger(ILogger logger)
		{
			_logger = logger;
		}

		protected abstract bool passesFilter(string msg, LogLevel level);

		#region ILogger Members

		public void log(string msg, LogLevel level)
		{
			if (passesFilter(msg, level))
				_logger.log(msg, level);
		}

		#endregion
	}
}