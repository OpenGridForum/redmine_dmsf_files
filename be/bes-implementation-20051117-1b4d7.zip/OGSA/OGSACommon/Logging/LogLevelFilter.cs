using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public class LogLevelFilter : AbstractFilterLogger
	{
		private LogLevel _threshold;

		public LogLevelFilter(ILogger subLogger, LogLevel threshold)
			: base(subLogger)
		{
			_threshold = threshold;
		}

		protected override bool passesFilter(string msg, LogLevel level)
		{
			if (level >= _threshold)
				return true;

			return false;
		}
	}
}