using System;

namespace GBG.OGSA.OGSACommon.Logging
{
	public interface ILogDevice
	{
		void logMessage(string msg);
	}
}