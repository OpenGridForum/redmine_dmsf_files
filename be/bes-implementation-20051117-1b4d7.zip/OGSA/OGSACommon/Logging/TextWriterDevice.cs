using System;
using System.IO;

namespace GBG.OGSA.OGSACommon.Logging
{
	public class TextWriterDevice : ILogDevice
	{
		private TextWriter _writer;

		public TextWriterDevice(TextWriter writer)
		{
			_writer = writer;
		}

		#region ILogDevice Members

		public void logMessage(string msg)
		{
			_writer.WriteLine(msg);
		}

		#endregion
	}
}