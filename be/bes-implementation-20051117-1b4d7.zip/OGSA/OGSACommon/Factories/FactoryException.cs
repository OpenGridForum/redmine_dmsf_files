using System;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

namespace GBG.OGSA.OGSACommon.Factories
{
	public class FactoryException : BaseFaultType
	{
		public FactoryException(string description, EndpointReferenceType originator)
			: base(description, null, null, originator)
		{
		}

		public FactoryException()
		{
		}
	}
}