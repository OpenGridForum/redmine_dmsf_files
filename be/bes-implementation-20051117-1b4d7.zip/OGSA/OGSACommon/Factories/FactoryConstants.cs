using System;

using System.Xml;

namespace GBG.OGSA.OGSACommon.Factories
{
	public class FactoryConstants
	{
		public const string _FACT_NAMESPACE = "http://gbg.virginia.edu/factories";
		public const string _FACT_PORTTYPE_NAME = "factory";
		public const string _FACT_SERVICE_EPRS_RP_NAME = "service-eprs";

		static public readonly XmlQualifiedName _FACT_PORTTYPE_QNAME =
			new XmlQualifiedName(_FACT_PORTTYPE_NAME, _FACT_NAMESPACE);
	}
}