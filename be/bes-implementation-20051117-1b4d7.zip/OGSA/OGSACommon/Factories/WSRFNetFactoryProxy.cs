using System.Diagnostics;
using System.Xml.Serialization;
using System;
using System.Web.Services.Protocols;
using System.ComponentModel;
using System.Web.Services;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Factories
{
	/// <remarks/>
	// CODEGEN: The optional WSDL extension element 'operation' from namespace 'http://schemas.xmlsoap.org/wsdl/soap/' was not handled.
	// CODEGEN: The optional WSDL extension element 'body' from namespace 'http://schemas.xmlsoap.org/wsdl/soap/' was not handled.
	// CODEGEN: The optional WSDL extension element 'body' from namespace 'http://schemas.xmlsoap.org/wsdl/soap/' was not handled.
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	[System.ComponentModel.DesignerCategoryAttribute("code")]
	[System.Web.Services.WebServiceBindingAttribute(Name="WSRFNetFactoryBinding", Namespace="http://gbg.virginia.edu/factories/bindings")]
	public class WSRFNetFactoryProxy : Microsoft.Web.Services2.WebServicesClientProtocol 
	{
		/// <remarks/>
		public WSRFNetFactoryProxy(string Url) 
		{
			this.Url = Url;
		}

		/// <remarks/>
		public WSRFNetFactoryProxy(EndpointReferenceType epr)
		{
			WSUtilities.setEPR(this, epr);
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://ggf.org/name/resolve/resolve", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("resolveWSNameResponse", Namespace="http://ggf.org/name")]
		public resolveWSNameResponse resolveWSName([System.Xml.Serialization.XmlElementAttribute("resolveWSName", Namespace="http://ggf.org/name")] resolveWSName resolveWSName1) 
		{
			object[] results = this.Invoke("resolveWSName", new object[] {
																			 resolveWSName1});
			return ((resolveWSNameResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginresolveWSName(resolveWSName resolveWSName1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("resolveWSName", new object[] {
																	  resolveWSName1}, callback, asyncState);
		}
        
		/// <remarks/>
		public resolveWSNameResponse EndresolveWSName(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((resolveWSNameResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://ggf.org/name/resolve/resolve_abstractname", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("resolveAbstractNameResponse", Namespace="http://ggf.org/name")]
		public resolveAbstractNameResponse resolveAbstractName([System.Xml.Serialization.XmlElementAttribute("resolveAbstractName", Namespace="http://ggf.org/name")] resolveAbstractName resolveAbstractName1) 
		{
			object[] results = this.Invoke("resolveAbstractName", new object[] {
																				   resolveAbstractName1});
			return ((resolveAbstractNameResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginresolveAbstractName(resolveAbstractName resolveAbstractName1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("resolveAbstractName", new object[] {
																			resolveAbstractName1}, callback, asyncState);
		}
        
		/// <remarks/>
		public resolveAbstractNameResponse EndresolveAbstractName(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((resolveAbstractNameResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://gbg.virginia.edu/factories/instantiate", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("instantiateResponse", Namespace="http://gbg.virginia.edu/factories")]
		public instantiateResponse instantiate([System.Xml.Serialization.XmlElementAttribute("instantiate", Namespace="http://gbg.virginia.edu/factories")] instantiate instantiate1) 
		{
			object[] results = this.Invoke("instantiate", new object[] {
																		   instantiate1});
			return ((instantiateResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Begininstantiate(instantiate instantiate1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("instantiate", new object[] {
																	instantiate1}, callback, asyncState);
		}
        
		/// <remarks/>
		public instantiateResponse Endinstantiate(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((instantiateResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://gbg.virginia.edu/factories/addServices", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("addServicesResponse", Namespace="http://gbg.virginia.edu/factories")]
		public addServicesResponse addServices([System.Xml.Serialization.XmlElementAttribute("addServices", Namespace="http://gbg.virginia.edu/factories")] addServices addServices1) 
		{
			object[] results = this.Invoke("addServices", new object[] {
																		   addServices1});
			return ((addServicesResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginaddServices(addServices addServices1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("addServices", new object[] {
																	addServices1}, callback, asyncState);
		}
        
		/// <remarks/>
		public addServicesResponse EndaddServices(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((addServicesResponse)(results[0]));
		}
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://gbg.virginia.edu/factories")]
	public class addServicesResponse 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://gbg.virginia.edu/factories")]
	public class addServices 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlArrayItemAttribute("service-epr", IsNullable=false)]
		public EndpointReferenceType[] services;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://gbg.virginia.edu/factories")]
	public class instantiateResponse 
	{
        
		/// <remarks/>
		public EndpointReferenceType instance;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://gbg.virginia.edu/factories")]
	public class instantiate 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ggf.org/name")]
	public class resolveAbstractNameResponse 
	{
        
		/// <remarks/>
		public EndpointReferenceType resolution;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ggf.org/name")]
	public class resolveAbstractName 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("abstract-name")]
		public string abstractname;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ggf.org/name")]
	public class resolveWSNameResponse 
	{
        
		/// <remarks/>
		public EndpointReferenceType resolution;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ggf.org/name")]
	public class resolveWSName 
	{
        
		/// <remarks/>
		public EndpointReferenceType hint;
	}
}