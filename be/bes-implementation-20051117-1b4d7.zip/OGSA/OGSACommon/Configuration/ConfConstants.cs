using System;

namespace GBG.OGSA.OGSACommon.Configuration
{
	public class ConfConstants
	{
		public const string _CONF_SECTION_NAME = "uva.gbg.ogsa.filesanddirs";
	}
}