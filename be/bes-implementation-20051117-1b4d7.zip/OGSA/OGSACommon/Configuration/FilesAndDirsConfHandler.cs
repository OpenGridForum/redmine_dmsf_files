using System;

using System.Configuration;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;

namespace GBG.OGSA.OGSACommon.Configuration
{
	public class FilesAndDirsConfHandler : IConfigurationSectionHandler
	{
		#region IConfigurationSectionHandler Members

		public object Create(object parent, object configContext, System.Xml.XmlNode section)
		{
			XmlRootAttribute root = new XmlRootAttribute(ConfConstants._CONF_SECTION_NAME);
			return WSUtilities.Deserialize((XmlElement)section, typeof(FilesAndDirsConf), root);
		}

		#endregion
	}
}