using System;
using System.IO;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.AppDomainCaches;

using GBG.OGSA.OGSACommon.Logging;

namespace GBG.OGSA.OGSACommon.Configuration
{
	public class FileBasedClientSession : IClientSessionManager
	{
		private ILogger _logger;

		public FileBasedClientSession(ILogger logger)
		{
			_logger = logger;
		}

		static public FileInfo SessionFile
		{
			get
			{
				string sessionID = Environment.GetEnvironmentVariable("OGSA_SESSION_ID");
				if (sessionID == null)
					sessionID = "default";

				string dir = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
				if (!Directory.Exists(dir))
					throw new Exception(string.Format("Directory \"{0}\" does not exist.\n", dir));

				return new FileInfo(string.Format("{0}\\ogsa-session.{1}.xml", dir, sessionID));
			}
		}

		#region IClientSessionManager Members

		public bool Exists
		{
			get
			{
				return SessionFile.Exists;
			}
		}

		public void clear()
		{
			SessionFile.Delete();
		}

		public ClientSession Session
		{
			get
			{
				FileInfo info = SessionFile;
				if (info.Exists)
				{
					using (FileStream stream = info.OpenRead())
					{
						XmlSerializer ser = SerializerCache.Instance[typeof(ClientSession)];
						return (ClientSession)ser.Deserialize(stream);
					}
				}
				else
					return new ClientSession();
			}
			set
			{
				FileInfo info = SessionFile;
				using (FileStream stream = info.Open(FileMode.Create, FileAccess.Write, FileShare.None))
				{
					XmlSerializer ser = SerializerCache.Instance[typeof(ClientSession)];
					ser.Serialize(stream, value);
				}
			}
		}

		public ILogger Logger
		{
			get
			{
				return _logger;
			}

			set
			{
				_logger = value;
			}
		}

		#endregion
	}
}