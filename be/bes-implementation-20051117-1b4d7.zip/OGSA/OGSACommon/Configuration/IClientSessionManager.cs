using System;

using GBG.OGSA.OGSACommon.Logging;

namespace GBG.OGSA.OGSACommon.Configuration
{
	public interface IClientSessionManager
	{
		bool Exists { get; }
		void clear();
		ClientSession Session { get; set; }
		ILogger Logger { get; set; }
	}
}