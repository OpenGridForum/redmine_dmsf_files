using System;

using System.IO;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.Directories;

namespace GBG.OGSA.OGSACommon.Configuration
{
	public class FilesAndDirsConf
	{
		private string _directory;

		[XmlElement("state-directory")]
		public string StateDirectory
		{
			get
			{
				return _directory;
			}

			set
			{
				_directory = value;
			}
		}

		public FilesAndDirsConf()
		{
		}
	}
}