using System;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;
using GBG.OGSA.OGSACommon.Logging;

namespace GBG.OGSA.OGSACommon.Configuration
{
	[XmlRoot("client-session", Namespace=SharedConstants._SHARED_NAMESPACE)]
	public class ClientSession
	{
		/// <summary>
		/// An array of ContextEntry types representing your current path.
		/// </summary>
		private ContextPath _currentPath;

		[XmlElement("current-path", Namespace=SharedConstants._SHARED_NAMESPACE)]
		public ContextPath CurrentPath
		{
			get
			{
				return _currentPath;
			}

			set
			{
				_currentPath = value;
			}
		}

		public ClientSession()
			: this(null)
		{
		}

		public ClientSession(EndpointReferenceType root)
		{
			_currentPath = new ContextPath(root);
		}

		public ClientSession(ContextPath path)
		{
			_currentPath = path;
		}
	}
}