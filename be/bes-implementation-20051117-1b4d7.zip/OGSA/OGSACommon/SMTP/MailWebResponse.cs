using System;

using System.IO;
using System.Net;

namespace GBG.OGSA.OGSACommon.SMTP
{
	public class MailWebResponse : WebResponse
	{
		private Uri _responseURI;
		private FileInfo _file;

		public MailWebResponse(FileInfo file, Uri responseURI)
		{
			_responseURI = responseURI;
			_file = file;
		}

		public override void Close()
		{
			if (_file != null)
				_file.Delete();
		}

		public override System.IO.Stream GetResponseStream()
		{
			throw new NotSupportedException("GetResponseStream not supported in MailWebResponse class.");
		}
	}
}