using System;

using System.Net;

using System.Web.Mail;

namespace GBG.OGSA.OGSACommon.SMTP
{
	public class MailWebRequestCreate : IWebRequestCreate
	{
		private string _fromAddress;
		private string _subjectPattern;
		private string _bodyPattern;

		public MailWebRequestCreate(string server, string fromAddress)
			: this(server, fromAddress, "Message \"{0}\".")
		{
		}

		public MailWebRequestCreate(string server, string fromAddress, string subjectPattern)
			: this(server, fromAddress, subjectPattern, "Result of a send to \"{0}\".")
		{
		}

		public MailWebRequestCreate(string server, string fromAddress, string subjectPattern, string bodyPattern)
		{
			SmtpMail.SmtpServer = server;
			_fromAddress = fromAddress;
			_subjectPattern = subjectPattern;
			_bodyPattern = bodyPattern;
		}

		#region IWebRequestCreate Members

		public WebRequest Create(Uri uri)
		{
			return new MailWebRequest(_fromAddress, _subjectPattern, _bodyPattern, uri);
		}

		#endregion
	}
}