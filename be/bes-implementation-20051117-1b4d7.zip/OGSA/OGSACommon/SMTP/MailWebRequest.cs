using System;

using System.IO;

using System.Text.RegularExpressions;

using System.Net;

using System.Web.Mail;

namespace GBG.OGSA.OGSACommon.SMTP
{
	public class MailWebRequest : WebRequest
	{
		static private Regex _QUERY_PARAM = new Regex("(?<name>[^=]+)=(?<value>.+)");

		private string _fromAddress;
		private string _subjectPattern;
		private string _bodyPattern;
		private string _fileExt = null;

		private FileInfo _file = null;
		private Stream _fileStream = null;

		private Uri _requestURI;

		public MailWebRequest(string fromAddress, string subjectPattern, string bodyPattern, Uri requestURI)
		{
			_requestURI = requestURI;
			_fromAddress = fromAddress;
			_subjectPattern = subjectPattern;
			_bodyPattern = bodyPattern;

			string query = _requestURI.Query;
			if (query != null && query.Length > 0)
				query = query.Substring(1);

			string []options = query.Split('&');
			foreach (string option in options)
			{
				Match m = _QUERY_PARAM.Match(option);
				if (m.Success)
				{
					string name = m.Groups["name"].Value.ToUpper();
					string val = m.Groups["value"].Value;

					switch (name)
					{
						case "FILEEXT" :
							_fileExt = val;
							break;
						case "SUBJECT" :
							_subjectPattern = val;
							break;
						case "BODY" :
							_bodyPattern = val;
							break;

						case "TO" :
						case "CC" :
						case "BCC" :
						default :
							break;
					}
				}
			}
		}

		public override Stream GetRequestStream()
		{
			string filename = Path.GetTempFileName();
			if (_fileExt != null)
				filename += "." + _fileExt;

			_file = new FileInfo(filename);
			_fileStream = new FileStream(_file.FullName, FileMode.Create, FileAccess.Write);

			return _fileStream;
		}

		public override WebResponse GetResponse()
		{
			_fileStream.Close();

			MailMessage msg = new MailMessage();
			msg.Attachments.Add(new MailAttachment(_file.FullName));

			msg.Body = string.Format(_bodyPattern, _requestURI);
			msg.From = _fromAddress;
			msg.Subject = string.Format(_subjectPattern, _requestURI);
			msg.To = string.Format("{0}@{1}", _requestURI.UserInfo, _requestURI.Host);

			SmtpMail.Send(msg);

			return new MailWebResponse(_file, _requestURI);
		}

		public override Uri RequestUri
		{
			get
			{
				return _requestURI;
			}
		}
	}
}