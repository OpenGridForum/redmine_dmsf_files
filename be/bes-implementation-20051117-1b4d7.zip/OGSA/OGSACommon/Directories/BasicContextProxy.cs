using System.Diagnostics;
using System.Xml.Serialization;
using System;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS;

namespace GBG.OGSA.OGSACommon.Directories
{   
	/// <remarks/>
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	[System.ComponentModel.DesignerCategoryAttribute("code")]
	[System.Web.Services.WebServiceBindingAttribute(Name="ContextBinding", Namespace="http://ogsa.org/directories/bindings")]
	public class BasicContextProxy : Microsoft.Web.Services2.WebServicesClientProtocol 
	{
		/// <remarks/>
		public BasicContextProxy(string Url) 
		{
			this.Url = Url;
		}

		/// <remarks/>
		public BasicContextProxy(EndpointReferenceType epr)
		{
			WSUtilities.setEPR(this, epr);
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://ogsa.org/directories/lookup", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("lookupResponse", Namespace="http://ogsa.org/directories")]
		public lookupResponse lookup([System.Xml.Serialization.XmlElementAttribute("lookup", Namespace="http://ogsa.org/directories")] lookup lookup1) 
		{
			object[] results = this.Invoke("lookup", new object[] {
																	  lookup1});
			return ((lookupResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginlookup(lookup lookup1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("lookup", new object[] {
															   lookup1}, callback, asyncState);
		}
        
		/// <remarks/>
		public lookupResponse Endlookup(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((lookupResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://ogsa.org/directories/add", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("addResponse", Namespace="http://ogsa.org/directories")]
		public addResponse add([System.Xml.Serialization.XmlElementAttribute("add", Namespace="http://ogsa.org/directories")] add add1) 
		{
			object[] results = this.Invoke("add", new object[] {
																   add1});
			return ((addResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginadd(add add1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("add", new object[] {
															add1}, callback, asyncState);
		}
        
		/// <remarks/>
		public addResponse Endadd(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((addResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://ogsa.org/directories/remove", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("removeResponse", Namespace="http://ogsa.org/directories")]
		public removeResponse remove([System.Xml.Serialization.XmlElementAttribute("remove", Namespace="http://ogsa.org/directories")] remove remove1) 
		{
			object[] results = this.Invoke("remove", new object[] {
																	  remove1});
			return ((removeResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginremove(remove remove1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("remove", new object[] {
															   remove1}, callback, asyncState);
		}
        
		/// <remarks/>
		public removeResponse Endremove(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((removeResponse)(results[0]));
		}
	}
        
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class removeResponse 
	{
        
		/// <remarks/>
		public bool result;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class remove 
	{
        
		/// <remarks/>
		public string name;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class addResponse 
	{
        
		/// <remarks/>
		public bool result;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class add 
	{
        
		/// <remarks/>
		public string name;
        
		/// <remarks/>
		public EndpointReferenceType epr;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class lookupResponse 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("entry-map")]
		public ContextEntryMap entrymap;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://ogsa.org/directories")]
	public class lookup 
	{
        
		/// <remarks/>
		public string pattern;
	}
}