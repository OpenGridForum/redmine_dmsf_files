using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Shared;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Naming;

namespace GBG.OGSA.OGSACommon.Directories
{
	[XmlRoot("current-path", Namespace=ContextConstants._DIR_NAMESPACE)]
	public class ContextPath
	{
		#region Delegates

		public delegate bool TraversedPathHandler(ContextPath path, bool repeated);

		#endregion

		#region Constants

		private static readonly TimeSpan _DEFAULT_LOOKUP_TIMEOUT = new TimeSpan(0, 0, 30);
		private const int _MAX_LOOKUP_ENTRIES = 1024;

		#endregion

		#region Caches

		/* Maps full path to EPRs */
		private TimedOutLRUCache _lookupCache;

		#endregion

		#region Private Members

		private EndpointReferenceType _root;
		private ArrayList _pathFromRoot;

		#endregion

		#region Serializable Members

		[XmlElement("root", Namespace=ContextConstants._DIR_NAMESPACE)]
		public EndpointReferenceType Root
		{
			get
			{
				return _root;
			}

			set
			{
				_root = value;
			}
		}

		[XmlArray("path-from-root", Namespace=ContextConstants._DIR_NAMESPACE)]
		[XmlArrayItem("path-element", typeof(ContextEntry), Namespace=ContextConstants._DIR_NAMESPACE)]
		public ArrayList PathFromRoot
		{
			get
			{
				return _pathFromRoot;
			}

			set
			{
				_pathFromRoot = value;
			}
		}

		#endregion

		#region Constructors

		/// <summary>
		/// Should only be used by XMLSerializer.
		/// </summary>
		public ContextPath()
			: this(null)
		{
		}

		public ContextPath(EndpointReferenceType root)
			: this(root, new ArrayList(), new TimedOutLRUCache(_MAX_LOOKUP_ENTRIES))
		{
		}

		private ContextPath(EndpointReferenceType root, ArrayList pathFromRoot, 
			TimedOutLRUCache lookupCache)
		{
			_lookupCache = lookupCache;
			_root = root;
			_pathFromRoot = pathFromRoot;
		}

		#endregion

		#region Public Members/Methods

		public override string ToString()
		{
			string ret = "";

			foreach (ContextEntry entry in _pathFromRoot)
			{
				ret += string.Format("/{0}", entry.EntryName);
			}

			if (_pathFromRoot.Count == 0)
				ret = "/";

			return ret;
		}

		[XmlIgnore]
		public string FullPath
		{
			get
			{
				return ToString();
			}
		}

		[XmlIgnore]
		public string Name
		{
			get
			{
				if (_pathFromRoot.Count == 0)
					return "/";
				return ((ContextEntry)(_pathFromRoot[_pathFromRoot.Count - 1])).EntryName;
			}
		}

		[XmlIgnore]
		public EndpointReferenceType EPR
		{
			get
			{
				if (_pathFromRoot.Count == 0)
					return _root;

				return ((ContextEntry)(_pathFromRoot[_pathFromRoot.Count - 1])).EPR;
			}
		}

		[XmlIgnore]
		public bool Exists
		{
			get
			{
				return EPR != null;
			}
		}

		public ContextPath Dirname
		{
			get
			{
				if (_pathFromRoot == null || _pathFromRoot.Count == 0)
					return this;

				ArrayList list = new ArrayList(_pathFromRoot);
				list.RemoveRange(list.Count - 1, 1);
				return new ContextPath(_root, list, _lookupCache);
			}
		}

		public static implicit operator EndpointReferenceType(ContextPath path)
		{
			return path.EPR;
		}

		public static implicit operator string(ContextPath path)
		{
			return path.FullPath;
		}

		/// <remarks>
		/// This method looks up a pattern in context space.  Based on what it finds there, it's quite possible
		/// that you may get a path back which isn't fully resolved.  This will be indicated by members along the
		/// path that have NULL EPRs.
		/// </remarks>
		public ContextPath[] lookup(string pathExpression, bool mustExist)
		{
			// This will have 0 entries in it if it is the root
			ContextEntry []unresolvedPath = PathUtils.combine(_pathFromRoot, pathExpression);
			if (unresolvedPath.Length == 0)
				return new ContextPath[] {new ContextPath(_root, new ArrayList(), _lookupCache)};

			LinkedEntry root = new LinkedEntry(new ContextEntry("/", _root));
			resolve(root, unresolvedPath, 0);
			/* At this point, we expect a fully fleshed out tree where every link is either resolved, or empty (it,
			 * doesn't exist). */

			ArrayList aList = new ArrayList();
			formList(aList, root, mustExist);

			ContextPath []ret = new ContextPath[aList.Count];
			aList.CopyTo(ret);

			return ret;
		}

		public ContextPath mkdir(string pathExpression, bool createParents)
		{
			ContextPath []paths = lookup(pathExpression, false);

			if (paths.Length != 1)
			{
				throw new ContextException(string.Format("Expression \"{0}\" resolves to more than one name.",
					pathExpression));
			}

			ContextPath path = paths[0];
			if (path.Exists)
			{
				throw new ContextException(string.Format("Path \"{0}\" already exists.", path.FullPath));
			}

			for (int lcv = 0; lcv < path._pathFromRoot.Count; lcv++)
			{
				ContextEntry entry = (ContextEntry)path._pathFromRoot[lcv];
				if (entry.EPR == null)
				{
					if (lcv + 1 < path._pathFromRoot.Count && !createParents)
					{
						throw new ContextException(string.Format("Path \"{0}\" does not exist.", 
							formPath(path._pathFromRoot, lcv)));
					}

					if (lcv == 0)
						entry.EPR = createEntry(_root, entry.EntryName);
					else
						entry.EPR = createEntry(((ContextEntry)path._pathFromRoot[lcv - 1]).EPR,
							entry.EntryName);
				}
			}

			return path;
		}

		public void ln(EndpointReferenceType epr)
		{
			ContextPath parent = Dirname;

			if (!parent.Exists)
				throw new ContextException(string.Format("Path \"{0}\" does not exist.", parent));

			if (Exists)
				throw new ContextException(string.Format("Path \"{0}\" already exists.", this));

			ContextObject cObj = OGSAObject.attach(parent.EPR,
				ContextConstants._DIR_PORTTYPE_QNAME) as ContextObject;

			cObj.add(Name, epr);
			((ContextEntry)(_pathFromRoot[_pathFromRoot.Count - 1])).EPR = epr;
		}

		public void remove(bool force, bool destroy)
		{
			Exception e = null;
			
			try
			{
				if (destroy)
					(new OGSAObject(this)).destroy();
			}
			catch (Exception ee)
			{
				e = ee;

				if (!force)
					throw;
			}

			ContextObject parent = (ContextObject)OGSAObject.attach(Dirname, 
				ContextConstants._DIR_PORTTYPE_QNAME);
			parent.remove(Name);

			if (e != null)
				throw e;
		}

		public void rename(string newName)
		{
			ContextObject parent = (ContextObject)OGSAObject.attach(Dirname,
				ContextConstants._DIR_PORTTYPE_QNAME);
			ContextEntryMap map = parent.lookup(newName);
			if (map.Entries.Length > 0)
				throw new ContextException(string.Format("Name \"{0}\" already exists.", newName));

			parent.add(newName, this);
			parent.remove(Name);
		}

		public ContextPath rename(ContextPath newPath)
		{
			if (newPath.Exists)
				throw new ContextException(string.Format("Path \"{0}\" already exists.", newPath));

			newPath.ln(this);
			this.remove(true, false);

			return newPath;
		}

		public void recursiveTraversal(string pathExpression, TraversedPathHandler handler)
		{
			Hashtable visitedContexts = new Hashtable();
			ContextPath []paths = lookup(pathExpression, true);

			recursiveTraversal(paths, visitedContexts, handler);
		}

		#endregion

		#region Private Members

		private bool recursiveTraversal(ContextPath []paths, Hashtable visistedContexts,
			TraversedPathHandler handler)
		{
			bool visited;
			foreach (ContextPath entry in paths)
			{
				visited = false;
				WSName name = (WSName)entry.EPR;

				if (name != null)
				{
					OGSAObject obj = new OGSAObject(entry);
					if (obj.ImplementsDirectory)
					{
						if (visistedContexts.ContainsKey(name))
							visited = true;
						else
						{
							visistedContexts[name] = entry;
							visited = false;
							if (!recursiveTraversal(entry.lookup("./*", true), visistedContexts, handler))
								return false;
						}
					}
				} else
					visited = false;

				if (!handler(entry, visited))
					return false;
			}

			return true;
		}

		private EndpointReferenceType createEntry(EndpointReferenceType parent, string name)
		{
			/* TODO -- check for context on parent */

			ContextPath []paths = lookup("/Factories/DefaultContextFactory", true);
			if (paths.Length != 1)
				throw new ContextException("Unable to locate context factory.");

			FactoryObject factory = OGSAObject.attach(paths[0].EPR,
				FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;

			WSRFNetFactoryProxy factoryProxy = new WSRFNetFactoryProxy(paths[0].EPR);
			instantiateResponse resp = factoryProxy.instantiate(new instantiate());

			BasicContextProxy contextProxy = new BasicContextProxy(parent);
			add a = new add();
			a.epr = resp.instance;
			a.name = name;
			contextProxy.add(a);

//			UVa.GCG.WSRF.Common.WS.ResourceLifetime.ImmediateResourceTerminationProxy killer =
//				new UVa.GCG.WSRF.Common.WS.ResourceLifetime.ImmediateResourceTerminationProxy(resp.instance);
//			killer.Destroy(new UVa.GCG.WSRF.Common.WS.ResourceLifetime.Destroy());

			return resp.instance;
		}

		private string formPath(ArrayList list, int stop)
		{
			string ret = "";
			
			for (int lcv = 0; lcv <= stop; lcv++)
			{
				ret += string.Format("/{0}", ((ContextEntry)list[lcv]).EntryName);
			}

			return ret;
		}

		private void createPathFromRoot(ArrayList pathFromRoot, LinkedEntry entry)
		{
			if (entry.Parent != null)
				createPathFromRoot(pathFromRoot, entry.Parent);

			if (entry.Entry.EntryName != "/")
				pathFromRoot.Add(new ContextEntry(entry.Entry.EntryName, entry.Entry.EPR));
		}

		private ContextPath createContextPath(LinkedEntry entry)
		{
			ArrayList pathFromRoot = new ArrayList();
			createPathFromRoot(pathFromRoot, entry);

			return new ContextPath(_root, pathFromRoot, _lookupCache);
		}

		private void formList(ArrayList aList, LinkedEntry entry, bool mustExist)
		{
			if (entry.Children.Length == 0)
			{
				ContextPath path = createContextPath(entry);

				if (!mustExist || path.Exists)
					aList.Add(createContextPath(entry));
			} 
			else
			{
				foreach (LinkedEntry child in entry.Children)
				{
					formList(aList, child, mustExist);
				}
			}
		}

		private ContextEntry[] doLookup(EndpointReferenceType epr, string entryName, string parentPath)
		{
			string myPath = (parentPath.Length == 1) ? string.Format("/{0}", entryName) :
				string.Format("{0}/{1}", parentPath, entryName);

			EndpointReferenceType result;
			lock (_lookupCache)
			{
				result = (EndpointReferenceType)_lookupCache.lookup(myPath);
			}

			if (result != null)
				return new ContextEntry[] {new ContextEntry(entryName, result)};

			/* TODO -- check to make sure that it's a directory */
			/* MOOCH */

			BasicContextProxy parent = new BasicContextProxy(epr);
			lookup lookupParam = new lookup();
			lookupParam.pattern = entryName;
			lookupResponse resp = parent.lookup(lookupParam);

			foreach (ContextEntry entry in resp.entrymap.Entries)
			{
				myPath = (parentPath.Length == 1) ? string.Format("/{0}", entry.EntryName) :
					string.Format("{0}/{1}", parentPath, entry.EntryName);
				lock(_lookupCache)
				{
					_lookupCache.add(myPath, entry.EPR, _DEFAULT_LOOKUP_TIMEOUT);
				}
			}

			return resp.entrymap.Entries;
		}

		private void resolve(LinkedEntry parent, ContextEntry []unresolvedPath, int index)
		{
			if (index >= unresolvedPath.Length)
				return;

			ContextEntry entry = unresolvedPath[index];
			if ( (entry.EPR != null) || (parent.Entry.EPR == null) )
			{
				LinkedEntry child = new LinkedEntry(entry, parent);
				resolve(child, unresolvedPath, index+1);
			} 
			else
			{
				string parentPath = parent.FullPath;

				/* We may get 0 results back indicating that nothing matched.  If that's the case, then we will go
				 * forward assuming that nothing matched
				 */
				ContextEntry []results = doLookup(parent.Entry.EPR, entry.EntryName, parentPath);

				if (results.Length == 0)
				{
					LinkedEntry child = new LinkedEntry(entry, parent);
					resolve(child, unresolvedPath, index + 1);
				} 
				else
				{
					foreach (ContextEntry subEntry in results)
					{
						LinkedEntry child = new LinkedEntry(subEntry, parent);
						resolve(child, unresolvedPath, index + 1);
					}
				}
			}
		}

		private class LinkedEntry
		{
			private ContextEntry _entry;
			private LinkedEntry _parent;
			private ArrayList _children;

			public LinkedEntry(ContextEntry root)
				: this(root, null)
			{
			}

			public LinkedEntry(ContextEntry entry, LinkedEntry parent)
			{
				_entry = entry;
				_parent = parent;
				_children = new ArrayList();

				if (parent != null)
					parent._children.Add(this);
			}

			public ContextEntry Entry
			{
				get
				{
					return _entry;
				}
			}

			public LinkedEntry Parent
			{
				get
				{
					return _parent;
				}
			}

			public LinkedEntry[] Children
			{
				get
				{
					LinkedEntry []ret = new LinkedEntry[_children.Count];
					_children.CopyTo(ret);
					return ret;
				}
			}

			public string FullPath
			{
				get
				{
					if (_parent != null)
						return string.Format("{0}/{1}", _parent.FullPath, _entry.EntryName);
					else
						return "";
				}
			}
		}

		#endregion
	}
}