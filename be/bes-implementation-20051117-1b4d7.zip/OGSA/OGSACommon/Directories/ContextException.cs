using System;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class ContextException : Exception
	{
		public ContextException(string msg)
			: base (msg)
		{
		}
	}
}