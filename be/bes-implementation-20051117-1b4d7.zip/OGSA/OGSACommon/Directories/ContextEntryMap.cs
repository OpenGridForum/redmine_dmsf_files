using System;

using System.Collections;

using System.Text.RegularExpressions;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class ContextEntryMap
	{
		/* Maps strings to EPRs */
		private Hashtable _table;

		[XmlArray("entries", Namespace=ContextConstants._DIR_NAMESPACE)]
		[XmlArrayItem("entry", Namespace=ContextConstants._DIR_NAMESPACE)]
		public ContextEntry[] Entries
		{
			get
			{
				int lcv = 0;
				ContextEntry []ret = new ContextEntry[_table.Count];
				foreach (string name in _table.Keys)
				{
					ret[lcv++] = new ContextEntry(name, (EndpointReferenceType)_table[name]);
				}

				return ret;
			}
		
			set
			{
				_table.Clear();
				foreach (ContextEntry entry in value)
				{
					_table[entry.EntryName] = entry.EPR;
				}
			}
		}

		public ContextEntryMap(IDictionary idict)
		{
			if (idict != null)
				_table = new Hashtable(idict);
			else
				_table = new Hashtable();
		}

		public ContextEntryMap()
			: this(null)
		{
		}

		public bool remove(string name)
		{
			bool result = _table.ContainsKey(name);
			_table.Remove(name);
			return result;
		}

		[XmlIgnore]
		public ContextEntryMap this[PathPatternMatcher expression]
		{
			get
			{
				ContextEntryMap result = new ContextEntryMap();
				foreach (string key in _table.Keys)
				{
					if (expression.matches(key))
						result._table[key] = _table[key];
				}

				return result;
			}
		}

		[XmlIgnore]
		public EndpointReferenceType this[string name]
		{
			get
			{
				return (EndpointReferenceType)_table[name];
			}

			set
			{
				_table[name] = value;
			}
		}
	}
}