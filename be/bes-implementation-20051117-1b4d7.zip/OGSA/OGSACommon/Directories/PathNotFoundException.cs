using System;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class PathNotFoundException : ContextException
	{
		public PathNotFoundException(ContextPath path)
			: this(path.ToString())
		{
		}

		public PathNotFoundException(string path)
			: base(string.Format("Path \"{0}\" not found.", path))
		{
		}
	}
}