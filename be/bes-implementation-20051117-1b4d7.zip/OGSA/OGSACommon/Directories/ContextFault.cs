using System;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class ContextFault : BaseFaultType
	{
		public ContextFault(string description, EndpointReferenceType originator)
			: base(description, null, null, originator)
		{
		}
	}
}