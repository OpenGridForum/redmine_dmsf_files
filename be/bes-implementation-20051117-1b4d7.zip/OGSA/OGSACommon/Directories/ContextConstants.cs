using System;
using System.Xml;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class ContextConstants
	{
		public const string _DIR_NAMESPACE = "http://ogsa.org/directories";
		public const string _DIR_PORTTYPE_NAME = "directory";

		static public readonly XmlQualifiedName _DIR_PORTTYPE_QNAME =
			new XmlQualifiedName(_DIR_PORTTYPE_NAME, _DIR_NAMESPACE);
	}
}