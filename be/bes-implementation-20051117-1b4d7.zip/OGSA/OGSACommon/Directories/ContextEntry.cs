using System;
using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Directories
{
	[XmlRoot("context-entry", Namespace=ContextConstants._DIR_NAMESPACE)]
	public class ContextEntry
	{
		private string _entryName;
		private EndpointReferenceType _epr;

		[XmlElement("entry-name", Namespace=ContextConstants._DIR_NAMESPACE)]
		public string EntryName
		{
			get
			{
				return _entryName;
			}

			set
			{
				_entryName = value;
			}
		}

		[XmlElement("epr", Namespace=ContextConstants._DIR_NAMESPACE)]
		public EndpointReferenceType EPR
		{
			get
			{
				return _epr;
			}

			set
			{
				_epr = value;
			}
		}

		public ContextEntry(string name, EndpointReferenceType epr)
		{
			_entryName = name;
			_epr = epr;
		}

		public ContextEntry()
			: this(null, null)
		{
		}

		public override string ToString()
		{
			return _entryName;
		}
	}
}