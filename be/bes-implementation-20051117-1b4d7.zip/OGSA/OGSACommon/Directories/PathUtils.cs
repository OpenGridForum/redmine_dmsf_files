using System;
using System.Collections;

namespace GBG.OGSA.OGSACommon.Directories
{
	public class PathUtils
	{
		static public string normalize(string path)
		{
			string []elements = path.Split('/');

			ArrayList builder = new ArrayList();
			foreach (string element in elements)
			{
				if (element == null || element.Length == 0)
					continue;

				if (element.Equals(".."))
				{
					if (builder.Count > 0)
						builder.RemoveAt(builder.Count - 1);
				} 
				else if (!element.Equals("."))
				{
					builder.Add(element);
				}
			}

			string ret = "";
			foreach (string element in builder)
			{
				ret += string.Format("/{0}", element);
			}

			if (ret.Length == 0)
				return "/";

			return ret;
		}

		static public string normalize(string rootPath, string subPath)
		{
			if (subPath[0] == '/')
				return normalize(subPath);

			return normalize(string.Format("{0}/{1}", rootPath, subPath));
		}

		static public ContextEntry[] combine(ArrayList currentPath, string newPath)
		{
			if (newPath.Length == 0)
			{
				ContextEntry []ret = new ContextEntry[currentPath.Count];
				currentPath.CopyTo(ret);
				return ret;
			}

			string rootPath = "/";
			foreach (ContextEntry entry in currentPath)
				rootPath += string.Format("/{0}", entry.EntryName);

			string normalizedPath = normalize(rootPath, newPath);

			int origNext = 0;
			int pathNext = 0;

			ArrayList builder = new ArrayList();
			string []elements = normalizedPath.Split('/');
			
			for (pathNext = 0; pathNext < elements.Length; pathNext++)
			{
				if (elements[pathNext] == null || elements[pathNext].Length == 0)
					continue;

				if (origNext >= currentPath.Count)
					break;

				ContextEntry entry = (ContextEntry)currentPath[origNext++];
				if (!entry.EntryName.Equals(elements[pathNext]))
					break;

				builder.Add(entry);
			}

			for (;pathNext < elements.Length; pathNext++)
			{
				if (elements[pathNext] == null || elements[pathNext].Length == 0)
					continue;

				builder.Add(new ContextEntry(elements[pathNext], null));
			}

			ContextEntry []entries = new ContextEntry[builder.Count];
			builder.CopyTo(entries);

			return entries;
		}

		static public string basename(string path)
		{
			while (path.EndsWith("/"))
				path = path.Substring(0, path.Length - 1);

			int index = path.LastIndexOf("/");
			if (index < 0)
				return path;
			return path.Substring(index + 1);
		}

		static public string dirname(string path)
		{
			while (path.EndsWith("/"))
				path = path.Substring(0, path.Length - 1);

			int index = path.LastIndexOf("/");
			if (index < 0)
				return ".";

			return path.Substring(0, index);
		}
	}
}