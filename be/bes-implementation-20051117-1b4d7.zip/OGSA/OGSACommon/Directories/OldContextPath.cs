using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Shared;
using GBG.OGSA.OGSACommon.Factories;

namespace GBG.OGSA.OGSACommon.Directories
{
	[XmlRoot("current-path", Namespace=Constants._DIR_NAMESPACE)]
	public class ContextPath
	{
		private static readonly TimeSpan _DEFAULT_LOOKUP_TIMEOUT = new TimeSpan(0, 0, 30);
		private const int _MAX_LOOKUP_ENTRIES = 1024;

		/* Maps full path to EPRs */
		private TimedOutLRUCache _lookupCache;

		private EndpointReferenceType _root;
		private ArrayList _pathFromRoot;

		[XmlElement("root", Namespace=Constants._DIR_NAMESPACE)]
		public EndpointReferenceType Root
		{
			get
			{
				return _root;
			}

			set
			{
				_root = value;
			}
		}

		[XmlArray("path-from-root", Namespace=Constants._DIR_NAMESPACE)]
		[XmlArrayItem("path-element", typeof(ContextEntry), Namespace=Constants._DIR_NAMESPACE)]
		public ArrayList PathFromRoot
		{
			get
			{
				return _pathFromRoot;
			}

			set
			{
				_pathFromRoot = value;
			}
		}

		/// <summary>
		/// Should only be used by XMLSerializer.
		/// </summary>
		public ContextPath()
			: this(null)
		{
		}

		public ContextPath(EndpointReferenceType root)
			: this(root, new ArrayList(), new TimedOutLRUCache(_MAX_LOOKUP_ENTRIES))
		{
		}

		private ContextPath(EndpointReferenceType root, ArrayList pathFromRoot, 
			TimedOutLRUCache lookupCache)
		{
			_lookupCache = lookupCache;
			_root = root;
			_pathFromRoot = pathFromRoot;
		}

		public override string ToString()
		{
			string ret = "";

			foreach (ContextEntry entry in _pathFromRoot)
			{
				ret += string.Format("/{0}", entry.EntryName);
			}

			if (_pathFromRoot.Count == 0)
				ret = "/";

			return ret;
		}

		[XmlIgnore]
		public string FullPath
		{
			get
			{
				return ToString();
			}
		}

		[XmlIgnore]
		public string Name
		{
			get
			{
				if (_pathFromRoot.Count == 0)
					return "/";
				return ((ContextEntry)(_pathFromRoot[_pathFromRoot.Count - 1])).EntryName;
			}
		}

		[XmlIgnore]
		public EndpointReferenceType EPR
		{
			get
			{
				if (_pathFromRoot.Count == 0)
					return _root;

				return ((ContextEntry)(_pathFromRoot[_pathFromRoot.Count - 1])).EPR;
			}
		}

		public ContextPath[] lookup(string pathExpression)
		{
			ContextEntry []newPathElements = PathUtils.combine(_pathFromRoot, pathExpression);
			if (newPathElements.Length == 0)
				return new ContextPath[]
					{
						new ContextPath(_root, new ArrayList(), _lookupCache)
					};

			/* Each element in this list is either a ContextEntry, or an ArrayList of ArrayLists (for new paths) */
			ArrayList newPath = new ArrayList();
			fillInPaths(_root, newPath, newPathElements, 0, "");

			PathPart root = createPathPartTree(newPath, null);
			ArrayList results = new ArrayList();
			sumParts(root, results);

			ContextPath []ret = new ContextPath[results.Count];
			results.CopyTo(ret);

			return ret;
		}

		public ContextPath mkdir(string newDir, bool createPath)
		{
			bool didCreate = false;
			int lcv;

			ContextPath []contextFactory = lookup("/Factories/DefaultContextFactory");
			if (contextFactory.Length != 1)
				throw new ContextException("Unable to locate default context factory.");
			WSRFNetFactoryProxy proxy = new WSRFNetFactoryProxy(contextFactory[0].EPR);

			ContextEntry []pathElements = PathUtils.combine(_pathFromRoot, newDir);
			
			ContextPath tmpPath = new ContextPath(_root, new ArrayList(), _lookupCache);
			for(lcv = 0; lcv < pathElements.Length; lcv++)
			{
				ContextPath []paths = tmpPath.lookup(pathElements[lcv].EntryName);
				if (paths == null || paths.Length == 0)
				{
					if (!createPath)
						throw new ContextException(string.Format("Path \"{0}/{1}\" does not exist.",
							tmpPath.FullPath, pathElements[lcv].EntryName));
				} 
				else if (paths.Length > 1)
				{
					throw new ContextException(string.Format("Too many paths match pattern.\n"));
				} 
				else
				{
					pathElements[lcv].EPR = paths[0].EPR;
					tmpPath._pathFromRoot.Add(pathElements[lcv]);
					continue;
				}

				instantiateResponse resp = proxy.instantiate(new instantiate());
				BasicContextProxy context = null;
				if (lcv == 0)
					context = new BasicContextProxy(_root);
				else
					context = new BasicContextProxy(pathElements[lcv - 1].EPR);

				add a = new add();
				a.epr = resp.instance;
				a.name = pathElements[lcv].EntryName;
				context.add(a);
				pathElements[lcv].EPR = resp.instance;
				didCreate = true;
				tmpPath._pathFromRoot.Add(pathElements[lcv]);
			}

			if (!didCreate)
			{
				throw new ContextException(string.Format("Path \"{0}\" already exists.",
					tmpPath.FullPath));
			}

			return tmpPath;
		}

		public static implicit operator EndpointReferenceType(ContextPath path)
		{
			return path.EPR;
		}

		public static implicit operator string(ContextPath path)
		{
			return path.FullPath;
		}

		private string formPath(ContextEntry []entries, int limit)
		{
			string ret = "";

			for (int lcv = 0; lcv <= limit; lcv++)
				ret += string.Format("/{0}", entries[lcv].EntryName);

			return ret;
		}

		private void sumParts(PathPart node, ArrayList results)
		{
//			if (node.PathComponents.Count == 0)
//				return;

			if (node.Children.Count != 0)
			{
				foreach (PathPart child in node.Children)
				{
					sumParts(child, results);
				}
			} 
			else
			{
				results.Add(createContextPath(node));
			}
		}

		private ContextPath createContextPath(PathPart leaf)
		{
			ArrayList pathFromRoot = new ArrayList();
			
			while (leaf != null)
			{
				pathFromRoot.InsertRange(0, leaf.PathComponents);
				leaf = leaf.Parent;
			}

			return new ContextPath(_root, pathFromRoot, _lookupCache);
		}

		private PathPart createPathPartTree(ArrayList pathList, PathPart parent)
		{
			ArrayList components = new ArrayList();
			foreach (object obj in pathList)
			{
				if (obj is ContextEntry)
				{
					components.Add(obj);
				} 
				else
				{
					PathPart ret = new PathPart(components, parent);
					ArrayList listOfLists = (ArrayList)obj;
					foreach (ArrayList nextPath in listOfLists)
					{
						ret.Children.Add(createPathPartTree(nextPath, ret));
					}

					return ret;
				}
			}

			return new PathPart(components, parent);
		}

		private void fillInPaths(EndpointReferenceType parent,
			ArrayList newPath, ContextEntry []pathElements, int startIndex, string pathSoFar)
		{
			if (startIndex >= pathElements.Length)
				return;

			ContextEntry entry = pathElements[startIndex];
			string newTextPath = string.Format("{0}/{1}", pathSoFar, entry.EntryName);

			if (entry.EPR == null)
			{
				lock(_lookupCache)
				{
					entry.EPR = (EndpointReferenceType)_lookupCache.lookup(newTextPath);
				}
				
				if (entry.EPR == null)
				{
					ContextEntryMap map = doLookup(parent, entry.EntryName);
//					if (map.Entries.Length == 0)
//					{
//						newPath.Clear();
//						return;
//					}

					if (map.Entries.Length == 1)
					{
						entry = map.Entries[0];
						newTextPath = string.Format("{0}/{1}", pathSoFar, entry.EntryName);
						lock (_lookupCache)
						{
							_lookupCache.add(newTextPath, entry.EPR, _DEFAULT_LOOKUP_TIMEOUT);
						}
					} 
					else
					{
						ArrayList listOfPaths = new ArrayList();
						newPath.Add(listOfPaths);
						foreach (ContextEntry entry2 in map.Entries)
						{
							newTextPath = string.Format("{0}/{1}", pathSoFar, entry2.EntryName);
							_lookupCache.add(newTextPath, entry2.EPR, _DEFAULT_LOOKUP_TIMEOUT);
							ArrayList nextNewPath = new ArrayList();
							listOfPaths.Add(nextNewPath);
							nextNewPath.Add(new ContextEntry(entry2.EntryName, entry2.EPR));
							fillInPaths(entry2.EPR, nextNewPath, pathElements, startIndex + 1, newTextPath);
						}

						return;
					}
				}
			}

			newPath.Add(entry);
			fillInPaths(entry.EPR, newPath, pathElements, startIndex + 1, newTextPath);
		}

		private ContextEntryMap doLookup(EndpointReferenceType context, string pattern)
		{
			BasicContextProxy proxy = new BasicContextProxy(context);
			lookup l = new lookup();
			l.pattern = pattern;

			lookupResponse resp = proxy.lookup(l);
			
			return resp.entrymap;
		}

		private class PathPart
		{
			private ArrayList _pathComponents;
			private PathPart _parent;
			private ArrayList _children;

			public ArrayList PathComponents
			{
				get
				{
					return _pathComponents;
				}
			}

			public PathPart Parent
			{
				get
				{
					return _parent;
				}
			}

			public ArrayList Children
			{
				get
				{
					return _children;
				}
			}

			public PathPart(ArrayList pathComponents, PathPart parent)
			{
				_parent = parent;
				_pathComponents = pathComponents;
				_children = new ArrayList();
			}
		}
	}
}