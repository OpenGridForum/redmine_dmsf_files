using System;
using System.Collections;

using System.Xml;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class TransferDescriptionTable : Hashtable
	{
		public TransferDescription this[XmlQualifiedName index]
		{
			get
			{
				return (TransferDescription)base[index];
			}

			set
			{
				base[index] = value;
			}
		}
	}
}