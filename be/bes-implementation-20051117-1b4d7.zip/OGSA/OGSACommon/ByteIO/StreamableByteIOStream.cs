using System;

using System.IO;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class StreamableByteIOStream : Stream
	{
		public override bool CanRead
		{
			get
			{
				/* TODO */
				return true;
			}
		}

		public override bool CanWrite
		{
			get
			{
				/* TODO */
				return true;
			}
		}

		public override bool CanSeek
		{
			get
			{
				/* TODO */
				return true;
			}
		}

		public override void Flush()
		{
			/* TODO */
		}

		public override void Close()
		{
			/* TODO */
			base.Close ();
		}

		public override long Length
		{
			get
			{
				/* TODO */
				return 0;
			}
		}

		public override long Position
		{
			get
			{
				/* TODO */
				return 0;
			}

			set
			{
				/* TODO */
			}
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			/* TODO */
			return 0;
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			/* TODO */
			return 0;
		}

		public override void SetLength(long value)
		{
			/* TODO */
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			/* TODO */
		}
	}
}