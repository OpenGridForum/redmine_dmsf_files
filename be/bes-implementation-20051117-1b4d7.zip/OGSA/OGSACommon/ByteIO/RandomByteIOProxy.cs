using System.Diagnostics;
using System.Xml.Serialization;
using System;
using System.Web.Services.Protocols;
using System.ComponentModel;
using System.Web.Services;
    
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	/// <remarks/>
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	[System.ComponentModel.DesignerCategoryAttribute("code")]
	[System.Web.Services.WebServiceBindingAttribute(Name="BasicFileBinding", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access/bindings")]
	public class RandomByteIOProxy : Microsoft.Web.Services2.WebServicesClientProtocol 
	{
		/// <remarks/>
		public RandomByteIOProxy(string URL) 
		{
			this.Url = URL;
		}

		public RandomByteIOProxy(EndpointReferenceType epr)
		{
			WSUtilities.setEPR(this, epr);
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/byteio/2005/10/random-access/append", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("appendResponse", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
		public appendResponse append([System.Xml.Serialization.XmlElementAttribute("append", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")] append append1) 
		{
			object[] results = this.Invoke("append", new object[] {
																	  append1});
			return ((appendResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginappend(append append1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("append", new object[] {
															   append1}, callback, asyncState);
		}
        
		/// <remarks/>
		public appendResponse Endappend(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((appendResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/byteio/2005/10/random-access/truncAppend", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("truncAppendResponse", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
		public truncAppendResponse truncAppend([System.Xml.Serialization.XmlElementAttribute("truncAppend", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")] truncAppend truncAppend1) 
		{
			object[] results = this.Invoke("truncAppend", new object[] {
																		   truncAppend1});
			return ((truncAppendResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BegintruncAppend(truncAppend truncAppend1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("truncAppend", new object[] {
																	truncAppend1}, callback, asyncState);
		}
        
		/// <remarks/>
		public truncAppendResponse EndtruncAppend(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((truncAppendResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/byteio/2005/10/random-access/read", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("readResponse", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
		public readResponse read([System.Xml.Serialization.XmlElementAttribute("read", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")] read read1) 
		{
			object[] results = this.Invoke("read", new object[] {
																	read1});
			return ((readResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginread(read read1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("read", new object[] {
															 read1}, callback, asyncState);
		}
        
		/// <remarks/>
		public readResponse Endread(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((readResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/byteio/2005/10/random-access/write", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("writeResponse", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
		public writeResponse write([System.Xml.Serialization.XmlElementAttribute("write", Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")] write write1) 
		{
			object[] results = this.Invoke("write", new object[] {
																	 write1});
			return ((writeResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult Beginwrite(write write1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("write", new object[] {
															  write1}, callback, asyncState);
		}
        
		/// <remarks/>
		public writeResponse Endwrite(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((writeResponse)(results[0]));
		}
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class append 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("transfer-information")]
		public BulkTransferInformation transferinformation;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class writeResponse 
	{
        
		/// <remarks/>
		public BulkTransferInformation writeResult;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class write 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("start-offset")]
		public long startoffset;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("bytes-per-block")]
		public int bytesperblock;
        
		/// <remarks/>
		public long stride;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("transfer-information")]
		public BulkTransferInformation transferinformation;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class readResponse 
	{
        
		/// <remarks/>
		public BulkTransferInformation readData;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class read 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("start-offset")]
		public long startoffset;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("bytes-per-block")]
		public int bytesperblock;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("num-blocks")]
		public int numblocks;
        
		/// <remarks/>
		public long stride;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("transfer-information")]
		public BulkTransferInformation transferinformation;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class truncAppendResponse 
	{
        
		/// <remarks/>
		public BulkTransferInformation truncAppendResult;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class truncAppend 
	{
        
		/// <remarks/>
		public long offset;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("transfer-information")]
		public BulkTransferInformation transferinformation;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/byteio/2005/10/random-access")]
	public class appendResponse 
	{
        
		/// <remarks/>
		public BulkTransferInformation appendResult;
	}
}