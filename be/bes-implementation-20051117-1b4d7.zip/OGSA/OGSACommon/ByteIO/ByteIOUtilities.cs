using System;

using System.IO;

using System.Web.Services.Protocols;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;
using Microsoft.Web.Services2.Attachments;
using Microsoft.Web.Services2.Dime;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

using UVa.GCG.WSRF.Service.BaseFaults;

using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class ByteIOUtilities
	{
		static public byte[] receiveData(SoapContext soapContext, BulkTransferInformation transferInfo)
		{
			if (transferInfo.TransferMechanism.Equals(ByteIOConstants.TRANSFER_SIMPLE))
			{
				return ((SimpleTransferDataBlock)WSUtilities.Deserialize(transferInfo.Any[0],
					typeof(SimpleTransferDataBlock))).Data;
			} 
			else if (transferInfo.TransferMechanism.Equals(ByteIOConstants.TRANSFER_DIME))
			{
				DimeTransferDataBlock xferInfo = (DimeTransferDataBlock)WSUtilities.Deserialize(
					transferInfo.Any[0], typeof(DimeTransferDataBlock));
				byte []buffer = new byte[xferInfo.NumBytes];
				soapContext.Attachments[0].Stream.Read(buffer, 0, buffer.Length);
				return buffer;
			}

			throw new GeneratableException(new UnsupportedTransferFault(
				string.Format("Transfer type \"{0}\" is not supported.", transferInfo.TransferMechanism)));
		}

		static public BulkTransferInformation sendData(XmlQualifiedName transferMechanism,
			SoapContext soapContext, byte []data, int length)
		{
			if (transferMechanism.Equals(ByteIOConstants.TRANSFER_SIMPLE))
			{
				return new BulkTransferInformation(transferMechanism,
					WSUtilities.Serialize(new SimpleTransferDataBlock(data, length)));
			} 
			else if (transferMechanism.Equals(ByteIOConstants.TRANSFER_DIME))
			{
				MemoryStream stream = new MemoryStream(data, 0, length);
				soapContext.Attachments.Add(
					new DimeAttachment("unknown", TypeFormat.Unknown, stream));
				return new BulkTransferInformation(transferMechanism,
					WSUtilities.Serialize(new DimeTransferDataBlock(length)));
			}

			throw new GeneratableException(new UnsupportedTransferFault(
				string.Format("Transfer type \"{0}\" is not supported.", transferMechanism)));
		}

		static public int readFully(Stream stream, byte []buffer, int offset, int numBytes)
		{
			int totalRead = 0;
			int bytesRead;

			while (numBytes > 0)
			{
				bytesRead = stream.Read(buffer, offset, numBytes);
				if (bytesRead == 0)
					return totalRead;

				totalRead += bytesRead;
				offset += bytesRead;
				numBytes -= bytesRead;
			}

			return totalRead;
		}
	}
}