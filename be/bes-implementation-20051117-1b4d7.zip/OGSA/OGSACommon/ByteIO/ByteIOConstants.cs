using System;
using System.Collections;

using System.Xml;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class ByteIOConstants
	{
		public const string BYTEIO_NS = "http://schemas.ggf.org/byteio/2005/10/byte-io";
		public const string RBYTEIO_NS = "http://schemas.ggf.org/byteio/2005/10/random-access";
		public const string SBYTEIO_NS = "http://schemas.ggf.org/byteio/2005/10/streamable-access";

		static public readonly XmlQualifiedName _RBYTEIO_QNAME = 
			new XmlQualifiedName("RandomByteIO", RBYTEIO_NS);
		static public readonly XmlQualifiedName TRANSFER_SIMPLE =
			new XmlQualifiedName("simple", "http://ggf.org/byteio/2005/10/transfer-mechanisms");
		static public readonly XmlQualifiedName TRANSFER_DIME =
			new XmlQualifiedName("dime", "http://ggf.org/byteio/2005/10/transfer-mechanisms");

		static public TransferDescriptionTable TransferDescriptions;

		static ByteIOConstants()
		{
			TransferDescriptions = new TransferDescriptionTable();

			TransferDescriptions[TRANSFER_SIMPLE] = new TransferDescription(
				TRANSFER_SIMPLE, 1024 * 4);
			TransferDescriptions[TRANSFER_DIME] = new TransferDescription(
				TRANSFER_DIME, 1024 * 1024);
		}
	}
}