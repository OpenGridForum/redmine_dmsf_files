using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	[XmlType("transfer-information-type", Namespace=ByteIOConstants.BYTEIO_NS)]
	public class BulkTransferInformation
	{
		private XmlElement []_any;
		private XmlQualifiedName _transferMechanism;

		[XmlAnyElement]
		public XmlElement []Any
		{
			get
			{
				return _any;
			}

			set
			{
				_any = value;
			}
		}

		[XmlAttribute("transfer-mechanism", Namespace=ByteIOConstants.BYTEIO_NS)]
		public XmlQualifiedName TransferMechanism
		{
			get
			{
				return _transferMechanism;
			}

			set
			{
				_transferMechanism = value;
			}
		}

		public BulkTransferInformation()
			: this(null, (XmlElement[])null)
		{
		}

		public BulkTransferInformation(XmlQualifiedName transferMechanism)
			: this(transferMechanism, (XmlElement[])null)
		{
		}

		public BulkTransferInformation(XmlQualifiedName transferMechanism,
			XmlElement element)
			: this(transferMechanism, new XmlElement[] {element})
		{
		}

		public BulkTransferInformation(XmlQualifiedName transferMechanism,
			XmlElement []any)
		{
			_transferMechanism = transferMechanism;
			_any = any;
		}
	}
}