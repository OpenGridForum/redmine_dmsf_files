using System;

using System.IO;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class RandomByteIOStream : Stream
	{
		static private FactoryObject _fileFactory = null;

		static FactoryObject getFactory(ContextPath anyPath)
		{
			if (_fileFactory == null)
			{
				ContextPath []entries = anyPath.lookup("/Factories/DefaultFileFactory", true);
				if (entries == null || entries.Length == 0)
					throw new PathNotFoundException("/Factories/DefaultFileFactory");
				_fileFactory = OGSAObject.attach(entries[0].EPR,
					FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;
			}

			return _fileFactory;
		}

		static private EndpointReferenceType attachStream(ContextPath path, FileMode mode)
		{
			EndpointReferenceType epr;

			switch (mode)
			{
				case FileMode.Append :
				case FileMode.Open :
				case FileMode.Truncate :
					if (!path.Exists)
						throw new PathNotFoundException(path);
					break;
					
				case FileMode.Create :
				case FileMode.OpenOrCreate :
					if (!path.Exists)
					{
						epr = getFactory(path).instantiate();
						path.ln(epr);
					}
					break;

				case FileMode.CreateNew :
					if (path.Exists)
						throw new ContextException(string.Format("Path \"{0}\" already exists.", path));

					epr = getFactory(path).instantiate();
					path.ln(epr);
					break;
			}

			return path.EPR;
		}

		private long _position;

		private FileMode _mode;
		private FileAccess _access;
		private EndpointReferenceType _epr;
		private RandomByteIOObject _robj = null;

		private RandomByteIOObject RObj
		{
			get
			{
				lock (this)
				{
					if (_robj == null)
						_robj = OGSAObject.attach(_epr,
							ByteIOConstants._RBYTEIO_QNAME) as RandomByteIOObject;
				}

				return _robj;
			}
		}

		public RandomByteIOStream(ContextPath path)
			: this(path, FileMode.OpenOrCreate, FileAccess.ReadWrite)
		{
		}

		public RandomByteIOStream(ContextPath path, FileMode mode, FileAccess access)
		{
			_epr = attachStream(path, mode);

			switch (mode)
			{
				case FileMode.Append :
					_position = RObj.Size;
					break;

				case FileMode.CreateNew :
				case FileMode.Open :
				case FileMode.OpenOrCreate :
					_position = 0;
					break;

				case FileMode.Create :
				case FileMode.Truncate :
					RObj.truncAppend(new byte[0], 0);
					_position = 0;
					break;
			}

			_mode = mode;
			_access = access;
		}

		public RandomByteIOStream(EndpointReferenceType epr)
			: this(epr, FileMode.Open, FileAccess.ReadWrite)
		{
		}

		public RandomByteIOStream(EndpointReferenceType epr, FileMode mode, FileAccess access)
		{
			_epr = epr;
			_mode = mode;
			_access = access;
		}

		public XmlQualifiedName TransferMechanism
		{
			get
			{
				return RObj.PreferredTransferMechanism;
			}

			set
			{
				_transferBlockSize = 0;
				RObj.PreferredTransferMechanism = value;
			}
		}

		private int _transferBlockSize = 0;
		public int TransferBlockSize
		{
			get
			{
				if (_transferBlockSize == 0)
					_transferBlockSize = 
						ByteIOConstants.TransferDescriptions[TransferMechanism].PreferredBlockSize;

				return _transferBlockSize;
			}

			set
			{
				_transferBlockSize = value;
			}
		}

		public override bool CanRead
		{
			get
			{
				bool canRead = (_access != FileAccess.Write) && RObj.CanRead;
				return canRead;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return true;
			}
		}

		public override bool CanWrite
		{
			get
			{
				bool canWrite = (_access != FileAccess.Read) && RObj.CanWrite;
				return canWrite;
			}
		}
		
		public override long Length
		{
			get
			{
				return RObj.Size;
			}
		}

		public override long Position
		{
			get
			{
				return _position;
			}

			set
			{
			}
		}

		public override void Flush()
		{
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			switch (origin)
			{
				case SeekOrigin.Begin :
					_position = offset;
					break;
				case SeekOrigin.Current :
					_position += offset;
					break;
				case SeekOrigin.End :
					_position = Length + offset;
					break;
			}

			return _position;
		}

		public override void SetLength(long val)
		{
			RObj.truncAppend(new byte[0], val);
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			int totalRead = 0;
			int toRead;

			while (count > 0)
			{
				toRead = (count > TransferBlockSize) ? TransferBlockSize : count;

				byte []data = RObj.read(_position, 1, toRead, 0);
				if (data.Length == 0)
					break;

				Array.Copy(data, 0, buffer, offset + totalRead, data.Length);
				totalRead += data.Length;
				count -= data.Length;
				_position += data.Length;
			}

			return totalRead;
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			int toWrite;
			while (count > 0)
			{
				toWrite = (count > TransferBlockSize) ? TransferBlockSize : count;

				byte []data = new byte[toWrite];
				Array.Copy(buffer, offset, data, 0, toWrite);

				RObj.write(data, _position, toWrite, 0);
				count -= toWrite;
				offset += toWrite;
				_position += toWrite;
			}
		}
	}
}