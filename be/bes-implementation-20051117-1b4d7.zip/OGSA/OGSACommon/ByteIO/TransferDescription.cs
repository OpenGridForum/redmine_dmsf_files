using System;

using System.Xml;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	public class TransferDescription
	{
		private XmlQualifiedName _transferMechanism;
		private int _preferredBlockSize;

		public TransferDescription(XmlQualifiedName transferMechanism, int preferredBlockSize)
		{
			_transferMechanism = transferMechanism;
			_preferredBlockSize = preferredBlockSize;
		}

		public XmlQualifiedName TransferMechanism
		{
			get
			{
				return _transferMechanism;
			}
		}

		public int PreferredBlockSize
		{
			get
			{
				return _preferredBlockSize;
			}
		}
	}
}