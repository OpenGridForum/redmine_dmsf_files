using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.ByteIO
{	
	[XmlRoot("dime-transfer-data-block", Namespace=ByteIOConstants.BYTEIO_NS)]
	public class DimeTransferDataBlock
	{
		private int _numBytes;

		public DimeTransferDataBlock(int numBytes)
		{
			_numBytes = numBytes;
		}

		public DimeTransferDataBlock()
			: this(0)
		{
		}

		[XmlElement("NumberOfBytes", Namespace=ByteIOConstants.BYTEIO_NS)]
		public int NumBytes
		{
			get
			{
				return _numBytes;
			}

			set
			{
				_numBytes = value;
			}
		}
	}
}