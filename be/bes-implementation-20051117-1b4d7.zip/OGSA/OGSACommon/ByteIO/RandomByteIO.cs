using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using System.Text.RegularExpressions;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.Attributes;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Service.BaseTypes;
using UVa.GCG.WSRF.Service.BaseFaults;
using UVa.GCG.WSRF.Service.Grid;
using UVa.GCG.WSRF.Service.ResourceLifetime;
using UVa.GCG.WSRF.Service.ResourceProperties;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.OGSA;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	[WsdlBaseName("RandomByteIO", ByteIOConstants.RBYTEIO_NS)]
	[WebService]
	[WebServiceBinding]
	[WSRFPortType(typeof(ImmediateResourceTerminationPortType))]
	[WSRFPortType(typeof(GCGResourceFactoryPortType))]
	[WSRFPortType(typeof(GetResourcePropertyPortType))]
	public class RandomByteIO : ServiceSkeleton
	{
		static RandomByteIO()
		{
			FaultGenerator.RegisterFaultType(typeof(UnsupportedTransferFault));
		}

		public RandomByteIO()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[ResourceProperty(OGSAConstants.WSResourceInterfacesName,
			 OGSAConstants.WSResourceInterfacesNS,
			 typeof(XmlQualifiedName), false, null, false, "1", "unbounded", 0)]
		private XmlQualifiedName[] WSResourceInterfaces
		{
			get
			{
				return new XmlQualifiedName[]
					{
						new XmlQualifiedName("RandomByteIO", ByteIOConstants.RBYTEIO_NS)
					};
			}
		}

		[ResourceProperty("Size", ByteIOConstants.RBYTEIO_NS, typeof(long),
			 false, "unsignedLong", false, "1", "1", 0)]
		public long Size
		{
			get
			{
				lock (typeof(RandomByteIO))
				{
					return BackendFile.Length;
				}
			}
		}

		[ResourceProperty("Readable", ByteIOConstants.RBYTEIO_NS, typeof(bool),
			 false, "boolean", false, "1", "1", 0)]
		public bool Readable
		{
			get
			{
				return true;
			}
		}

		[ResourceProperty("Writeable", ByteIOConstants.RBYTEIO_NS, typeof(bool),
			 false, "boolean", false, "1", "1", 0)]
		public bool Writeable
		{
			get
			{
				lock (typeof(RandomByteIO))
				{
					bool ronly = (BackendFile.Attributes & FileAttributes.ReadOnly) != 0;
					return !ronly;
				}
			}
		}

		[ResourceProperty("TransferMechanisms", ByteIOConstants.RBYTEIO_NS, typeof(XmlQualifiedName),
			 false, null, false, "1", "unbounded", 0)]
		public XmlQualifiedName[] TransferMechanisms
		{
			get
			{
				return new XmlQualifiedName[]
				{
					ByteIOConstants.TRANSFER_SIMPLE,
					ByteIOConstants.TRANSFER_DIME
				};
			}
		}

		[ResourceProperty("CreateTime", ByteIOConstants.RBYTEIO_NS, typeof(DateTime),
			 false, null, false, "0", "1", 0)]
		public DateTime CreateTime
		{
			get
			{
				lock (typeof(RandomByteIO))
				{
					return BackendFile.CreationTime;
				}
			}
		}

		[ResourceProperty("ModificationTime", ByteIOConstants.RBYTEIO_NS, typeof(DateTime),
			 false, null, false, "0", "1", 0)]
		public DateTime ModificationTime
		{
			get
			{
				lock (typeof(RandomByteIO))
				{
					return BackendFile.LastWriteTime;
				}
			}
		}

		[ResourceProperty("AccessTime", ByteIOConstants.RBYTEIO_NS, typeof(DateTime),
			 false, null, false, "0", "1", 0)]
		public DateTime AccessTime
		{
			get
			{
				lock (typeof(RandomByteIO))
				{
					return BackendFile.LastAccessTime;
				}
			}
		}

		private FilesAndDirsConf DirectoryConfiguration
		{
			get
			{
				FilesAndDirsConf conf = (FilesAndDirsConf)ConfigurationSettings.GetConfig(
					ConfConstants._CONF_SECTION_NAME);

				return conf;
			}
		}

		private FileInfo BackendFile
		{
			get
			{
				string filename = ServiceBase.ResourceID;
				if ( (filename == null) || (filename.Length == 0) )
					throw new Exception("MOOCH:  Unknown resource.");

				FileInfo info = new FileInfo(
					string.Format("{0}/{1}", DirectoryConfiguration.StateDirectory, filename));
				if (!info.Exists)
				{
					using (Stream s = info.Create())
					{
					}

					info = new FileInfo(
						string.Format("{0}/{1}", DirectoryConfiguration.StateDirectory, filename));
				}
				return info;
			}
		}

		[WebMethod]
		[SoapDocumentMethod(ByteIOConstants.RBYTEIO_NS + "/write",
			 RequestNamespace=ByteIOConstants.RBYTEIO_NS,
			 ResponseNamespace=ByteIOConstants.RBYTEIO_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("writeResult", Namespace=ByteIOConstants.RBYTEIO_NS)]
		public BulkTransferInformation write(
			[XmlElement("start-offset", Namespace=ByteIOConstants.RBYTEIO_NS)] long startOffset, 
			[XmlElement("bytes-per-block", Namespace=ByteIOConstants.RBYTEIO_NS)] int bytesPerBlock, 
			[XmlElement("stride", Namespace=ByteIOConstants.RBYTEIO_NS)] long stride,
			[XmlElement("transfer-information", Namespace=ByteIOConstants.RBYTEIO_NS)]
				BulkTransferInformation transferInformation)
		{
			try
			{
				byte []data = ByteIOUtilities.receiveData(RequestSoapContext.Current, transferInformation);
				FileInfo file = BackendFile;

				lock (typeof(RandomByteIO))
				{
					using (FileStream stream = file.OpenWrite())
					{
						long offset = startOffset;
						int bufferOffset = 0;
						int bytesLeft = data.Length;

						while (bytesLeft > 0)
						{
							int bytesToWrite = (bytesLeft > bytesPerBlock) ? bytesPerBlock : bytesLeft;

							stream.Seek(offset, SeekOrigin.Begin);
							stream.Write(data, bufferOffset, bytesToWrite);
							bufferOffset += bytesToWrite;
							bytesLeft -= bytesToWrite;
							offset += stride;
						}
					}
				}

				return null;
			}
			catch (GeneratableException bge)
			{
				throw bge.generate(FaultGenerator, ServiceBase.EPR);
			}
		}

		[WebMethod]
		[SoapDocumentMethod(ByteIOConstants.RBYTEIO_NS + "/read",
			 RequestNamespace=ByteIOConstants.RBYTEIO_NS,
			 ResponseNamespace=ByteIOConstants.RBYTEIO_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("readData", Namespace=ByteIOConstants.RBYTEIO_NS)]
		public BulkTransferInformation read(
			[XmlElement("start-offset", Namespace=ByteIOConstants.RBYTEIO_NS)] long startOffset, 
			[XmlElement("bytes-per-block", Namespace=ByteIOConstants.RBYTEIO_NS)] int bytesPerBlock, 
			[XmlElement("num-blocks", Namespace=ByteIOConstants.RBYTEIO_NS)] int numBlocks, 
			[XmlElement("stride", Namespace=ByteIOConstants.RBYTEIO_NS)] long stride, 
			[XmlElement("transfer-information", Namespace=ByteIOConstants.RBYTEIO_NS)]
				BulkTransferInformation transferInformation)
		{
			try
			{
				int bytesToRead = bytesPerBlock * numBlocks;
				long offset = startOffset;

				byte []data = new byte[bytesToRead];
				int bufferOffset = 0;

				lock (typeof(RandomByteIO))
				{
					using (FileStream stream = BackendFile.OpenRead())
					{
						while (bytesToRead > 0)
						{
							stream.Seek(offset, SeekOrigin.Begin);
							int r = ByteIOUtilities.readFully(stream, data, bufferOffset, bytesPerBlock);
							bytesToRead -= r;
							bufferOffset += r;

							if (r < bytesPerBlock)
								break;

							offset += stride;
						}
					}
				}

				return ByteIOUtilities.sendData(transferInformation.TransferMechanism,
					ResponseSoapContext.Current, data, bufferOffset);
			}
			catch (GeneratableException bge)
			{
				throw bge.generate(FaultGenerator, ServiceBase.EPR);
			}
		}

		[WebMethod]
		[SoapDocumentMethod(ByteIOConstants.RBYTEIO_NS + "/append",
			 RequestNamespace=ByteIOConstants.RBYTEIO_NS,
			 ResponseNamespace=ByteIOConstants.RBYTEIO_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("appendResult", Namespace=ByteIOConstants.RBYTEIO_NS)]
		public BulkTransferInformation append(
			[XmlElement("transfer-information", Namespace=ByteIOConstants.RBYTEIO_NS)]
				BulkTransferInformation transferInformation)
		{
			try
			{
				byte []data = ByteIOUtilities.receiveData(RequestSoapContext.Current, transferInformation);
				FileInfo file = BackendFile;

				lock (typeof(RandomByteIO))
				{
					using (FileStream stream = file.OpenWrite())
					{
						stream.Seek(0, SeekOrigin.End);

						stream.Write(data, 0, data.Length);
					}
				}

				return null;
			}
			catch (GeneratableException bge)
			{
				throw bge.generate(FaultGenerator, ServiceBase.EPR);
			}
		}

		[WebMethod]
		[SoapDocumentMethod(ByteIOConstants.RBYTEIO_NS + "/truncAppend",
			 RequestNamespace=ByteIOConstants.RBYTEIO_NS,
			 ResponseNamespace=ByteIOConstants.RBYTEIO_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("truncAppendResult", Namespace=ByteIOConstants.RBYTEIO_NS)]
		public BulkTransferInformation truncAppend(
			[XmlElement("offset", Namespace=ByteIOConstants.RBYTEIO_NS)] long offset,
			[XmlElement("transfer-information", Namespace=ByteIOConstants.RBYTEIO_NS)]
				BulkTransferInformation transferInformation)
		{
			try
			{
				byte []data = ByteIOUtilities.receiveData(RequestSoapContext.Current, transferInformation);
				FileInfo file = BackendFile;

				lock (typeof(RandomByteIO))
				{
					using (FileStream stream = file.OpenWrite())
					{
						stream.SetLength(offset);
						stream.Seek(offset, SeekOrigin.Begin);

						stream.Write(data, 0, data.Length);
					}
				}
			
				return null;
			}
			catch (GeneratableException bge)
			{
				throw bge.generate(FaultGenerator, ServiceBase.EPR);
			}
		}

		private void deletedHandler(string resID)
		{
			lock (typeof(RandomByteIO))
			{
				BackendFile.Delete();
			}
		}

		protected override void portInit()
		{
			base.portInit ();

			ServiceBase.addDeletedListener(new WebServiceBase.DeletedDelegate(deletedHandler));
		}

	}
}