using System;

using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	[XmlRoot("UnsupportedTransferFault", Namespace=ByteIOConstants.BYTEIO_NS)]
	[XmlType("UnsupportedTransferFaultType", Namespace=ByteIOConstants.BYTEIO_NS)]
	public class UnsupportedTransferFault : BaseFaultType
	{
		public UnsupportedTransferFault()
		{
		}

		public UnsupportedTransferFault(string description)
			: base(description, null, null, null)
		{
		}
	}
}