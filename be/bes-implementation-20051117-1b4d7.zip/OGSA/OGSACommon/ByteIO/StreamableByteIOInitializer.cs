using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	[XmlRoot("streamable-byte-io-initializer", Namespace=ByteIOConstants.SBYTEIO_NS)]
	public class StreamableByteIOInitializer
	{
		private EndpointReferenceType _dataResource;

		public StreamableByteIOInitializer()
			: this(null)
		{
		}

		public StreamableByteIOInitializer(EndpointReferenceType dataResource)
		{
			_dataResource = dataResource;
		}

		[XmlElement("data-resource", Namespace=ByteIOConstants.SBYTEIO_NS)]
		public EndpointReferenceType DataResource
		{
			get
			{
				return _dataResource;
			}

			set
			{
				_dataResource = value;
			}
		}
	}
}