using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.ByteIO
{
	[XmlRoot("simple-transfer-data-block", Namespace=ByteIOConstants.BYTEIO_NS)]
	public class SimpleTransferDataBlock
	{
		private byte[] _data;

		public SimpleTransferDataBlock(byte []data, int length)
		{
			_data = new byte[length];
			Array.Copy(data, 0, _data, 0, length);
		}

		public SimpleTransferDataBlock(byte []data)
			: this(data, data.Length)
		{
		}

		public SimpleTransferDataBlock()
		{
		}

		[XmlElement("Data", Namespace=ByteIOConstants.BYTEIO_NS)]
		public byte[] Data
		{
			get
			{
				return _data;
			}

			set
			{
				_data = value;
			}
		}
	}
}