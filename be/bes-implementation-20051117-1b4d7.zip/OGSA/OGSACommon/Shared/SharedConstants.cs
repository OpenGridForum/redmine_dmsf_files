using System;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class SharedConstants
	{
		public const string _SHARED_NAMESPACE = "http://vcgr.virginia.edu";
	}
}