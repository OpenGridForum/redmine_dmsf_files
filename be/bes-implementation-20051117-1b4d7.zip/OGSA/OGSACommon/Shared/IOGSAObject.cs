using System;
using System.Xml;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Shared
{
	public interface IOGSAObject
	{
		EndpointReferenceType EPR
		{
			get;
		}

		XmlQualifiedName[] ImplementedPortTypes
		{
			get;
		}

		bool Implements(XmlQualifiedName portType);
		bool ImplementsDirectory { get; }
		bool ImplementsFile { get; }
		bool ImplementsFactory { get; }

		string TypeDescription { get; }
		string SizeDescription { get; }
	}
}