using System;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.ByteIO;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using UVa.GCG.WSRF.Common.WS.ResourceProperties;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class RandomByteIOObject : BaseOGSAObject
	{
		static private readonly XmlRootAttribute _rootForTransferMechs;
		static private readonly XmlRootAttribute _readRoot;
		static private readonly XmlRootAttribute _writeRoot;
		static private readonly XmlRootAttribute _sizeRoot;
		static private readonly XmlRootAttribute _createTimeRoot;
		static private readonly XmlRootAttribute _modTimeRoot;
		static private readonly XmlRootAttribute _accessTimeRoot;

		static RandomByteIOObject()
		{
			_rootForTransferMechs = new XmlRootAttribute("TransferMechanisms");
			_rootForTransferMechs.Namespace = ByteIOConstants.RBYTEIO_NS;

			_readRoot = new XmlRootAttribute("Readable");
			_readRoot.Namespace = ByteIOConstants.RBYTEIO_NS;

			_writeRoot = new XmlRootAttribute("Writeable");
			_writeRoot.Namespace = ByteIOConstants.RBYTEIO_NS;

			_sizeRoot = new XmlRootAttribute("Size");
			_sizeRoot.Namespace = ByteIOConstants.RBYTEIO_NS;

			_createTimeRoot = new XmlRootAttribute("CreateTime");
			_createTimeRoot.Namespace = ByteIOConstants.RBYTEIO_NS;
			
			_modTimeRoot = new XmlRootAttribute("ModificationTime");
			_modTimeRoot.Namespace = ByteIOConstants.RBYTEIO_NS;

			_accessTimeRoot = new XmlRootAttribute("AccessTime");
			_accessTimeRoot.Namespace = ByteIOConstants.RBYTEIO_NS;
		}

		private XmlQualifiedName _preferredTransferMechanism = null;
		private object _preferredTransferMechanismLock = new object();

		private XmlQualifiedName []_supportedTransferMechanisms = null;
		private object _transMechLock = new object();

		private XmlQualifiedName[] getSupportedTransferMechanisms()
		{
			GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
			GetResourcePropertyResponse resp = proxy.GetResourceProperty(
				new XmlQualifiedName("TransferMechanisms", ByteIOConstants.RBYTEIO_NS));

			XmlQualifiedName []qnames = new XmlQualifiedName[resp.Any.Count];
			for (int lcv = 0; lcv < qnames.Length; lcv++)
			{
				qnames[lcv] = (XmlQualifiedName)WSUtilities.Deserialize((XmlElement)(resp.Any[lcv]),
					typeof(XmlQualifiedName), _rootForTransferMechs);
			}

			return qnames;
		}

		internal RandomByteIOObject(IOGSAObject parent)
			: base(parent)
		{
		}

		public XmlQualifiedName[] SupportedTransferMechanisms
		{
			get
			{
				lock(_transMechLock)
				{
					if (_supportedTransferMechanisms == null)
						_supportedTransferMechanisms = getSupportedTransferMechanisms();
				}

				return _supportedTransferMechanisms;
			}
		}

		public long Size
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("Size", ByteIOConstants.RBYTEIO_NS));

				return (long)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(long), _sizeRoot);
			}
		}

		public bool CanRead
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("Readable", ByteIOConstants.RBYTEIO_NS));

				return (bool)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(bool), _readRoot);
			}
		}

		public bool CanWrite
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("Writeable", ByteIOConstants.RBYTEIO_NS));

				return (bool)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(bool), _writeRoot);
			}
		}

		public DateTime CreateTime
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("CreateTime", ByteIOConstants.RBYTEIO_NS));

				return (DateTime)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(DateTime), _createTimeRoot);
			}
		}
		
		public DateTime ModificationTime
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("ModificationTime", ByteIOConstants.RBYTEIO_NS));

				return (DateTime)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(DateTime), _modTimeRoot);	
			}
		}
		
		public DateTime AccessTime
		{
			get
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("AccessTime", ByteIOConstants.RBYTEIO_NS));

				return (DateTime)WSUtilities.Deserialize(resp.Any[0] as XmlElement,
					typeof(DateTime), _accessTimeRoot);
			}
		}

		public bool supportsTransferMechanism(XmlQualifiedName transMech)
		{
			foreach (XmlQualifiedName index in SupportedTransferMechanisms)
			{
				if (index.Equals(transMech))
					return true;
			}

			return false;
		}

		public XmlQualifiedName PreferredTransferMechanism
		{
			get
			{
				lock (_preferredTransferMechanismLock)
				{
					if (_preferredTransferMechanism == null)
					{
						if (supportsTransferMechanism(ByteIOConstants.TRANSFER_DIME))
							_preferredTransferMechanism = ByteIOConstants.TRANSFER_DIME;
						else
							_preferredTransferMechanism = ByteIOConstants.TRANSFER_SIMPLE;
					}
				}

				return _preferredTransferMechanism;
			}

			set
			{
				lock (_preferredTransferMechanismLock)
				{
					_preferredTransferMechanism = value;
				}
			}
		}

		public byte[] read(long startOffset, int numBlocks, int bytesPerBlock, long stride)
		{
			RandomByteIOProxy proxy = new RandomByteIOProxy(EPR);

			read r = new read();

			r.transferinformation = new BulkTransferInformation(PreferredTransferMechanism);
			r.bytesperblock = bytesPerBlock;
			r.numblocks = numBlocks;
			r.stride = stride;
			r.startoffset = startOffset;

			BulkTransferInformation transInfo = proxy.read(r).readData;
			return ByteIOUtilities.receiveData(proxy.ResponseSoapContext, transInfo);
		}

		public void write(byte []data, long startOffset, int bytesPerBlock, long stride)
		{
			RandomByteIOProxy proxy = new RandomByteIOProxy(EPR);

			write w = new write();
			w.bytesperblock = bytesPerBlock;
			w.startoffset = startOffset;
			w.stride = stride;
			w.transferinformation = ByteIOUtilities.sendData(PreferredTransferMechanism,
				proxy.RequestSoapContext, data, data.Length);

			proxy.write(w);
		}

		public void append(byte []data)
		{
			RandomByteIOProxy proxy = new RandomByteIOProxy(EPR);

			append a = new append();
			a.transferinformation = ByteIOUtilities.sendData(PreferredTransferMechanism,
				proxy.RequestSoapContext, data, data.Length);
			
			proxy.append(a);
		}

		public void truncAppend(byte []data, long offset)
		{
			RandomByteIOProxy proxy = new RandomByteIOProxy(EPR);

			truncAppend ta = new truncAppend();
			ta.transferinformation = ByteIOUtilities.sendData(PreferredTransferMechanism,
				proxy.RequestSoapContext, data, data.Length);
			ta.offset = offset;
			
			proxy.truncAppend(ta);
		}

		public override string TypeDescription
		{
			get
			{
				return "File";
			}
		}

		public override string SizeDescription
		{
			get
			{
				return ToSizeDescription(Size);
			}
		}
	}
}