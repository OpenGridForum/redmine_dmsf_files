using System;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.Factories;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.ResourceProperties;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class FactoryObject : BaseOGSAObject
	{
		static private readonly XmlRootAttribute _rootAttr;

		static FactoryObject()
		{
			_rootAttr = new XmlRootAttribute("service-eprs");
			_rootAttr.Namespace = FactoryConstants._FACT_NAMESPACE;
		}

		internal FactoryObject(IOGSAObject parent)
			: base(parent)
		{
		}

		public EndpointReferenceType instantiate()
		{
			WSRFNetFactoryProxy proxy = new WSRFNetFactoryProxy(EPR);

			return proxy.instantiate(new instantiate()).instance;
		}

		public void addServices(EndpointReferenceType []services)
		{
			WSRFNetFactoryProxy proxy = new WSRFNetFactoryProxy(EPR);

			addServices a = new addServices();
			a.services = services;

			proxy.addServices(a);
		}

		public EndpointReferenceType[] listServices()
		{
			GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(EPR);
			GetResourcePropertyResponse resp = proxy.GetResourceProperty(
				new XmlQualifiedName("service-eprs",
				FactoryConstants._FACT_NAMESPACE));

			EndpointReferenceType []eprs = new EndpointReferenceType[resp.Any.Count];

			int lcv = 0;
			foreach (XmlElement element in resp.Any)
			{
				eprs[lcv++] = (EndpointReferenceType)WSUtilities.Deserialize(
					element, typeof(EndpointReferenceType), _rootAttr);
			}

			return eprs;
		}

		public override string TypeDescription
		{
			get
			{
				return "Factory";
			}
		}
	}
}