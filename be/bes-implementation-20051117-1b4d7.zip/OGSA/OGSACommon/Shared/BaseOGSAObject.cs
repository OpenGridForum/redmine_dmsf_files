using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.ResourceProperties;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.ByteIO;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class BaseOGSAObject : IOGSAObject
	{
		private IOGSAObject _parent;

		protected BaseOGSAObject(IOGSAObject parent)
		{
			_parent = parent;
		}

		#region IOGSAObject Members

		public EndpointReferenceType EPR
		{
			get
			{
				return _parent.EPR;
			}
		}

		public XmlQualifiedName[] ImplementedPortTypes
		{
			get
			{
				return _parent.ImplementedPortTypes;
			}
		}

		public bool Implements(XmlQualifiedName portType)
		{
			return _parent.Implements(portType);
		}

		public bool ImplementsDirectory
		{
			get
			{
				return _parent.ImplementsDirectory;
			}
		}

		public bool ImplementsFile
		{
			get
			{
				return _parent.ImplementsFile;
			}
		}

		public bool ImplementsFactory
		{
			get
			{
				return _parent.ImplementsFactory;
			}
		}

		public virtual string TypeDescription
		{
			get
			{
				return _parent.TypeDescription;
			}
		}

		public virtual string SizeDescription
		{
			get
			{
				return _parent.SizeDescription;
			}
		}

		#endregion

		protected string ToSizeDescription(long size)
		{
//			if (size < 1024)
//				return string.Format("{0} bytes", size);
//			
//			size /= 1024;
//			if (size < 1024)
//				return string.Format("{0} KBytes", size);
//
//			size /= 1024;
//			if (size < 1024)
//				return string.Format("{0} MBytes", size);
//
//			size /= 1024;
//			if (size < 1024)
//				return string.Format("{0} GBytes", size);
//
//			size /= 1024;
//			return string.Format("{0} TBytes", size);

			return string.Format("{0:N0}", size);
		}
	}
}