using System;
using System.Text.RegularExpressions;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class PathPatternMatcher
	{
		private Regex _regex;

		public PathPatternMatcher(string pathPattern)
		{
			string regexString = "";
			int index;

			while (pathPattern.Length > 0)
			{
				index = pathPattern.IndexOfAny(new char[] { '\\', '*', '?', '[' });
				if (index < 0)
				{
					regexString += Regex.Escape(pathPattern);
					break;
				}

				regexString += Regex.Escape(pathPattern.Substring(0, index));
				char c = pathPattern[index];
				pathPattern = pathPattern.Substring(index + 1);
				switch (c)
				{
					case '\\' :
						if (pathPattern.Length == 0)
							regexString += @"\\";
						else
						{
							regexString += string.Format("\\{0}", pathPattern[0]);
							pathPattern = pathPattern.Substring(1);
						}
						break;
					case '*' :
						regexString += ".*";
						break;
					case '?' :
						regexString += ".?";
						break;
					case '[' :
						regexString += "[";
						break;
				}
			}

			_regex = new Regex(string.Format("^{0}$", regexString));
		}

		public bool matches(string input)
		{
			return _regex.IsMatch(input);
		}
	}
}