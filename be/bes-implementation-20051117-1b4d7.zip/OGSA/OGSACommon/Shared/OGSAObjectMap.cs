using System;
using System.Collections;

using System.Xml;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class OGSAObjectMap : Hashtable
	{
		public OGSAObjectMap()
			: base()
		{
		}

		public OGSAObjectMap(int capacity)
			: base(capacity)
		{
		}

		public IOGSAObject this[XmlQualifiedName portType]
		{
			get
			{
				return base[portType] as IOGSAObject;
			}
		}
	}
}