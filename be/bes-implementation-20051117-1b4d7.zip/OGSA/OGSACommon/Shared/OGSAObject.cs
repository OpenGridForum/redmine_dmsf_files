using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.ResourceLifetime;
using UVa.GCG.WSRF.Common.WS.ResourceProperties;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.ByteIO;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class OGSAObject : IOGSAObject
	{
		#region Statics

		static private readonly XmlRootAttribute _rootAttrForPortTypes;

		static OGSAObject()
		{
			_rootAttrForPortTypes = new XmlRootAttribute("WSResourceInterfaces");
			_rootAttrForPortTypes.Namespace = "http://www.ggf.org/namespaces/OGSABasicProfile-1.0.xsd";
		}

		static private IOGSAObject attach(OGSAObject baseObject, XmlQualifiedName portType)
		{
			if (portType == null)
				return baseObject;

			if (portType.Equals(ByteIOConstants._RBYTEIO_QNAME))
				return new RandomByteIOObject(baseObject);
			else if (portType.Equals(ContextConstants._DIR_PORTTYPE_QNAME))
				return new ContextObject(baseObject);
			else if (portType.Equals(FactoryConstants._FACT_PORTTYPE_QNAME))
				return new FactoryObject(baseObject);
			else
				return baseObject;
		}

		#endregion

		#region Private Members

		private EndpointReferenceType _epr;
		private XmlQualifiedName []_portTypes;
		private object _portTypeLock = new object();

		private XmlQualifiedName[] getPortTypes()
		{
			try
			{
				GetResourcePropertyBinding proxy = new GetResourcePropertyBinding(_epr);
				GetResourcePropertyResponse resp = proxy.GetResourceProperty(
					new XmlQualifiedName("WSResourceInterfaces",
					"http://www.ggf.org/namespaces/OGSABasicProfile-1.0.xsd"));

				XmlQualifiedName []qnames = new XmlQualifiedName[resp.Any.Count];
				for (int lcv = 0; lcv < qnames.Length; lcv++)
				{
					qnames[lcv] = (XmlQualifiedName)WSUtilities.Deserialize((XmlElement)(resp.Any[lcv]),
						typeof(XmlQualifiedName), _rootAttrForPortTypes);
				}

				return qnames;
			}
			catch (Exception)
			{
				return new XmlQualifiedName[0];
			}
		}

		#endregion

		#region Constructors

		public OGSAObject(EndpointReferenceType epr)
		{
			_epr = epr;
		}

		#endregion

		public XmlQualifiedName[] ImplementedPortTypes
		{
			get
			{
				lock (_portTypeLock)
				{
					if (_portTypes == null)
						_portTypes = getPortTypes();
				}

				return _portTypes;
			}
		}

		public EndpointReferenceType EPR
		{
			get
			{
				return _epr;
			}
		}

		public void destroy()
		{
			ImmediateResourceTerminationProxy proxy = new ImmediateResourceTerminationProxy(EPR);
			proxy.Destroy(new Destroy());
		}

		public bool Implements(XmlQualifiedName portType)
		{
			foreach (XmlQualifiedName pType in ImplementedPortTypes)
			{
				if (pType.Equals(portType))
					return true;
			}

			return false;
		}

		public bool ImplementsDirectory
		{
			get
			{
				return Implements(ContextConstants._DIR_PORTTYPE_QNAME);
			}
		}

		public bool ImplementsFile
		{
			get
			{
				return Implements(ByteIOConstants._RBYTEIO_QNAME);
			}
		}

		public bool ImplementsFactory
		{
			get
			{
				return Implements(FactoryConstants._FACT_PORTTYPE_QNAME);
			}
		}

		public string TypeDescription
		{
			get
			{
				return "<non-ogsa>";
			}
		}

		public string SizeDescription
		{
			get
			{
				return "";
			}
		}

		static public OGSAObjectMap attach(EndpointReferenceType epr, XmlQualifiedName []portTypes)
		{
			OGSAObjectMap map = new OGSAObjectMap(portTypes.Length);
			OGSAObject sObj = new OGSAObject(epr);

			foreach (XmlQualifiedName portType in portTypes)
			{
				map.Add(portType, attach(sObj, portType));
			}

			return map;
		}

		static public IOGSAObject attach(EndpointReferenceType epr, XmlQualifiedName portType)
		{
			OGSAObject sObj = new OGSAObject(epr);
			return attach(sObj, portType);
		}

		static public IOGSAObject attach(EndpointReferenceType epr)
		{
			OGSAObject sObj = new OGSAObject(epr);
			return sObj;
		}
	}
}