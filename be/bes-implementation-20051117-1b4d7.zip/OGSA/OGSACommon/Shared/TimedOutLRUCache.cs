using System;
using System.Collections;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class TimedOutLRUCache
	{
		private class CacheElement
		{
			private object _key;
			private object _data;
			private DateTime _timeout;

			public object Key
			{
				get
				{
					return _key;
				}
			}

			public object Data
			{
				get
				{
					return _data;
				}
			}

			public DateTime Timeout
			{
				get
				{
					return _timeout;
				}
			}

			public CacheElement(object key, object data, TimeSpan timeout)
			{
				_key = key;
				_data = data;
				_timeout = DateTime.Now + timeout;
			}

			public bool Equals(CacheElement element)
			{
				return _key.Equals(element.Key);
			}

			public override bool Equals(object obj)
			{
				return Equals((CacheElement)obj);	
			}

			public override int GetHashCode()
			{
				return _key.GetHashCode();
			}

		}

		private ArrayList _LRUTable;
		private ArrayList _timeoutTable;
		private Hashtable _lookupTable;

		private int _numEntries;
		private int _maxEntries;

		public TimedOutLRUCache(int maxEntries)
		{
			_maxEntries = maxEntries;

			_LRUTable = new ArrayList(maxEntries);
			_timeoutTable = new ArrayList(maxEntries);
			_lookupTable = new Hashtable(maxEntries);
		}

		public object lookup(object key)
		{
			cleanupTimeouts();

			CacheElement element = (CacheElement)_lookupTable[key];
			if (element == null)
				return null;

			_LRUTable.Remove(element);
			_LRUTable.Insert(0, element);

			return element.Data;
		}

		/* TODO */
		public void add(object key, object val, TimeSpan timeout)
		{
			cleanupTimeouts();

			CacheElement element = (CacheElement)_lookupTable[key];
			if (element != null)
			{
				_lookupTable.Remove(key);
				_timeoutTable.Remove(element);
				_LRUTable.Remove(element);
				_numEntries--;
			}

			if (_numEntries > _maxEntries)
				freeSlot();

			element = new CacheElement(key, val, timeout);
			_lookupTable[key] = element;
			_LRUTable.Insert(0, element);
			int first = 0;
			int last = _timeoutTable.Count - 1;

			while (true)
			{
				if (_timeoutTable.Count == 0)
				{
					_timeoutTable.Add(element);
					break;
				}

				CacheElement cfirst = (CacheElement)_timeoutTable[first];
				CacheElement clast = (CacheElement)_timeoutTable[last];

				if (first >= last)
				{
					_timeoutTable.Insert(first + 1, element);
					break;
				}

				if (element.Timeout < cfirst.Timeout)
				{
					_timeoutTable.Insert(first, element);
					break;
				} 
				else if (element.Timeout >= clast.Timeout)
				{
					_timeoutTable.Insert(last + 1, element);
					break;
				} 
				else
				{
					int middle = (first + last) >> 2;
					CacheElement cmiddle = (CacheElement)_timeoutTable[middle];
					if (element.Timeout < cmiddle.Timeout)
					{
						last = middle;
					} 
					else
					{
						first = middle;
					}
				}
			}

			_numEntries++;
		}

		public void clear()
		{
			_LRUTable.Clear();
			_timeoutTable.Clear();
			_lookupTable.Clear();
			_numEntries = 0;
		}

		private void cleanupTimeouts()
		{
			int lcv = 0;
			while (lcv < _timeoutTable.Count)
			{
				CacheElement element = (CacheElement)_timeoutTable[lcv];
				if (element.Timeout > DateTime.Now)
					break;
				lcv++;
			}

			if (lcv > 0)
			{
				for (int index = 0; index < lcv; index++)
				{
					CacheElement element  = (CacheElement)_timeoutTable[index];
					_LRUTable.Remove(_timeoutTable[index]);
					_lookupTable.Remove(element.Key);
				}

				_timeoutTable.RemoveRange(0, lcv);
				_numEntries -= lcv;
			}
		}

		private void freeSlot()
		{
			if (_LRUTable.Count > 0)
			{
				CacheElement element = (CacheElement)_LRUTable[0];
				_LRUTable.RemoveAt(0);
				_timeoutTable.Remove(element);
				_lookupTable.Remove(element.Key);
				_numEntries--;
			} 
			else
			{
				throw new Exception("Unexpected exception occurred.  Asked to free a slot from an empty cache.");
			}
		}
	}
}