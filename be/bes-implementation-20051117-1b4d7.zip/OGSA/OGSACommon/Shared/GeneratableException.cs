using System;

using System.Web.Services.Protocols;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;
using UVa.GCG.WSRF.Service.BaseFaults;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class GeneratableException : Exception, IGeneratableException
	{
		private BaseFaultType _fault;

		public GeneratableException(BaseFaultType bft)
		{
			_fault = bft;
		}

		#region IGeneratableException Members

		public SoapException generate(FaultGenerator generator, EndpointReferenceType originator)
		{
			_fault.Originator = originator;
			return generator.MakeFault(_fault, SoapException.ClientFaultCode);
		}

		#endregion
	}
}