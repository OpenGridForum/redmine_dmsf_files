using System;

using GBG.OGSA.OGSACommon.Directories;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class ContextObject : BaseOGSAObject
	{
		internal ContextObject(IOGSAObject parent)
			: base(parent)
		{
		}

		public ContextEntryMap lookup(string pattern)
		{
			BasicContextProxy proxy = new BasicContextProxy(EPR);

			lookup l = new lookup();
			l.pattern = pattern;

			return proxy.lookup(l).entrymap;
		}

		public bool add(string name, EndpointReferenceType epr)
		{
			BasicContextProxy proxy = new BasicContextProxy(EPR);

			add a = new add();
			a.name = name;
			a.epr = epr;

			return proxy.add(a).result;
		}

		public bool remove(string name)
		{
			BasicContextProxy proxy = new BasicContextProxy(EPR);

			remove r = new remove();
			r.name = name;

			return proxy.remove(r).result;
		}

		public override string TypeDescription
		{
			get
			{
				return "Directory";
			}
		}
	}
}