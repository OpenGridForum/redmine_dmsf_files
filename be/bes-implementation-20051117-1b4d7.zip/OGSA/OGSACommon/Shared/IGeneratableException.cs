using System;

using System.Web.Services.Protocols;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;
using UVa.GCG.WSRF.Service.BaseFaults;

namespace GBG.OGSA.OGSACommon.Shared
{
	public interface IGeneratableException
	{
		SoapException generate(FaultGenerator generator, EndpointReferenceType originator);
	}
}