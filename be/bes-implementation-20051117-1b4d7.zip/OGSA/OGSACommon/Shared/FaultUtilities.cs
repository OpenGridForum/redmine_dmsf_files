using System;

using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.AppDomainCaches;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

using System.Web.Services.Protocols;

namespace GBG.OGSA.OGSACommon.Shared
{
	public class FaultUtilities
	{
		private static Hashtable _knownFaults;
		private static XmlSerializer _serializer = null;

		static FaultUtilities()
		{
			_knownFaults = new Hashtable();
			Type type = typeof(BaseFaultType);
			RegisterFaultType(type);
			object[] attrs = type.GetCustomAttributes(typeof(XmlIncludeAttribute), false);
			foreach(XmlIncludeAttribute xia in attrs)
			{
				RegisterFaultType(xia.Type);
			}
		}

		public static void RegisterFaultType(Type type)
		{
			lock (typeof(FaultUtilities))
			{
				if(!type.IsSubclassOf(typeof(BaseFaultType)) && !type.Equals(typeof(BaseFaultType)))
					return;

				object[] attrs = type.GetCustomAttributes(typeof(XmlRootAttribute), true);
				XmlRootAttribute xra = (XmlRootAttribute)attrs[0]; // there will always be one since this type derives off of BaseFaultType
				XmlQualifiedName qName = new XmlQualifiedName(xra.ElementName, xra.Namespace);
				if(!_knownFaults.Contains(qName))
				{
					_knownFaults.Add(qName, type);
					_serializer = null;
				}
			}
		}

		static private XmlSerializer Serializer
		{
			get
			{
				lock (typeof(FaultUtilities))
				{
					if (_serializer == null)
						_serializer = getSerializer();

					return _serializer;
				}
			}
		}

		static private XmlSerializer getSerializer(XmlNode details)
		{
			lock (typeof(FaultUtilities))
			{
				foreach(XmlNode node in details.ChildNodes)
				{
					XmlElement element = node as XmlElement;
					if(element != null)
					{	// for now assume that only the first child element of the detail node can be a base fault.
						XmlQualifiedName qName = new XmlQualifiedName(element.LocalName,
							element.NamespaceURI);

						return SerializerCache.Instance[_knownFaults[qName] as Type];
					}
				}

				return null;
			}
		}

		static public BaseFaultType transform(SoapException se)
		{
			lock (typeof(FaultUtilities))
			{
				if((se != null) && (se.Detail != null) && IsBaseFault(se.Detail))
				{
					foreach(XmlNode node in se.Detail.ChildNodes)
					{
						XmlElement element = node as XmlElement;
						if(element != null)
						{
							XmlNodeReader xnr = new XmlNodeReader(element);
//							Console.WriteLine("Deserializing:\n{0}", element.OuterXml);
//							XmlSerializer ser = new XmlSerializer(typeof(GBG.OGSA.OGSACommon.ByteIO.UnsupportedTransferFaultType));
//							BaseFaultType rv = Serializer.Deserialize(xnr) as BaseFaultType;
//							BaseFaultType rv = ser.Deserialize(xnr) as BaseFaultType;
							BaseFaultType rv = getSerializer(se.Detail).Deserialize(xnr) as BaseFaultType;
							xnr.Close();
							return rv;
						}
					}
				}

				return null;
			}
		}

		static public bool IsBaseFault(XmlNode details)
		{
			lock (typeof(FaultUtilities))
			{
				foreach(XmlNode node in details.ChildNodes)
				{
					XmlElement element = node as XmlElement;
					if(element != null)
					{	// for now assume that only the first child element of the detail node can be a base fault.
						XmlQualifiedName qName = new XmlQualifiedName(element.LocalName,
							element.NamespaceURI);

						return _knownFaults.Contains(qName);
					}
				}

				return false;
			}
		}

		private static XmlSerializer getSerializer()
		{
			lock(typeof(FaultUtilities))
			{
				Type[] types = new Type[_knownFaults.Count - 1];
				int index = 0;
				foreach(Type type in _knownFaults.Values)
				{
					if(type.Equals(typeof(BaseFaultType)))
						continue;
					types[index++] = type;
					//					Console.Out.WriteLine("Adding \"{0}\".", type.FullName);
				}

				return new XmlSerializer(typeof(BaseFaultType), types);
			}
		}
	}
}