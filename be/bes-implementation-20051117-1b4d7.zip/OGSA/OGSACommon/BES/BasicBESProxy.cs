using System.Diagnostics;
using System.Xml.Serialization;
using System;
using System.Web.Services.Protocols;
using System.ComponentModel;
using System.Web.Services;
    
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.BES.JSDL;

namespace GBG.OGSA.OGSACommon.BES
{
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	[System.ComponentModel.DesignerCategoryAttribute("code")]
	[System.Web.Services.WebServiceBindingAttribute(Name="BasicBESServiceBinding", Namespace="http://schemas.ggf.org/bes/2005/11/bes/bindings")]
	public class BasicBESProxy : Microsoft.Web.Services2.WebServicesClientProtocol 
	{
		/// <remarks/>
		public BasicBESProxy(string URL) 
		{
			this.Url = URL;
		}

		public BasicBESProxy(EndpointReferenceType epr)
		{
			WSUtilities.setEPR(this, epr);
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/GetActivityStatus", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("GetActivityStatusResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public GetActivityStatusResponse GetActivityStatus([System.Xml.Serialization.XmlElementAttribute("GetActivityStatus", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] GetActivityStatus GetActivityStatus1) 
		{
			object[] results = this.Invoke("GetActivityStatus", new object[] {
																				 GetActivityStatus1});
			return ((GetActivityStatusResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginGetActivityStatus(GetActivityStatus GetActivityStatus1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("GetActivityStatus", new object[] {
																		  GetActivityStatus1}, callback, asyncState);
		}
        
		/// <remarks/>
		public GetActivityStatusResponse EndGetActivityStatus(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((GetActivityStatusResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/GetActivityJSDLDocuments", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("GetActivityJSDLDocumentsResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public GetActivityJSDLDocumentsResponse GetActivityJSDLDocuments([System.Xml.Serialization.XmlElementAttribute("GetActivityJSDLDocuments", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] GetActivityJSDLDocuments GetActivityJSDLDocuments1) 
		{
			object[] results = this.Invoke("GetActivityJSDLDocuments", new object[] {
																						GetActivityJSDLDocuments1});
			return ((GetActivityJSDLDocumentsResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginGetActivityJSDLDocuments(GetActivityJSDLDocuments GetActivityJSDLDocuments1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("GetActivityJSDLDocuments", new object[] {
																				 GetActivityJSDLDocuments1}, callback, asyncState);
		}
        
		/// <remarks/>
		public GetActivityJSDLDocumentsResponse EndGetActivityJSDLDocuments(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((GetActivityJSDLDocumentsResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/CreateActivityFromJSDL", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("CreateActivityFromJSDLResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public CreateActivityFromJSDLResponse CreateActivityFromJSDL([System.Xml.Serialization.XmlElementAttribute("CreateActivityFromJSDL", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] CreateActivityFromJSDL CreateActivityFromJSDL1) 
		{
			object[] results = this.Invoke("CreateActivityFromJSDL", new object[] {
																					  CreateActivityFromJSDL1});
			return ((CreateActivityFromJSDLResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginCreateActivityFromJSDL(CreateActivityFromJSDL CreateActivityFromJSDL1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("CreateActivityFromJSDL", new object[] {
																			   CreateActivityFromJSDL1}, callback, asyncState);
		}
        
		/// <remarks/>
		public CreateActivityFromJSDLResponse EndCreateActivityFromJSDL(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((CreateActivityFromJSDLResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/StopAcceptingNewActivities", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("StopAcceptingNewActivitiesResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public StopAcceptingNewActivitiesResponse StopAcceptingNewActivities([System.Xml.Serialization.XmlElementAttribute("StopAcceptingNewActivities", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] StopAcceptingNewActivities StopAcceptingNewActivities1) 
		{
			object[] results = this.Invoke("StopAcceptingNewActivities", new object[] {
																						  StopAcceptingNewActivities1});
			return ((StopAcceptingNewActivitiesResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginStopAcceptingNewActivities(StopAcceptingNewActivities StopAcceptingNewActivities1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("StopAcceptingNewActivities", new object[] {
																				   StopAcceptingNewActivities1}, callback, asyncState);
		}
        
		/// <remarks/>
		public StopAcceptingNewActivitiesResponse EndStopAcceptingNewActivities(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((StopAcceptingNewActivitiesResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/IsAcceptingNewActivities", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("IsAcceptingNewActivitiesResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public IsAcceptingNewActivitiesResponse IsAcceptingNewActivities([System.Xml.Serialization.XmlElementAttribute("IsAcceptingNewActivities", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] IsAcceptingNewActivities IsAcceptingNewActivities1) 
		{
			object[] results = this.Invoke("IsAcceptingNewActivities", new object[] {
																						IsAcceptingNewActivities1});
			return ((IsAcceptingNewActivitiesResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginIsAcceptingNewActivities(IsAcceptingNewActivities IsAcceptingNewActivities1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("IsAcceptingNewActivities", new object[] {
																				 IsAcceptingNewActivities1}, callback, asyncState);
		}
        
		/// <remarks/>
		public IsAcceptingNewActivitiesResponse EndIsAcceptingNewActivities(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((IsAcceptingNewActivitiesResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/RequestActivityStateChanges", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("RequestActivityStateChangesResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public RequestActivityStateChangesResponse RequestActivityStateChanges([System.Xml.Serialization.XmlElementAttribute("RequestActivityStateChanges", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] RequestActivityStateChanges RequestActivityStateChanges1) 
		{
			object[] results = this.Invoke("RequestActivityStateChanges", new object[] {
																						   RequestActivityStateChanges1});
			return ((RequestActivityStateChangesResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginRequestActivityStateChanges(RequestActivityStateChanges RequestActivityStateChanges1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("RequestActivityStateChanges", new object[] {
																					RequestActivityStateChanges1}, callback, asyncState);
		}
        
		/// <remarks/>
		public RequestActivityStateChangesResponse EndRequestActivityStateChanges(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((RequestActivityStateChangesResponse)(results[0]));
		}
        
		/// <remarks/>
		[System.Web.Services.Protocols.SoapDocumentMethodAttribute("http://schemas.ggf.org/bes/2005/11/bes/StartAcceptingNewActivities", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
		[return: System.Xml.Serialization.XmlElementAttribute("StartAcceptingNewActivitiesResponse", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public StartAcceptingNewActivitiesResponse StartAcceptingNewActivities([System.Xml.Serialization.XmlElementAttribute("StartAcceptingNewActivities", Namespace="http://schemas.ggf.org/bes/2005/11/bes")] StartAcceptingNewActivities StartAcceptingNewActivities1) 
		{
			object[] results = this.Invoke("StartAcceptingNewActivities", new object[] {
																						   StartAcceptingNewActivities1});
			return ((StartAcceptingNewActivitiesResponse)(results[0]));
		}
        
		/// <remarks/>
		public System.IAsyncResult BeginStartAcceptingNewActivities(StartAcceptingNewActivities StartAcceptingNewActivities1, System.AsyncCallback callback, object asyncState) 
		{
			return this.BeginInvoke("StartAcceptingNewActivities", new object[] {
																					StartAcceptingNewActivities1}, callback, asyncState);
		}
        
		/// <remarks/>
		public StartAcceptingNewActivitiesResponse EndStartAcceptingNewActivities(System.IAsyncResult asyncResult) 
		{
			object[] results = this.EndInvoke(asyncResult);
			return ((StartAcceptingNewActivitiesResponse)(results[0]));
		}
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class StartAcceptingNewActivitiesResponse 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class StartAcceptingNewActivities 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class RequestActivityStateChangesResponse 
	{
        
		/// <remarks/>
		[XmlElement("state-change-response", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public StateChangeRequestType[] statechangeresponse;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class RequestActivityStateChanges 
	{
        
		/// <remarks/>
		[XmlElement("state-change-request", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public StateChangeRequestType[] statechangerequest;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class IsAcceptingNewActivitiesResponse 
	{
        
		/// <remarks/>
		public bool response;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class IsAcceptingNewActivities 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class StopAcceptingNewActivitiesResponse 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class StopAcceptingNewActivities 
	{
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class CreateActivityFromJSDLResponse 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("activity-identifier")]
		public EndpointReferenceType activityidentifier;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class CreateActivityFromJSDL 
	{
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("job-description-document")]
		public JobDefinitionType jobdescriptiondocument;
        
		/// <remarks/>
		[System.Xml.Serialization.XmlElementAttribute("create-suspended")]
		public bool createsuspended;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class GetActivityJSDLDocumentsResponse 
	{
        
		/// <remarks/>
		[XmlElement("activity-jsdl-document", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public ActivityJSDLDocumentType[] activityjsdldocument;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class GetActivityJSDLDocuments 
	{
        
		/// <remarks/>
		[XmlElement("activity-identifier", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public EndpointReferenceType[] activityidentifier;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class GetActivityStatusResponse 
	{
        
		/// <remarks/>
		[XmlElement("activity-status", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public ActivityStatusType[] activitystatus;
	}
    
	/// <remarks/>
	[System.Xml.Serialization.XmlTypeAttribute(Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
	public class GetActivityStatus 
	{
        
		/// <remarks/>
		[XmlElement("activity-identifier", Namespace="http://schemas.ggf.org/bes/2005/11/bes")]
		public EndpointReferenceType[] activityidentifier;
	}
}