using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("JobDescription", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class JobDescriptionType
	{
		public JobDescriptionType()
			: this(null, null, null)
		{
		}

		public JobDescriptionType(JobIdentificationType jit)
			: this(jit, null, null)
		{
		}

		public JobDescriptionType(JobIdentificationType jit, ApplicationType app,
			DataStagingType []staging)
		{
			JobIdentification = jit;
			Application = app;
			DataStaging = staging;
			Resources = null;
			Any = null;
			AnyAttr = null;
		}

		public JobIdentificationType JobIdentification;
    
		public ApplicationType Application;
    
		public ResourcesType Resources;
    
		[XmlElement("DataStaging")]
		public DataStagingType[] DataStaging;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}