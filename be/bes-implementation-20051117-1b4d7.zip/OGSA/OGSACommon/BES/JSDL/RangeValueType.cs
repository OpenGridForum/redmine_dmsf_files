using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("DiskSpace", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class RangeValueType
	{
		public BoundaryType UpperBoundedRange;
		public BoundaryType LowerBoundedRange;
    
		[XmlElement("Exact")]
		public ExactType[] Exact;
    
		[XmlElement("Range")]
		public RangeType[] Range;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}