using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("OperatingSystemType", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class OperatingSystemTypeType
	{
		public OperatingSystemTypeEnumeration OperatingSystemName;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}