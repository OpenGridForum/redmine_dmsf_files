using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("OperatingSystem", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class OperatingSystem_Type
	{
		public OperatingSystemTypeType OperatingSystemType;
		public string OperatingSystemVersion;
		public string Description;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}