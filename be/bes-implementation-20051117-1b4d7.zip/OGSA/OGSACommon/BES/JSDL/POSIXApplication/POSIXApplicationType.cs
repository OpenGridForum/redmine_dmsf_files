using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("POSIXApplication", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class POSIXApplicationType
	{
		public FileNameType Executable;
    
		[XmlElement("Argument")]
		public ArgumentType[] Argument;
    
		public FileNameType Input;
		public FileNameType Output;
		public FileNameType Error;
		public DirectoryNameType WorkingDirectory;
    
		[XmlElement("Environment")]
		public EnvironmentType[] Environment;
    
		public LimitsType WallTimeLimit;
		public LimitsType FileSizeLimit;
		public LimitsType CoreDumpLimit;
		public LimitsType DataSegmentLimit;
		public LimitsType LockedMemoryLimit;
		public LimitsType MemoryLimit;
		public LimitsType OpenDescriptorsLimit;
		public LimitsType PipeSizeLimit;
		public LimitsType StackSizeLimit;
		public LimitsType CPUTimeLimit;
		public LimitsType ProcessCountLimit;
		public LimitsType VirtualMemoryLimit;
		public LimitsType ThreadCountLimit;
		public UserNameType UserName;
		public GroupNameType GroupName;
    
		[XmlAttribute(DataType="NCName")]
		public string name;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}