using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("Environment", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class EnvironmentType
	{
		[XmlAttribute(DataType="NCName")]
		public string name;
    
		[XmlAttribute(DataType="NCName")]
		public string filesystemName;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText]
		public string Value;
	}
}