using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("WallTimeLimit", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class LimitsType
	{
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText(DataType="nonNegativeInteger")]
		public string Value;
	}
}