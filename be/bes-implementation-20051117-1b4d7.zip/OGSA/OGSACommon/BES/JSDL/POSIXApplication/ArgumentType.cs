using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("Argument", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class ArgumentType
	{
		[XmlAttribute(DataType="NCName")]
		public string filesystemName;
    
		[XmlAnyAttribute]
		public System.Xml.XmlAttribute[] AnyAttr;
    
		[XmlText(DataType="normalizedString")]
		public string Value;
	}
}