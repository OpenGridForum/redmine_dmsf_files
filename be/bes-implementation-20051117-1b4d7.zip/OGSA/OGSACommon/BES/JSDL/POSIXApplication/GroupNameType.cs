using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("GroupName", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class GroupNameType
	{
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText]
		public string Value;
	}
}