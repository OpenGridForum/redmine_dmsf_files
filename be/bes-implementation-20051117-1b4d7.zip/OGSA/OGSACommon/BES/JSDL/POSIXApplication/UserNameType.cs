using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication
{
	/// <remarks/>
	[XmlType(Namespace=JSDLPosixConstants.JSDLPOSIX_NS)]
	[XmlRoot("UserName", Namespace=JSDLPosixConstants.JSDLPOSIX_NS, IsNullable=false)]
	public class UserNameType
	{
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText]
		public string Value;
	}
}