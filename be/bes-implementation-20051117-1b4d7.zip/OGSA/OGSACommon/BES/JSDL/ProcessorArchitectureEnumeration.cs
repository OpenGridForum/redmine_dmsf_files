using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("CPUArchitectureName", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public enum ProcessorArchitectureEnumeration 
	{
		sparc,
		powerpc,
		x86,
		x86_32,
		x86_64,
		parisc,
		mips,
		ia64,
		arm,
		other
	}
}