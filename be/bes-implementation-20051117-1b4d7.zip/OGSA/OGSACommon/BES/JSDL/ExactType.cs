using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	public class ExactType
	{
		[XmlAttribute]
		public System.Double epsilon;
    
		[XmlIgnore]
		public bool epsilonSpecified;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText]
		public System.Double Value;
	}
}