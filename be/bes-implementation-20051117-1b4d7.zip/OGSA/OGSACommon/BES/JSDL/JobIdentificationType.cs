using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("JobIdentification", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class JobIdentificationType
	{

		public string JobName;
		public string Description;
    
		[XmlElement("JobAnnotation")]
		public string[] JobAnnotation;
    
		[XmlElement("JobProject")]
		public string[] JobProject;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}