using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("Application", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class ApplicationType
	{
		public string ApplicationName;
		public string ApplicationVersion;
		public string Description;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}