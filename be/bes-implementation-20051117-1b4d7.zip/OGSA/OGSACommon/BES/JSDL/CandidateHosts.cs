using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("CandidateHosts", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class CandidateHostsType
	{
		[XmlElement("HostName")]
		public string[] HostName;
	}
}