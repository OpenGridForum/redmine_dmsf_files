using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	public class BoundaryType
	{
		[XmlAttribute]
		public bool exclusiveBound;
    
		[XmlIgnore]
		public bool exclusiveBoundSpecified;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
    
		[XmlText]
		public System.Double Value;
	}
}