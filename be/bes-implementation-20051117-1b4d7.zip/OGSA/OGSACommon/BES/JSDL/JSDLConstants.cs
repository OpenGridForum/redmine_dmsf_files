using System;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	public class JSDLConstants
	{
		public const string JSDL_NS = "http://schemas.ggf.org/jsdl/2005/11/jsdl";
	}
}