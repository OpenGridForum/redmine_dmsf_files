using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("FileSystemType", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public enum FileSystemTypeEnumeration
	{
		swap,
		temporary,
		spool,
		normal
	}
}