using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	public class RangeType
	{
		public BoundaryType LowerBound;
		public BoundaryType UpperBound;

		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}