using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("CPUArchitecture", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class CPUArchitectureType
	{
		public ProcessorArchitectureEnumeration CPUArchitectureName;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}