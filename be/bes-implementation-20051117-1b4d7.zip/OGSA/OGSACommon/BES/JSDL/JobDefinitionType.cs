using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("JobDefinition", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class JobDefinitionType
	{
		public JobDefinitionType()
			: this(null, null)
		{
		}

		public JobDefinitionType(JobDescriptionType jdt)
			: this(jdt, null)
		{
		}

		public JobDefinitionType(JobDescriptionType jdt, string _id)
		{
			Any = null;
			id = _id;
			AnyAttr = null;
			JobDescription = jdt;
		}

		public JobDescriptionType JobDescription;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAttribute(DataType="ID")]
		public string id;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}