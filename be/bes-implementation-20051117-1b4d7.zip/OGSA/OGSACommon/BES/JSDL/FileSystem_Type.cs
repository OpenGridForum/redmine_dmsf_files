using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("FileSystem", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class FileSystem_Type
	{
		public FileSystemTypeEnumeration FileSystemType;
    
		[XmlIgnore]
		public bool FileSystemTypeSpecified;
    
		public string Description;
		public string MountPoint;
		public RangeValueType DiskSpace;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAttribute(DataType="NCName")]
		public string name;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}