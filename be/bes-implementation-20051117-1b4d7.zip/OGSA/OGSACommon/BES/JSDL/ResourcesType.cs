using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES.JSDL
{
	[XmlType(Namespace=JSDLConstants.JSDL_NS)]
	[XmlRoot("Resources", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
	public class ResourcesType
	{
		[XmlArrayItem("HostName", IsNullable=false)]
		public string[] CandidateHosts;
    
		[XmlElement("FileSystem")]
		public FileSystem_Type[] FileSystem;
    
		public bool ExclusiveExecution;
    
		[XmlIgnore]
		public bool ExclusiveExecutionSpecified;
    
		public OperatingSystem_Type OperatingSystem;
		public CPUArchitectureType CPUArchitecture;
		public RangeValueType IndividualCPUSpeed;
		public RangeValueType IndividualCPUTime;
		public RangeValueType IndividualCPUCount;
		public RangeValueType IndividualNetworkBandwidth;
		public RangeValueType IndividualPhysicalMemory;
		public RangeValueType IndividualVirtualMemory;
		public RangeValueType IndividualDiskSpace;
		public RangeValueType TotalCPUTime;
		public RangeValueType TotalCPUCount;
		public RangeValueType TotalPhysicalMemory;
		public RangeValueType TotalVirtualMemory;
		public RangeValueType TotalDiskSpace;
		public RangeValueType TotalResourceCount;
    
		[XmlAnyElement]
		public XmlElement[] Any;
    
		[XmlAnyAttribute]
		public XmlAttribute[] AnyAttr;
	}
}