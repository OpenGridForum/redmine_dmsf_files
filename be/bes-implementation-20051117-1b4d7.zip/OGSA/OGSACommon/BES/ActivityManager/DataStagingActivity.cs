using System;

using System.IO;
using System.Net;

using GBG.OGSA.OGSACommon.BES;
using GBG.OGSA.OGSACommon.BES.JSDL;

namespace GBG.OGSA.OGSACommon.BES.ActivityManager
{
	public class DataStagingActivity
	{
		private const int _BLOCK_SIZE = 1024 * 4;

		private DirectoryInfo _stateDirectory;
		private DataStagingType _stagingOperation;
		private DataStagingStateEnumeration _lastState;
		private bool _lastStateSpecified;
		private DataStagingStateEnumeration _stagingState;

		public DataStagingActivity(DataStagingType stagingOperation, DirectoryInfo stateDirectory)
		{
			_stateDirectory = stateDirectory;
			_stagingOperation = stagingOperation;
			_lastState = _stagingState = DataStagingStateEnumeration.New;
			_lastStateSpecified = false;
		}

		public DataStagingStateEnumeration StagingState
		{
			get
			{
				return _stagingState;
			}

			set
			{
				_lastState = _stagingState;
				_lastStateSpecified = true;
				_stagingState = value;
			}
		}

		public DataStagingType StagingOperation
		{
			get
			{
				return _stagingOperation;
			}
		}

		public DataStageStatusType DataStageStatus
		{
			get
			{
				DataStageStatusType ret = new DataStageStatusType();
				ret.id = _stagingOperation.FileName;
				ret.laststate = _lastState;
				ret.laststateSpecified = _lastStateSpecified;
				ret.state = StagingState;
				ret.stateSpecified = true;

				return ret;
			}
		}

		public void stageIn()
		{
			if (_stagingState == DataStagingStateEnumeration.Exception)
				return;

			try
			{
				StagingState = DataStagingStateEnumeration.StagingIn;
				copyIn();
				StagingState = DataStagingStateEnumeration.Waiting;
			}
			catch (Exception)
			{
				// TODO: Do something better with this exception.
				StagingState = DataStagingStateEnumeration.Exception;
				throw;
			}
		}

		public void stageOut()
		{
			if (_stagingState == DataStagingStateEnumeration.Exception)
				return;

			try
			{
				StagingState = DataStagingStateEnumeration.StagingOut;
				copyOut();
				StagingState = DataStagingStateEnumeration.Done;
			}
			catch (Exception)
			{
				// TODO: Do something better with this exception.
				StagingState = DataStagingStateEnumeration.Exception;
				throw;
			}
		}

		public void cleanup()
		{
			if (_stagingOperation.DeleteOnTerminationSpecified && _stagingOperation.DeleteOnTermination)
				(new FileInfo(Path.Combine(_stateDirectory.FullName, _stagingOperation.FileName))).Delete();
		}

		private void copyIn()
		{
			FileMode mode;

			switch (_stagingOperation.CreationFlag)
			{
				case CreationFlagEnumeration.append :
					mode = FileMode.Append;
					break;

				case CreationFlagEnumeration.overwrite :
					mode = FileMode.Create;
					break;

				case CreationFlagEnumeration.dontOverwrite :
				default :
					mode = FileMode.Truncate;
					break;
			}

			byte []block = new byte[_BLOCK_SIZE];

			if (_stagingOperation.Source == null || _stagingOperation.Source.URI == null ||
				_stagingOperation.Source.URI.Length == 0)
				return;

			WebRequest request = WebRequest.Create(new Uri(_stagingOperation.Source.URI));
			using (WebResponse response = request.GetResponse())
			{
				using (Stream inputStream = response.GetResponseStream())
				{
					using (Stream outputStream = new FileStream(
							   Path.Combine(_stateDirectory.FullName, _stagingOperation.FileName),
							   mode))
					{
						int bytesRead;

						while ( (bytesRead = inputStream.Read(block, 0, _BLOCK_SIZE)) > 0)
							outputStream.Write(block, 0, bytesRead);
					}
				}
			}
		}

		private void copyOut()
		{
			byte []block = new byte[_BLOCK_SIZE];

			if (_stagingOperation.Target == null || _stagingOperation.Target.URI == null ||
				_stagingOperation.Target.URI.Length == 0)
				return;

			WebRequest request = WebRequest.Create(new Uri(_stagingOperation.Target.URI));
			try
			{
				using (Stream inputStream = new FileStream(
						   Path.Combine(_stateDirectory.FullName, _stagingOperation.FileName),
						   FileMode.Open))
				{
					using (Stream outputStream = request.GetRequestStream())
					{
						int bytesRead;

						while ( (bytesRead = inputStream.Read(block, 0, _BLOCK_SIZE)) > 0)
							outputStream.Write(block, 0, bytesRead);
					}
				}
			}
			finally
			{
				request.GetResponse().Close();
			}
		}
	}
}