using System;
using System.Diagnostics;

using System.IO;

using System.Threading;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.BES.JSDL;
using GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication;

using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

using UVa.GCG.WSRF.Service.BaseFaults;

namespace GBG.OGSA.OGSACommon.BES.ActivityManager
{
	public class ActivityThread
	{
		private Process _proc = null;
		private GeneratableException _fault = null;
		private string _activityKey;
		private bool _startSuspended;
		private Thread _thread;
		private JobDefinitionType _jobDescription;
		private POSIXApplicationType _posixDescription;
		private OverallStateEnumeration _lastState;
		private bool _lastStateSpecified = false;
		private OverallStateEnumeration _currentState;
		private DataStagingActivity []_stagingActivities;
		private DirectoryInfo _baseStateDir;
		private DirectoryInfo _workingStateDir = null;

		public ActivityThread(string activityKey, JobDefinitionType jobDescription, bool startSuspended,
			DirectoryInfo baseStateDir)
		{
			_baseStateDir = baseStateDir;
			_activityKey = activityKey;
			_startSuspended = startSuspended;
			_jobDescription = jobDescription;
			_posixDescription = getPosixApp(jobDescription);

			_workingStateDir = new DirectoryInfo(Path.Combine(_baseStateDir.FullName, _activityKey));
			_workingStateDir.Create();

			if (jobDescription.JobDescription.DataStaging != null)
				_stagingActivities = new DataStagingActivity[
					jobDescription.JobDescription.DataStaging.Length];
			else
				_stagingActivities = new DataStagingActivity[0];

			for (int lcv = 0; lcv < _stagingActivities.Length; lcv++)
				_stagingActivities[lcv] = new DataStagingActivity(
					jobDescription.JobDescription.DataStaging[lcv], _workingStateDir);

			_lastStateSpecified = false;
			_lastState = _currentState = OverallStateEnumeration.New;

			_thread = new Thread(new ThreadStart(run));
			_thread.IsBackground = true;
		}

		public void start()
		{
			_thread.Start();
		}

		public ActivityStatusType getActivityStatus()
		{
			ActivityStatusType ret = new ActivityStatusType();
			ret.OverallStatus = new OverallStatusType();
			ret.OverallStatus.laststate = _lastState;
			ret.OverallStatus.laststateSpecified = _lastStateSpecified;
			ret.OverallStatus.otherstate = null;
			ret.OverallStatus.state = _currentState;
			ret.OverallStatus.stateSpecified = true;
			ret.StagingStatus = new DataStageStatusType[_stagingActivities.Length];

			for (int lcv = 0; lcv < _stagingActivities.Length; lcv++)
			{
				ret.StagingStatus[lcv] = _stagingActivities[lcv].DataStageStatus;
			}

			return ret;
		}

		public StateChangeResponseType requestActivityStageChange(
			RequestedStateChangeType requestedStateChange)
		{
			StateChangeResponseType scrt = new StateChangeResponseType();
			scrt.responseSpecified = true;

			if (requestedStateChange.fromSpecified)
			{
				if (requestedStateChange.from != _currentState)
				{
					scrt.response = StateChangeResponseEnumeration.Failed;
				
					return scrt;
				}
			}

			// TODO -- This isn't particularly good, but for now it'll do.
			switch (requestedStateChange.to)
			{
				case OverallStateEnumeration.Terminated :
					_proc.Kill();
					CurrentState = OverallStateEnumeration.Terminated;
					scrt.response = StateChangeResponseEnumeration.Succeeded;
					break;

				default :
					scrt.response = StateChangeResponseEnumeration.Failed;
					break;
			}

			return scrt;
		}

		public ActivityJSDLDocumentType getActivityJSDLDocumentType()
		{
			ActivityJSDLDocumentType ret = new ActivityJSDLDocumentType();
			ret.JobDescription = _jobDescription;

			return ret;
		}

		private void run()
		{
			try
			{
				CurrentState = OverallStateEnumeration.New;
				initialize();
				CurrentState = OverallStateEnumeration.Staging_In;
				stageIn();
				CurrentState = OverallStateEnumeration.ExecutionPending;
				startRunning();
				CurrentState = OverallStateEnumeration.Running;
				waitForJobComplete();
				CurrentState = OverallStateEnumeration.StagingOut;
				stageOut();
				CurrentState = OverallStateEnumeration.CleaningUp;
				cleanUp();
				CurrentState = OverallStateEnumeration.Done;
			}
			catch (GeneratableException bge)
			{
				CurrentState = OverallStateEnumeration.Exception;
				_fault = bge;
			}
			catch (Exception e)
			{
				CurrentState = OverallStateEnumeration.Exception;
				_fault = new GeneratableException(new BackendFault(e.ToString()));
			}
		}

		static private POSIXApplicationType getPosixApp(JobDefinitionType jsdl)
		{
			if ( (jsdl == null)	||
				(jsdl.JobDescription == null) ||
				(jsdl.JobDescription.Application == null) ||
				(jsdl.JobDescription.Application.Any == null) )
			{
				throw new GeneratableException(new UnsupportedFeatureFault());
			}

			foreach (XmlElement element in jsdl.JobDescription.Application.Any)
			{
				XmlQualifiedName qname = new XmlQualifiedName(element.LocalName, element.NamespaceURI);

				if (qname.Equals(
					new XmlQualifiedName("POSIXApplication", JSDLPosixConstants.JSDLPOSIX_NS)))
				{
					return (POSIXApplicationType)WSUtilities.Deserialize(element,
						typeof(POSIXApplicationType));
				}
			}

			throw new GeneratableException(new UnsupportedFeatureFault());
		}

		private void initialize()
		{
			// TODO -- Any initialization?
		}

		private void stageIn()
		{
			foreach (DataStagingActivity activity in _stagingActivities)
			{
				activity.stageIn();
			}
		}

		private void startRunning()
		{
			_proc = new Process();
			string arg = null;

			foreach (ArgumentType argument in _posixDescription.Argument)
			{
				if (arg == null)
					arg = string.Format("\"{0}\"", argument.Value);
				else
					arg += string.Format(" \"{0}\"", argument.Value);
			}

			ProcessStartInfo startInfo = new ProcessStartInfo(_posixDescription.Executable.Value,
				arg);
			startInfo.CreateNoWindow = true;
			startInfo.ErrorDialog = false;
			startInfo.RedirectStandardError = false;
			startInfo.RedirectStandardInput = false;
			startInfo.RedirectStandardOutput = false;
			startInfo.UseShellExecute = false;
			startInfo.WorkingDirectory = _workingStateDir.FullName;

			_proc.StartInfo = startInfo;
			
			_proc.EnableRaisingEvents = true;
			_proc.Exited += new EventHandler(_proc_Exited);

			_proc.Start();
		}

		private void waitForJobComplete()
		{
			while (!_proc.HasExited)
			{
				Monitor.Enter(this);
				try
				{
					Monitor.Wait(this);
				}
				finally
				{
					Monitor.Exit(this);
				}
			}
		}

		private void stageOut()
		{
			foreach (DataStagingActivity activity in _stagingActivities)
			{
				activity.stageOut();
			}
		}

		private void cleanUp()
		{
			foreach (DataStagingActivity activity in _stagingActivities)
			{
				activity.cleanup();
			}

			if (_workingStateDir.GetFileSystemInfos().Length == 0)
				_workingStateDir.Delete(false);
		}

		private OverallStateEnumeration CurrentState
		{
			set
			{
				_lastState = _currentState;
				_lastStateSpecified = true;
				_currentState = value;
			}
		}

		private void _proc_Exited(object sender, EventArgs e)
		{
			Monitor.Enter(this);
			try
			{
				Monitor.PulseAll(this);
			}
			finally
			{
				Monitor.Exit(this);
			}
		}
	}
}