using System;
using System.Collections;

using System.IO;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.BES.JSDL;
using GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication;

using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS;

using UVa.GCG.WSRF.Service.BaseFaults;

namespace GBG.OGSA.OGSACommon.BES.ActivityManager
{
	public class ActivityManager
	{
		static private ActivityManager _instance = null;

		private Hashtable _activityTable = new Hashtable();

		static ActivityManager()
		{
			_instance = new ActivityManager();
		}

		private ActivityManager()
		{
		}

		static public ActivityManager Instance
		{
			get
			{
				return _instance;
			}
		}

		public string create(string baseDir, JobDefinitionType jobDescription, bool createInSuspendedState)
		{
			string activityKey = Guid.NewGuid().ToString();

			ActivityThread activity = new ActivityThread(activityKey, jobDescription,
				createInSuspendedState, new DirectoryInfo(baseDir));

			lock (this)
			{
				_activityTable[activityKey] = activity;
			}

			activity.start();

			return activityKey;
		}

		public ActivityStatusType getActivityStatus(string activityKey)
		{
			ActivityThread thread;

			lock (this)
			{
				thread = (ActivityThread)_activityTable[activityKey];
			}

			if (thread == null)
			{
				ActivityStatusType ret = new ActivityStatusType();
				ret.OverallStatus = new OverallStatusType();
				ret.OverallStatus.laststateSpecified = false;
				ret.OverallStatus.otherstate = null;
				ret.OverallStatus.stateSpecified = true;
				ret.OverallStatus.state = OverallStateEnumeration.Unknown;

				return ret;
			}

			return thread.getActivityStatus();
		}

		public StateChangeResponseType requestActivityStateChange(string activityKey,
			RequestedStateChangeType requestedStateChange)
		{
			ActivityThread thread;

			lock (this)
			{
				thread = (ActivityThread)_activityTable[activityKey];
			}

			if (thread == null)
			{
				StateChangeResponseType scrt = new StateChangeResponseType();
				scrt.response = StateChangeResponseEnumeration.Failed;
				scrt.responseSpecified = true;

				return scrt;
			}

			return thread.requestActivityStageChange(requestedStateChange);
		}

		public ActivityJSDLDocumentType getActivityJSDLDocument(string activityKey)
		{
			ActivityThread thread;

			lock (this)
			{
				thread = (ActivityThread)_activityTable[activityKey];
			}

			if (thread == null)
				return new ActivityJSDLDocumentType();

			return thread.getActivityJSDLDocumentType();
		}
	}
}