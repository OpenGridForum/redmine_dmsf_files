using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("overall-state-enumeration", Namespace=BESConstants.BES_NS)]
	public enum OverallStateEnumeration 
	{
		New,
		Pending,
		Staging_In,
		ExecutionPending,
		Running,
		ExecutionComplete,
		StagingOut,
		CleaningUp,
		Exception,
		Suspended,
		Unknown,
		Other,
		Done,
		ShuttingDown,
		Terminated
	}
}