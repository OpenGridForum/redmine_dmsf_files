using System;

using System.Xml;

namespace GBG.OGSA.OGSACommon.BES
{
	public class BESConstants
	{
		public const string BES_NS = "http://schemas.ggf.org/bes/2005/11/bes";
		public const string BES_PORT_NAME = "BES";

		static public readonly XmlQualifiedName BES_PORT_TYPE_QNAME =
			new XmlQualifiedName(BES_PORT_NAME, BES_NS);
	}
}