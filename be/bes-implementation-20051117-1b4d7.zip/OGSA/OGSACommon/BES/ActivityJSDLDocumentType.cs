using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.BES.JSDL;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("activity-jsdl-document-type", Namespace=BESConstants.BES_NS)]
	public class ActivityJSDLDocumentType
	{
		[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
		public EndpointReferenceType ActivityIdentifier;

		[XmlElement("job-description", Namespace=BESConstants.BES_NS)]
		public JobDefinitionType JobDescription;
	}
}