using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("data-stage-status-type", Namespace=BESConstants.BES_NS)]
	public class DataStageStatusType 
	{
		[XmlAttribute]
		public string id;
    
		[XmlAttribute]
		public DataStagingStateEnumeration state;
    
		[XmlIgnore]
		public bool stateSpecified;
    
		[XmlAttribute]
		public DataStagingStateEnumeration laststate;
    
		[XmlIgnore]
		public bool laststateSpecified;
	}
}