using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("requested-state-change-type", Namespace=BESConstants.BES_NS)]
	public class RequestedStateChangeType
	{
		[XmlAttribute]
		public OverallStateEnumeration from;
    
		[XmlIgnore]
		public bool fromSpecified;

		[XmlAttribute]
		public OverallStateEnumeration to;
    
		[XmlIgnore]
		public bool toSpecified;
	}
}