using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("state-change-response-type", Namespace=BESConstants.BES_NS)]
	public class StateChangeResponseType
	{
		[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
		public EndpointReferenceType ActivityIdentifier;

		[XmlAttribute]
		public StateChangeResponseEnumeration response;

		[XmlIgnore]
		public bool responseSpecified;
	}
}