using System;

using System.Configuration;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;

namespace GBG.OGSA.OGSACommon.BES
{
	public class BasicBESConfHandler : IConfigurationSectionHandler
	{
		#region IConfigurationSectionHandler Members

		public object Create(object parent, object configContext, System.Xml.XmlNode section)
		{
			XmlRootAttribute root = new XmlRootAttribute("uva.gbg.ogsa.bes");
			return WSUtilities.Deserialize((XmlElement)section, typeof(BasicBESConf), root);
		}

		#endregion
	}
}