using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("data-staging-state-enumeration", Namespace=BESConstants.BES_NS)]
	public enum DataStagingStateEnumeration 
	{
		New,
		Pending,
		StagingIn,
		Waiting,
		StagingOut,
		Done,
		Suspended,
		Blocked,
		Exception,
		Terminated,
		NotKnown
	}
}