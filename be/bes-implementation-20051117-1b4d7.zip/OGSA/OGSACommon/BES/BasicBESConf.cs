using System;

using System.IO;

using System.Xml;
using System.Xml.Serialization;

using GBG.OGSA.OGSACommon.Directories;

namespace GBG.OGSA.OGSACommon.BES
{
	public class BasicBESConf
	{
		private string _directory;
		private string _fromAddress;
		private string _SMTPServer;
		private string _subjectPattern;
		private string _bodyPattern;

		[XmlElement("state-directory")]
		public string StateDirectory
		{
			get
			{
				return _directory;
			}

			set
			{
				_directory = value;
			}
		}

		[XmlElement("mailto-from-address")]
		public string FromAddress
		{
			get
			{
				return _fromAddress;
			}

			set
			{
				_fromAddress = value;
			}
		}

		[XmlElement("mailto-smtp-server")]
		public string SMTPServer
		{
			get
			{
				return _SMTPServer;
			}

			set
			{
				_SMTPServer = value;
			}
		}

		[XmlElement("mailto-subject-pattern")]
		public string SubjectPattern
		{
			get
			{
				return _subjectPattern;
			}

			set
			{
				_subjectPattern = value;
			}
		}

		[XmlElement("mailto-body-pattern")]
		public string BodyPattern
		{
			get
			{
				return _bodyPattern;
			}

			set
			{
				_bodyPattern = value;
			}
		}

		public BasicBESConf()
		{
		}
	}
}