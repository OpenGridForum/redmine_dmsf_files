using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	public class EPRUtilities
	{
		public const string _KEY_NAME = "activitiy-key";
		public const string _KEY_NS = BESConstants.BES_NS;

		static public readonly XmlQualifiedName _KEY_QNAME =
			new XmlQualifiedName(_KEY_NAME, _KEY_NS);

		static private XmlRootAttribute _KEY_ROOT;

		static EPRUtilities()
		{
			_KEY_ROOT = new XmlRootAttribute(_KEY_NAME);
			_KEY_ROOT.Namespace = _KEY_NS;
		}

		static public EndpointReferenceType makeSubResource(EndpointReferenceType container,
			string key)
		{
			XmlElement keyElement = WSUtilities.Serialize(key, _KEY_ROOT);
			XmlElement []parms;

			if (container.ReferenceProperties == null || container.ReferenceProperties.Any == null)
				parms = new XmlElement[]
					{
						keyElement
					};
			else
			{
				int lcv;
				parms = new XmlElement[container.ReferenceProperties.Any.Length + 1];
				for (lcv = 0; lcv < container.ReferenceProperties.Any.Length; lcv++)
					parms[lcv] = container.ReferenceProperties.Any[lcv];
				parms[lcv] = keyElement;
			}

			ReferencePropertiesType rpt = new ReferencePropertiesType(parms);
			return new EndpointReferenceType(
				container.Address, rpt, container.PortType, container.ServiceName,
				container.Any, container.AnyAttr);
		}

		static public string extractActivityKey(EndpointReferenceType epr)
		{
			if ( (epr == null) || 
				(epr.ReferenceProperties == null) || 
				(epr.ReferenceProperties.Any == null) )
				return null;

			foreach (XmlElement element in epr.ReferenceProperties.Any)
			{
				XmlQualifiedName qname = new XmlQualifiedName(element.LocalName, element.NamespaceURI);

				if (qname.Equals(_KEY_QNAME))
					return (string)(WSUtilities.Deserialize(element, typeof(string), _KEY_ROOT));
			}

			return null;
		}
	}
}