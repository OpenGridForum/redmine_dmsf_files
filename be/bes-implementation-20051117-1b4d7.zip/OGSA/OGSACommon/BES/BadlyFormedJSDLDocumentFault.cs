using System;

using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlRoot("NotAcceptingNewActivitiesFault", Namespace=BESConstants.BES_NS)]
	[XmlType("NotAcceptingNewActivitiesFaultType", Namespace=BESConstants.BES_NS)]
	public class BadlyFormedJSDLDocumentFault : BaseFaultType
	{
		public BadlyFormedJSDLDocumentFault()
		{
		}

		public BadlyFormedJSDLDocumentFault(string description)
			: base(description, null, null, null)
		{
		}
	}
}