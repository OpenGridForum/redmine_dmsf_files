﻿using System;

using System.Xml;
using System.Xml.Serialization;

public class JSDLConstants
{
	public const string JSDL_NS = "http://schemas.ggf.org/jsdl/2005/11/jsdl";
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("JobDefinition", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class JobDefinitionType
{
	public JobDescriptionType JobDescription;
    
    [XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAttribute(DataType="ID")]
    public string id;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("JobDescription", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class JobDescriptionType
{
	public JobIdentificationType JobIdentification;
    
    public ApplicationType Application;
    
    public ResourcesType Resources;
    
	[XmlElement("DataStaging")]
    public DataStagingType[] DataStaging;
    
    [XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("JobIdentification", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class JobIdentificationType
{

	public string JobName;
    public string Description;
    
	[XmlElement("JobAnnotation")]
    public string[] JobAnnotation;
    
    [XmlElement("JobProject")]
    public string[] JobProject;
    
    [XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("Source", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class SourceTargetType
{
    [XmlElement(DataType="anyURI")]
    public string URI;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("DataStaging", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class DataStagingType
{

	public string FileName;
    
	[XmlElement(DataType="NCName")]
    public string FilesystemName;
    
    public CreationFlagEnumeration CreationFlag;
    
    public bool DeleteOnTermination;
    
    [XmlIgnore]
    public bool DeleteOnTerminationSpecified;
    
	public SourceTargetType Source;
    public SourceTargetType Target;
    
    [XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAttribute(DataType="NCName")]
    public string name;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("CreationFlag", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public enum CreationFlagEnumeration
{
	overwrite,
    append,
    dontOverwrite
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("CPUArchitecture", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class CPUArchitectureType
{
	public ProcessorArchitectureEnumeration CPUArchitectureName;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("CPUArchitectureName", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public enum ProcessorArchitectureEnumeration 
{
	sparc,
    powerpc,
    x86,
    x86_32,
    x86_64,
    parisc,
    mips,
    ia64,
    arm,
    other
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("OperatingSystemType", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class OperatingSystemTypeType
{
	public OperatingSystemTypeEnumeration OperatingSystemName;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
	[XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("OperatingSystemName", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public enum OperatingSystemTypeEnumeration
{
	Unknown,
    MACOS,
    ATTUNIX,
    DGUX,
    DECNT,
    Tru64_UNIX,
    OpenVMS,
    HPUX,
    AIX,
    MVS,
    OS400,
    OS_2,
    JavaVM,
    MSDOS,
    WIN3x,
    WIN95,
    WIN98,
    WINNT,
    WINCE,
    NCR3000,
    NetWare,
    OSF,
    DC_OS,
    Reliant_UNIX,
    SCO_UnixWare,
    SCO_OpenServer,
    Sequent,
    IRIX,
    Solaris,
    SunOS,
    U6000,
    ASERIES,
    TandemNSK,
    TandemNT,
    BS2000,
    LINUX,
    Lynx,
    XENIX,
    VM,
    Interactive_UNIX,
    BSDUNIX,
    FreeBSD,
    NetBSD,
    GNU_Hurd,
    OS9,
    MACH_Kernel,
    Inferno,
    QNX,
    EPOC,
    IxWorks,
    VxWorks,
    MiNT,
    BeOS,
    HP_MPE,
    NextStep,
    PalmPilot,
    Rhapsody,
    Windows_2000,
    Dedicated,
    OS_390,
    VSE,
    TPF,
    Windows_R_Me,
    Caldera_Open_UNIX,
    OpenBSD,
    Not_Applicable,
    Windows_XP,
    z_OS,
    other
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("OperatingSystem", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class OperatingSystem_Type
{
	public OperatingSystemTypeType OperatingSystemType;
    public string OperatingSystemVersion;
    public string Description;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
public class RangeType
{
    public BoundaryType LowerBound;
    public BoundaryType UpperBound;

	[XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
public class BoundaryType
{
	[XmlAttribute]
    public bool exclusiveBound;
    
    [XmlIgnore]
    public bool exclusiveBoundSpecified;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
    
    [XmlText]
    public System.Double Value;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
public class ExactType
{
	[XmlAttribute]
    public System.Double epsilon;
    
	[XmlIgnore]
    public bool epsilonSpecified;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
    
    [XmlText]
    public System.Double Value;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("DiskSpace", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class RangeValueType
{
	public BoundaryType UpperBoundedRange;
    public BoundaryType LowerBoundedRange;
    
    [XmlElement("Exact")]
    public ExactType[] Exact;
    
    [XmlElement("Range")]
    public RangeType[] Range;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("FileSystem", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class FileSystem_Type
{
    public FileSystemTypeEnumeration FileSystemType;
    
    [XmlIgnore]
    public bool FileSystemTypeSpecified;
    
    public string Description;
    public string MountPoint;
    public RangeValueType DiskSpace;
    
    [XmlAnyElement]
    public XmlElement[] Any;
    
    [XmlAttribute(DataType="NCName")]
    public string name;
    
    [XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("FileSystemType", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public enum FileSystemTypeEnumeration
{
    swap,
    temporary,
    spool,
    normal
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("Resources", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class ResourcesType
{
    [XmlArrayItem("HostName", IsNullable=false)]
    public string[] CandidateHosts;
    
    [XmlElement("FileSystem")]
    public FileSystem_Type[] FileSystem;
    
    public bool ExclusiveExecution;
    
	[XmlIgnore]
    public bool ExclusiveExecutionSpecified;
    
    public OperatingSystem_Type OperatingSystem;
    public CPUArchitectureType CPUArchitecture;
    public RangeValueType IndividualCPUSpeed;
    public RangeValueType IndividualCPUTime;
    public RangeValueType IndividualCPUCount;
    public RangeValueType IndividualNetworkBandwidth;
    public RangeValueType IndividualPhysicalMemory;
    public RangeValueType IndividualVirtualMemory;
    public RangeValueType IndividualDiskSpace;
    public RangeValueType TotalCPUTime;
    public RangeValueType TotalCPUCount;
    public RangeValueType TotalPhysicalMemory;
    public RangeValueType TotalVirtualMemory;
    public RangeValueType TotalDiskSpace;
    public RangeValueType TotalResourceCount;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
	[XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("Application", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class ApplicationType
{
	public string ApplicationName;
    public string ApplicationVersion;
    public string Description;
    
	[XmlAnyElement]
    public XmlElement[] Any;
    
	[XmlAnyAttribute]
    public XmlAttribute[] AnyAttr;
}

[XmlType(Namespace=JSDLConstants.JSDL_NS)]
[XmlRoot("CandidateHosts", Namespace=JSDLConstants.JSDL_NS, IsNullable=false)]
public class CandidateHostsType
{
    [XmlElement("HostName")]
    public string[] HostName;
}