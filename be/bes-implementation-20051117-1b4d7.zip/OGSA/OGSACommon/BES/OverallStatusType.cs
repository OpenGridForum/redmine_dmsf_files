using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("overall-status-type", Namespace=BESConstants.BES_NS)]
	public class OverallStatusType 
	{
		[XmlAttribute]
		public OverallStateEnumeration state;
    
		[XmlIgnore]
		public bool stateSpecified;
    
		[XmlAttribute]
		public OverallStateEnumeration laststate;
    
		[XmlIgnore]
		public bool laststateSpecified;
    
		[XmlAttribute]
		public string otherstate;
	}
}