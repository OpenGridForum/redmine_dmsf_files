using System;

using System.Xml;
using System.Xml.Serialization;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("state-change-response-enumeration", Namespace=BESConstants.BES_NS)]
	public enum StateChangeResponseEnumeration
	{
		Succeeded,
		Failed,
		IllegalStateChangeRequest
	}
}