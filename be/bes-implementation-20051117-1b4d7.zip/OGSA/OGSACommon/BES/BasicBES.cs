using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.Attributes;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Service.BaseTypes;
using UVa.GCG.WSRF.Service.BaseFaults;
using UVa.GCG.WSRF.Service.Grid;
using UVa.GCG.WSRF.Service.ResourceLifetime;
using UVa.GCG.WSRF.Service.ResourceProperties;

using GBG.FTP.FtpWeb;
using GBG.OGSA.OGSACommon.SMTP;

using GBG.OGSA.OGSACommon.Naming;
using GBG.OGSA.OGSACommon.Shared;

using GBG.OGSA.OGSACommon.BES.JSDL;

namespace GBG.OGSA.OGSACommon.BES
{
	[WsdlBaseName(BESConstants.BES_PORT_NAME, BESConstants.BES_NS)]
	[WebService]
	[WebServiceBinding]
	[WSRFPortType(typeof(ImmediateResourceTerminationPortType))]
	[WSRFPortType(typeof(GCGResourceFactoryPortType))]
	public class BasicBES : ServiceSkeleton
	{
		[Resource]
		private bool AcceptingNewActivities = true;

		static BasicBES()
		{
			FaultGenerator.RegisterFaultType(typeof(BackendFault));
			FaultGenerator.RegisterFaultType(typeof(BadlyFormedJSDLDocumentFault));
			FaultGenerator.RegisterFaultType(typeof(JobSpecificationFault));
			FaultGenerator.RegisterFaultType(typeof(NotAcceptingNewActivitiesFault));
			FaultGenerator.RegisterFaultType(typeof(UnsupportedFeatureFault));
			FaultGenerator.RegisterFaultType(typeof(UnsupportedJSDLFault));
			
			BasicBESConf conf = (BasicBESConf)ConfigurationSettings.GetConfig(
				"uva.gbg.ogsa.bes");

			WebRequest.RegisterPrefix("ftp", new FtpWebRequestCreate());
			WebRequest.RegisterPrefix("mailto",
				new MailWebRequestCreate(conf.SMTPServer, conf.FromAddress,
					conf.SubjectPattern, conf.BodyPattern));
		}

		public BasicBES()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		static private BasicBESConf BESConfiguration
		{
			get
			{
				BasicBESConf conf = (BasicBESConf)ConfigurationSettings.GetConfig(
					"uva.gbg.ogsa.bes");

				return conf;
			}
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/CreateActivityFromJSDL",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
		public EndpointReferenceType CreateActivityFromJSDL(
			[XmlElement("job-description-document", Namespace=BESConstants.BES_NS)]
				JobDefinitionType jobDescription, 
			[XmlElement("create-suspended", Namespace=BESConstants.BES_NS)]
				bool createInSuspendedState)
		{
			try
			{
				if (!AcceptingNewActivities)
					throw new GeneratableException(new NotAcceptingNewActivitiesFault());

				string activityKey = ActivityManager.ActivityManager.Instance.create(
					BESConfiguration.StateDirectory, jobDescription, createInSuspendedState);
				
				return EPRUtilities.makeSubResource(ServiceBase.EPR, activityKey);
			}
			catch (GeneratableException bge)
			{
				throw bge.generate(FaultGenerator, ServiceBase.EPR);
			}
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/GetActivityStatus",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("activity-status", Namespace=BESConstants.BES_NS)]
		public ActivityStatusType[] GetActivityStatus(
			[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
			EndpointReferenceType []activityIdentifiers)
		{
			int lcv;
			ActivityStatusType []ast = new ActivityStatusType[activityIdentifiers.Length];

			for (lcv = 0; lcv < ast.Length; lcv++)
			{
				string activityKey = EPRUtilities.extractActivityKey(activityIdentifiers[lcv]);
				ast[lcv] = ActivityManager.ActivityManager.Instance.getActivityStatus(activityKey);
				ast[lcv].ActivityIdentifier = activityIdentifiers[lcv];
			}

			return ast;
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/RequestActivityStateChanges",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("state-change-response", Namespace=BESConstants.BES_NS)]
		public StateChangeResponseType[] RequestActivityStateChanges(
			[XmlElement("state-change-request", Namespace=BESConstants.BES_NS)]
			StateChangeRequestType []requests)
		{
			int lcv;
			StateChangeResponseType []scrt = new StateChangeResponseType[requests.Length];

			for (lcv = 0; lcv < scrt.Length; lcv++)
			{
				string activityKey = EPRUtilities.extractActivityKey(requests[lcv].ActivityIdentifier);
				scrt[lcv] = ActivityManager.ActivityManager.Instance.requestActivityStateChange(
					activityKey, requests[lcv].RequestedStateChange);
				scrt[lcv].ActivityIdentifier = requests[lcv].ActivityIdentifier;
			}

			return scrt;
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/StopAcceptingNewActivities",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		public void StopAcceptingNewActivities()
		{
			AcceptingNewActivities = false;
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/StartAcceptingNewActivities",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		public void StartAcceptingNewActivities()
		{
			AcceptingNewActivities = true;
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/IsAcceptingNewActivities",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("response", Namespace=BESConstants.BES_NS)]
		public bool IsAcceptingNewActivities()
		{
			return AcceptingNewActivities;
		}

		[WebMethod]
		[SoapDocumentMethod(BESConstants.BES_NS + "/GetActivityJSDLDocuments",
			 RequestNamespace=BESConstants.BES_NS,
			 ResponseNamespace=BESConstants.BES_NS,
			 Use=System.Web.Services.Description.SoapBindingUse.Literal, 
			 ParameterStyle=SoapParameterStyle.Wrapped)]
		[return: XmlElement("activity-jsdl-document", Namespace=BESConstants.BES_NS)]
		public ActivityJSDLDocumentType[] GetActivityJSDLDocuments(
			[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
			EndpointReferenceType []activityIdentifiers)
		{
			int lcv;
			ActivityJSDLDocumentType []ast = new ActivityJSDLDocumentType[activityIdentifiers.Length];

			for (lcv = 0; lcv < ast.Length; lcv++)
			{
				string activityKey = EPRUtilities.extractActivityKey(activityIdentifiers[lcv]);
				ast[lcv] = ActivityManager.ActivityManager.Instance.getActivityJSDLDocument(activityKey);
				ast[lcv].ActivityIdentifier = activityIdentifiers[lcv];
			}

			return ast;
		}
	}
}