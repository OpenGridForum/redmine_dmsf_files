using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("activity-status-type", Namespace=BESConstants.BES_NS)]
	[XmlRoot("ActivityStatus", Namespace=BESConstants.BES_NS, IsNullable=false)]
	public class ActivityStatusType 
	{
		[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
		public EndpointReferenceType ActivityIdentifier;

		[XmlElement("overall-status", Namespace=BESConstants.BES_NS)]
		public OverallStatusType OverallStatus;

		[XmlElement("data-stage-status", Namespace=BESConstants.BES_NS)]
		public DataStageStatusType []StagingStatus;
	}
}