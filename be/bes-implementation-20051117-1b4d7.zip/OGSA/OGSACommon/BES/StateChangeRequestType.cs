using System;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.BES
{
	[XmlType("state-change-request-type", Namespace=BESConstants.BES_NS)]
	public class StateChangeRequestType
	{
		[XmlElement("activity-identifier", Namespace=BESConstants.BES_NS)]
		public EndpointReferenceType ActivityIdentifier;

		[XmlElement("requested-state-change", Namespace=BESConstants.BES_NS)]
		public RequestedStateChangeType RequestedStateChange;
	}
}