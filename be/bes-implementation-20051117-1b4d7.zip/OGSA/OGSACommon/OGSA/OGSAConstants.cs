using System;

using System.Xml;

namespace GBG.OGSA.OGSACommon.OGSA
{
	public class OGSAConstants
	{
		public const string WSResourceInterfacesNS = "http://www.ggf.org/namespaces/OGSABasicProfile-1.0.xsd";
		public const string WSResourceInterfacesName = "WSResourceInterfaces";

		static public readonly XmlQualifiedName WSResourceInterfacesQName =
			new XmlQualifiedName(WSResourceInterfacesName, WSResourceInterfacesNS);
	}
}