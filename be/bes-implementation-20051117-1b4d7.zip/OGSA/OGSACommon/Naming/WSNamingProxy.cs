using System;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Naming
{
	public class WSNamingProxy : WebServicesClientProtocol
	{
		static private readonly int []_RETRY_VECTOR;

		static WSNamingProxy()
		{
			_RETRY_VECTOR = new int[]
				{
					0, 0, 0, 0, 0,
					5, 10, 15
				};
		}

		private EndpointReferenceType _epr;

		public WSNamingProxy(EndpointReferenceType epr)
		{
			_epr = epr;
		}

		public WSNamingProxy(string URL)
			: this(new EndpointReferenceType(
				new AttributedURI(null, URL),
				null, null, null, null, null))
		{
		}

		protected new object[] Invoke(string method, object []parms)
		{
			Exception badE = null;

			bool unresponsive = false;
			foreach (int retry in _RETRY_VECTOR)
			{
				if (unresponsive)
				{
					System.Threading.Thread.Sleep(1000 * retry);
					Console.Error.WriteLine("Found an unresponsive target -- retrying...");
				}

				try
				{
					return base.Invoke(method, parms);
				}
				catch (Exception e)
				{
					if (!NamingUtilities.retryable(e))
						throw;

					unresponsive = true;
					badE = e;
				}
			}

			throw badE;
		}

//		protected new IAsyncResult BeginInvoke(string methodName, object[] parameters,
//			AsyncCallback callback, object asyncState)
//		{
//			return base.BeginInvoke(methodName, parameters, callback, asyncState);
//		}
//
//		protected new object[] EndInvoke(IAsyncResult asyncResult)
//		{
//			return base.EndInvoke(asyncResult);
//		}
	}
}