using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Naming
{
	public class WSName
	{
		static private XmlRootAttribute _refResRoot;

		static WSName()
		{
			_refResRoot = new XmlRootAttribute("ReferenceResolver");
			_refResRoot.Namespace = NamingConstants.NAMING_NS;
		}

		private EndpointReferenceType _epr;
		private EndpointReferenceType []_resolvers;
		private string _abstractName = null;

		private WSName(EndpointReferenceType epr)
		{
			_epr = epr;
			ArrayList resolvers = new ArrayList();

			foreach (XmlElement element in _epr.Any)
			{
				if (element.Name.Equals(NamingConstants.ABSTRACT_NAME_QNAME.Name))
				{
					_abstractName = element.InnerText;
				} 
				else if (element.Name.Equals(NamingConstants.REFERENCE_RESOLVER_QNAME.Name))
				{
					EndpointReferenceType eepr = (EndpointReferenceType)WSUtilities.Deserialize(element, 
						typeof(EndpointReferenceType), _refResRoot);
					if (eepr == null)
						throw new Exception();

					resolvers.Add(eepr);
				}
			}

			if (_abstractName == null)
				throw new Exception();

			_resolvers = new EndpointReferenceType[resolvers.Count];
			resolvers.CopyTo(_resolvers);
		}

		static public implicit operator EndpointReferenceType(WSName name)
		{
			return (name == null) ? null : name._epr;
		}

		static public implicit operator WSName(EndpointReferenceType epr)
		{
			try
			{
				return new WSName(epr);
			}
			catch (Exception)
			{
				return null;
			}
		}

		public string AbstractName
		{
			get
			{
				return _abstractName;
			}
		}

		public EndpointReferenceType[] ReferenceResolvers
		{
			get
			{
				return _resolvers;
			}
		}

		public bool Equals(WSName wsname)
		{
			return wsname._abstractName.Equals(_abstractName);
		}

		public override bool Equals(object obj)
		{
			if (obj is WSName)
				return Equals((WSName)obj);

			return false;
		}

		public override int GetHashCode()
		{
			return _abstractName.GetHashCode();
		}
	}
}