using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using System.Text.RegularExpressions;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.Attributes;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Service.BaseTypes;
using UVa.GCG.WSRF.Service.Grid;
using UVa.GCG.WSRF.Service.ResourceLifetime;
using UVa.GCG.WSRF.Service.ResourceProperties;

namespace GBG.OGSA.OGSACommon.Naming
{
	[WsdlBaseName("ReferenceResolver", NamingConstants.NAMING_NS)]
	[WebService]
	[WebServiceBinding]
	[WSRFPortType(typeof(ImmediateResourceTerminationPortType))]
	[WSRFPortType(typeof(GCGResourceFactoryPortType))]
	public class ReferenceResolver : ServiceSkeleton
	{
		public ReferenceResolver()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		[SoapDocumentMethod(NamingConstants.NAMING_NS + "/resolve/resolve_abstractname")]
		[return: XmlElement("resolution", Namespace=NamingConstants.NAMING_NS)]
		public EndpointReferenceType resolveAbstractName(
			[XmlElement("abstract-name", Namespace=NamingConstants.NAMING_NS)] string abstractName)
		{
			return null;
		}

		[WebMethod]
		[SoapDocumentMethod(NamingConstants.NAMING_NS + "/resolve/resolve")]
		[return: XmlElement("resolution", Namespace=NamingConstants.NAMING_NS)]
		public EndpointReferenceType resolveWSName(
			[XmlElement("hint", Namespace=NamingConstants.NAMING_NS)] EndpointReferenceType hint)
		{
			return null;
		}
	}
}