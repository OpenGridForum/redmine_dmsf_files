using System;
using System.Collections;

using System.Xml;
using System.Xml.Serialization;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Naming
{
	public class EPRComparisons : IHashCodeProvider, IComparer
	{
		static private EPRComparisons _instance;

		static EPRComparisons()
		{
			_instance = new EPRComparisons();
		}

		static public EPRComparisons Instance
		{
			get
			{
				return _instance;
			}
		}

		private EPRComparisons()
		{
		}

		#region IHashCodeProvider Members

		public int GetHashCode(EndpointReferenceType epr)
		{
			XmlElement elem = WSUtilities.Serialize(epr);
			return elem.GetHashCode();
		}

		public int GetHashCode(object obj)
		{
			if (obj is WSName)
				return obj.GetHashCode();
			if (obj is EndpointReferenceType)
				return GetHashCode((EndpointReferenceType)obj);
			
			return obj.GetHashCode();
		}

		#endregion

		#region IComparer Members

		public int Compare(EndpointReferenceType epr1, EndpointReferenceType epr2)
		{
			XmlElement e1 = WSUtilities.Serialize(epr1);
			XmlElement e2 = WSUtilities.Serialize(epr2);

			if (e1.Equals(e2))
				return 0;

			return (e1.GetHashCode() - e2.GetHashCode());
		}

		public int Compare(object x, object y)
		{
			if ((x is WSName) && (y is WSName))
				if (x.Equals(y))
					return 0;
				
			return GetHashCode(x) - GetHashCode(y);
		}

		#endregion
	}
}