using System;
using System.Net;
using System.Web.Services.Protocols;
using System.Xml;

using System.Text.RegularExpressions;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

namespace GBG.OGSA.OGSACommon.Naming
{
	public class NamingUtilities
	{
		static private readonly Regex _SOAP_MESSAGE_PATTERN;

		static NamingUtilities()
		{
			_SOAP_MESSAGE_PATTERN = new Regex("^Unable to locate resource with id .*$");
		}

		static public bool retryable(Exception e)
		{
			if (e is WebException)
				return true;
			else if (e is SoapException)
			{
				SoapException se = (SoapException)e;
				return _SOAP_MESSAGE_PATTERN.IsMatch(se.Message);
			}

			return false;
		}
	}
}