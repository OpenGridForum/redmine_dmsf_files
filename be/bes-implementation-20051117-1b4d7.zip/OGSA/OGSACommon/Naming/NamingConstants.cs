using System;

using System.Xml;

namespace GBG.OGSA.OGSACommon.Naming
{
	public class NamingConstants
	{
		public const string NAMING_NS = "http://ggf.org/name";

		static public readonly XmlQualifiedName ABSTRACT_NAME_QNAME =
			new XmlQualifiedName("AbstractName", NAMING_NS);
		static public readonly XmlQualifiedName REFERENCE_RESOLVER_QNAME =
			new XmlQualifiedName("ReferenceResolver", NAMING_NS);

		public const string REF_RESOLVER_PORT_TYPE = "reference-resolver";
		static public readonly XmlQualifiedName REF_RESOLVER_PORT_TYPE_QNAME =
			new XmlQualifiedName(REF_RESOLVER_PORT_TYPE, NAMING_NS);
	}
}