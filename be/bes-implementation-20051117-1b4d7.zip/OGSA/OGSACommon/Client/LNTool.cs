using System;
using System.IO;

using System.Xml;
using System.Xml.Serialization;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Grid;
using UVa.GCG.WSRF.Common.AppDomainCaches;

using GBG.OGSA.OGSACommon.ByteIO;

namespace GBG.OGSA.OGSACommon.Client
{
	public class LNTool : AbstractTool
	{
		private const string _TOOL_NAME = "ln";
		private const string _TOOL_DESCRIPTION = "Tool to add new links.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <src-path> <target-path>\n\t\tOR\n\t"
			+ _TOOL_NAME + " --src-file=<local-file> <target-path>\n\t\tOR\n\t"
			+ _TOOL_NAME + " --uri=<uri> <target-path>";

		public LNTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			string srcFile = null;
			string srcURI = null;
			if (commandLine.Options.ContainsKey("src-file"))
			{
				ArrayList aList = (ArrayList)commandLine.Options["src-file"];
				if (aList != null && aList.Count == 1)
					srcFile = aList[0] as string;
			} 
			else if (commandLine.Options.ContainsKey("uri"))
			{
				ArrayList aList = (ArrayList)commandLine.Options["uri"];
				if (aList != null && aList.Count == 1)
					srcURI = aList[0] as string;
			}

			if (srcFile != null)
				return link(commandLine.Arguments, srcFile, sessionMgr);
			else if (srcURI != null)
				return link(commandLine.Arguments, new EndpointReferenceType(
					new AttributedURI(null, srcURI), null, null, null, null, null),
					sessionMgr);
			else
				return link(commandLine.Arguments, sessionMgr);
		}

		private bool link(ArrayList arguments, IClientSessionManager sessionMgr)
		{
			if (arguments.Count != 2)
				throw new ToolUsageException(this);

			ContextPath []results = sessionMgr.Session.CurrentPath.lookup(arguments[0] as string, true);
			if (results.Length != 1)
				throw new ToolUsageException(this);

			ContextPath source = results[0];

			results = sessionMgr.Session.CurrentPath.lookup(arguments[1] as string, false);
			if (results.Length != 1)
				throw new ToolUsageException(this);
			
			ContextPath target = results[0];
			if (target.Exists)
				throw new ToolException(this, string.Format("Path \"{0}\" already exists.", target));

			target.ln(source.EPR);
			return true;
		}

		private bool link(ArrayList arguments, EndpointReferenceType epr, IClientSessionManager sessionMgr)
		{
			if (arguments.Count != 1)
				throw new ToolUsageException(this);

			ContextPath []results = sessionMgr.Session.CurrentPath.lookup(arguments[0] as string, false);
			if (results.Length != 1)
				throw new ToolUsageException(this);
			
			ContextPath target = results[0];
			if (target.Exists)
				throw new ToolException(this, string.Format("Path \"{0}\" already exists.", target));

			target.ln(epr);
			return true;
		}

		private bool link(ArrayList arguments, string sourceFile, IClientSessionManager sessionMgr)
		{
			EndpointReferenceType epr;
			using (FileStream stream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read))
			{
				XmlSerializer serializer = SerializerCache.Instance[typeof(EndpointReferenceType)];
				epr = (EndpointReferenceType)serializer.Deserialize(stream);
			}

			if (epr == null)
				throw new ToolException(this, string.Format(
					"Couldn't read valid EPR from file \"{0}\".", sourceFile));

			return link(arguments, epr, sessionMgr);
		}
	}
}