using System;
using System.Collections;

namespace GBG.OGSA.OGSACommon.Client
{
	public interface ICommandLine
	{
		// A map of option name to ArrayList(of string values)
		Hashtable Options { get; }
		ArrayList Arguments { get; }

		string getSingleOption(string key);
	}
}