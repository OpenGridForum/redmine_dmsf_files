using System;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ToolUsageException : ToolException
	{
		public ToolUsageException(ITool tool)
			: base(tool, string.Format(tool.ToolHelp))
		{
		}
	}
}