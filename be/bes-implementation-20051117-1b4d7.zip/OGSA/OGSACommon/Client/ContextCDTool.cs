using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ContextCDTool : AbstractTool
	{
		private const string _TOOL_NAME = "cd";
		private const string _TOOL_DESCRIPTION = "Tool to change current working context.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <path>";

		public ContextCDTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			ArrayList args = commandLine.Arguments;

			if (args.Count != 1)
				throw new ToolUsageException(this);

			try
			{
				ContextPath []paths = sessionMgr.Session.CurrentPath.lookup(args[0] as string, true);
				if (paths.Length != 1)
					throw new ToolUsageException(this);
                
				OGSAObject context = new OGSAObject(paths[0].EPR);
				if (!context.ImplementsDirectory)
					throw new ToolException(this, string.Format("Path \"{0}\" does not resolve to a context.",
						paths[0].FullPath));

				sessionMgr.Session = new ClientSession(paths[0]);
			}
			catch (ContextException ce)
			{
				stderr.WriteLine("{0}", ce.Message);
				return false;
			}

			return true;
		}
	}
}