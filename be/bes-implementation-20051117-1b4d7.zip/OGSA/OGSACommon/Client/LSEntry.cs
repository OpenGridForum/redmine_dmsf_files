using System;

using System.Xml;

using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS;

namespace GBG.OGSA.OGSACommon.Client
{
	public interface ILSEntry
	{
		string TypeDescription { get; }
		string SizeDescription { get; }
		string Name { get; }
		string EPRDescription { get; }
	}

	public class VirtualLSEntry : ILSEntry
	{
		private string _typeDescription;
		private string _sizeDescription;
		private string _name;
		private string _eprDescription;

		public VirtualLSEntry(string typeDescription, string sizeDescription, string name)
			: this(typeDescription, sizeDescription, name, null)
		{
		}

		public VirtualLSEntry(string typeDescription, string sizeDescription, string name,
			string eprDescription)
		{
			_typeDescription = typeDescription;
			_sizeDescription = sizeDescription;
			_name = name;
			_eprDescription = eprDescription;
		}

		#region ILSEntry Members

		public string TypeDescription
		{
			get
			{
				return _typeDescription;
			}
		}

		public string SizeDescription
		{
			get
			{
				return _sizeDescription;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
		}

		public string EPRDescription
		{
			get
			{
				return _eprDescription;
			}
		}

		#endregion
	}

	public class ConcreteLSEntry : ILSEntry
	{
		private IOGSAObject _contactPoint;
		private ContextPath _path;

		public ConcreteLSEntry(ContextPath path)
		{
			_path = path;
			_contactPoint = null;
		}

		public ConcreteLSEntry(ContextPath path, IOGSAObject obj)
		{
			_path = path;
			_contactPoint = obj;
		}

		private IOGSAObject Contact
		{
			get
			{
				lock (this)
				{
					if (_contactPoint == null)
					{
						try
						{
							XmlQualifiedName []names = new XmlQualifiedName[]
							{
								ByteIOConstants._RBYTEIO_QNAME,
								ContextConstants._DIR_PORTTYPE_QNAME,
								FactoryConstants._FACT_PORTTYPE_QNAME
							};

							OGSAObjectMap map = OGSAObject.attach(_path.EPR, names);

							foreach (XmlQualifiedName name in names)
							{
								_contactPoint = map[name];
								foreach (XmlQualifiedName implementedName 
											 in _contactPoint.ImplementedPortTypes)
								{
									if (implementedName.Equals(name))
										return _contactPoint;
								}
							}

							_contactPoint = new OGSAObject(_path.EPR);
						}
						catch (Exception)
						{
							_contactPoint = new OGSAObject(_path.EPR);
						}
					}
				}

				return _contactPoint;
			}
		}

		#region ILSEntry Members

		public string TypeDescription
		{
			get
			{
				return Contact.TypeDescription;
			}
		}

		public string SizeDescription
		{
			get
			{
				return Contact.SizeDescription;
			}
		}

		public string Name
		{
			get
			{
				return _path.Name;
			}
		}

		public string EPRDescription
		{
			get
			{
				XmlElement element = WSUtilities.Serialize(_path.EPR);
				return element.OuterXml;
			}
		}

		#endregion
	}
}