using System;
using System.Collections;
using System.IO;

using GBG.OGSA.OGSACommon.Logging;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.Grid;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ContextSpaceTool : AbstractTool
	{
		private const string _BOOT_OPTION = "boot";
		private const string _DESTROY_OPTION = "destroy";
		private const string _CONNECT_OPTION = "connect";
		private const string _DISCONNECT_OPTION = "disconnect";
		private const string _CONTEXT_FACTORY_SERVICE = "context-factory-service";
		private const string _FORCE_OPTION = "force";

		private const string _TOOL_NAME = "context-space";
		private const string _TOOL_DESCRIPTION = "Tool to manage entire context spaces.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " --" + _BOOT_OPTION + "=<factory-url> --" + 
				_CONTEXT_FACTORY_SERVICE + "=<context-factory-service-url>\n" +
			"\t\tOR\n" +
			"\t" + _TOOL_NAME + " --" + _DESTROY_OPTION + " [--" + _FORCE_OPTION + "]\n" +
			"\t\tOR\n" +
			"\t" + _TOOL_NAME + " --" + _CONNECT_OPTION + "=<connection-url>" + "\n" +
			"\t\tOR\n" +
			"\t" + _TOOL_NAME + " --" + _DISCONNECT_OPTION + " [--" + _FORCE_OPTION + "]";

		public ContextSpaceTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			verify(commandLine);

			if (commandLine.Options.ContainsKey(_BOOT_OPTION))
				return boot(commandLine, stdin, stdout, stderr, sessionMgr);
			else if (commandLine.Options.ContainsKey(_DESTROY_OPTION))
				return destroy(commandLine, stdin, stdout, stderr, sessionMgr);
			else if (commandLine.Options.ContainsKey(_CONNECT_OPTION))
				return connect(commandLine, stdin, stdout, stderr, sessionMgr);
			else
				return disconnect(commandLine, stdin, stdout, stderr, sessionMgr);
		}

		protected void verify(ICommandLine commandLine)
		{
			if (commandLine.Options.ContainsKey(_BOOT_OPTION))
			{
				ArrayList list = (ArrayList)commandLine.Options[_BOOT_OPTION];
				if (list != null && list.Count == 1)
				{
					list = (ArrayList)commandLine.Options[_CONTEXT_FACTORY_SERVICE];
					if (list != null && list.Count == 1)
						return;
				}
			} 
			else if (commandLine.Options.ContainsKey(_DESTROY_OPTION))
			{
				return;
			} 
			else if (commandLine.Options.ContainsKey(_CONNECT_OPTION))
			{
				ArrayList list = (ArrayList)commandLine.Options[_CONNECT_OPTION];
				if (list != null && list.Count == 1)
					return;
			}
			else if (commandLine.Options.ContainsKey(_DISCONNECT_OPTION))
			{
				return;
			}

			throw new ToolUsageException(this);
		}
		
		private bool boot(ICommandLine commandLine, TextReader stdin, TextWriter stdout, TextWriter stderr, 
			IClientSessionManager sessionMgr)
		{
			if (sessionMgr.Exists)
			{
				stderr.WriteLine("Not allowed to boot a new system while still connected to an old one.");
				return false;
			}

			ArrayList factoryURLs = (ArrayList)commandLine.Options[_BOOT_OPTION];

			EndpointReferenceType superFactoryEPR;
			GCGResourceFactoryBinding GCGFactory = new GCGResourceFactoryBinding(factoryURLs[0] as string);
			CreateResponse resp = GCGFactory.Create(new Create());
			superFactoryEPR = resp.ResourceEndpoint;
			FactoryObject superFactory = OGSAObject.attach(superFactoryEPR,
				FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;
			superFactory.addServices(new EndpointReferenceType[]
				{
					new EndpointReferenceType(new AttributedURI(null, factoryURLs[0] as String),
					null, null, null, null, null)
				});

			ArrayList contextURLs = commandLine.Options[_CONTEXT_FACTORY_SERVICE] as ArrayList;
			EndpointReferenceType contextFactoryEPR = superFactory.instantiate();
			FactoryObject contextFactory = OGSAObject.attach(contextFactoryEPR,
				FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;
			contextFactory.addServices(new EndpointReferenceType[] 
				{
					new EndpointReferenceType(new AttributedURI(null,
					contextURLs[0] as string), null, null, null, null, null)
				});

			sessionMgr.Session = new ClientSession(contextFactory.instantiate());

			ContextObject rootContext = OGSAObject.attach(sessionMgr.Session.CurrentPath.EPR,
				ContextConstants._DIR_PORTTYPE_QNAME) as ContextObject;

			EndpointReferenceType factoriesEPR = contextFactory.instantiate();
			rootContext.add("Factories", factoriesEPR);

			ContextObject factoriesContext = OGSAObject.attach(factoriesEPR,
				ContextConstants._DIR_PORTTYPE_QNAME) as ContextObject;
			factoriesContext.add("DefaultContextFactory", contextFactoryEPR);
			factoriesContext.add("SuperFactory", superFactoryEPR);

			return true;
		}

		private bool destroy(ICommandLine commandLine, TextReader stdin, TextWriter stdout, TextWriter stderr, 
			IClientSessionManager sessionMgr)
		{
			bool force = commandLine.Options.ContainsKey(_FORCE_OPTION);

			if (!force)
			{
				stdout.Write("Are you sure you want to destroy the attached OGSA system (Y/N)?  ");
				string answer = stdin.ReadLine().Trim();
				if (!answer.Equals("Y"))
				{
					stdout.WriteLine("Cancelling operation.");
					return true;
				}
			}

			stderr.WriteLine("Unimplemented!");
			return false;
		}

		private bool connect(ICommandLine commandLine, TextReader stdin, TextWriter stdout, TextWriter stderr, 
			IClientSessionManager sessionMgr)
		{
			if (sessionMgr.Exists)
			{
				stderr.WriteLine("Not allowed to connect to a new system while still connected to an old one.");
				return false;
			}

			stderr.WriteLine("Unimplemented!");
			return false;
		}

		private bool disconnect(ICommandLine commandLine, TextReader stdin, TextWriter stdout, TextWriter stderr, 
			IClientSessionManager sessionMgr)
		{
			bool force = commandLine.Options.ContainsKey(_FORCE_OPTION);

			if (!force)
			{
				stdout.Write("Are you sure you want to disconnect from the attached OGSA system (Y/N)?  ");
				string answer = stdin.ReadLine().Trim();
				if (!answer.Equals("Y"))
				{
					stdout.WriteLine("Cancelling operation.");
					return true;
				}
			}

			sessionMgr.clear();

			return false;
		}
	}
}