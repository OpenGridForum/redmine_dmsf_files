using System;
using System.IO;

using System.Text.RegularExpressions;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.BES;
using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.BES.JSDL;
using GBG.OGSA.OGSACommon.BES.JSDL.POSIXApplication;

namespace GBG.OGSA.OGSACommon.Client
{
	public class RunTool : AbstractTool
	{
		private const string _TOOL_NAME = "run";
		private const string _TOOL_DESCRIPTION = "Tool to run legacy jobs on a remote system.";
		private const string _TOOL_HELP =
			"USAGE:  run <host-name> [--in=[name:<name>:]<uri>]* [--out=[name:<name>:]<uri>*] <executable> <arg1> <arg2> ...";

		public RunTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			if (commandLine.Arguments.Count < 2)
				throw new ToolUsageException(this);

			string hostName = (string)(commandLine.Arguments[0]);
			string executable = (string)(commandLine.Arguments[1]);

			string []arguments = new string[commandLine.Arguments.Count - 2];
			for (int lcv = 2; lcv < commandLine.Arguments.Count; lcv++)
				arguments[lcv - 2] = (string)(commandLine.Arguments[lcv]);

			string []inputURIs = null;
			string []outputURIs = null;

			if (commandLine.Options.ContainsKey("in"))
				inputURIs = getURIs((ArrayList)(commandLine.Options["in"]));
			else
				inputURIs = new string[0];

			if (commandLine.Options.ContainsKey("out"))
				outputURIs = getURIs((ArrayList)(commandLine.Options["out"]));
			else
				outputURIs = new string[0];

			JobDefinitionType jdt = formJSDL(executable, inputURIs, outputURIs, arguments);
			ContextPath []hostPath = sessionMgr.Session.CurrentPath.lookup(hostName, true);
			if (hostPath.Length != 1)
			{
				stderr.WriteLine("Unable to locate host \"{0}\".", hostName);
				throw new ToolUsageException(this);
			}

			BasicBESProxy proxy = new BasicBESProxy((EndpointReferenceType)(hostPath[0]));
			CreateActivityFromJSDL create = new CreateActivityFromJSDL();
			create.createsuspended = false;
			create.jobdescriptiondocument = jdt;

			EndpointReferenceType activity = proxy.CreateActivityFromJSDL(create).activityidentifier;

			bool done = false;
			while (!done)
			{
				GetActivityStatus request = new GetActivityStatus();
				request.activityidentifier = new EndpointReferenceType[] { activity, activity };
				GetActivityStatusResponse response = proxy.GetActivityStatus(request);

				OverallStateEnumeration state = response.activitystatus[0].OverallStatus.state;
				stdout.WriteLine("Current State:  {0}", state);

				switch (state)
				{
					case OverallStateEnumeration.Done :
					case OverallStateEnumeration.Exception :
					case OverallStateEnumeration.Terminated :
						stdout.WriteLine("The job has finished....exiting.");
						done = true;
						break;

					case OverallStateEnumeration.Unknown :
					case OverallStateEnumeration.Other :
						stdout.WriteLine("State is unknown or indeterminate...exiting.");
						done = true;
						break;

					default :
						done = false;
						break;
				}

				if (!done)
					System.Threading.Thread.Sleep(1000 * 5);
			}

			return true;
		}

		static private string[] getURIs(ArrayList list)
		{
			string []ret = new string[list.Count];
			for (int lcv = 0; lcv < ret.Length; lcv++)
				ret[lcv] = (string)(list[lcv]);

			return ret;
		}

		static private JobDefinitionType formJSDL(string executable, string []inputURIs,
			string []outputURIs, string []arguments)
		{
			int lcv;
			POSIXApplicationType posixApp = new POSIXApplicationType();
			posixApp.Executable = new FileNameType();
			posixApp.Executable.Value = executable;
			posixApp.Argument = new ArgumentType[arguments.Length];

			for (lcv = 0; lcv < arguments.Length; lcv++)
			{
				posixApp.Argument[lcv] = new ArgumentType();
				posixApp.Argument[lcv].Value = arguments[lcv];
			}

			JobDefinitionType jdt = new JobDefinitionType();
			jdt.JobDescription = new JobDescriptionType();
			jdt.JobDescription.JobIdentification = new JobIdentificationType();
			jdt.JobDescription.JobIdentification.JobName = "Run submitted from OGSA Command Line Run Tool";
			jdt.JobDescription.JobIdentification.Description = "This run was automatically generated and submitted by the OGSA run tool.";
			jdt.JobDescription.Application = new ApplicationType();
			jdt.JobDescription.Application.ApplicationName = executable;
			jdt.JobDescription.Application.Any = new XmlElement[]
				{
					WSUtilities.Serialize(posixApp)
				};

			jdt.JobDescription.DataStaging = new DataStagingType[inputURIs.Length + outputURIs.Length];
			for (lcv = 0; lcv < inputURIs.Length; lcv++)
			{
				jdt.JobDescription.DataStaging[lcv] = formStagingInfo(true, inputURIs[lcv]);
			}

			for (lcv = 0; lcv < outputURIs.Length; lcv++)
			{
				jdt.JobDescription.DataStaging[lcv + inputURIs.Length] = formStagingInfo(false,
					outputURIs[lcv]);
			}

			return jdt;
		}

		static private Regex _FILE_REGEX = new Regex("(name:(?<name>[^:]+):)?(?<uri>.*)");
		static private DataStagingType formStagingInfo(bool isInput, string parameter)
		{
			string name = null;
			string uri = null;

			DataStagingType ret = new DataStagingType();
			ret.CreationFlag = CreationFlagEnumeration.overwrite;
			ret.DeleteOnTermination = true;
			ret.DeleteOnTerminationSpecified = true;

			Match m = _FILE_REGEX.Match(parameter);
			if (!m.Success || m.Groups["name"].Value == null || m.Groups["name"].Value.Length == 0)
			{
				int index = parameter.LastIndexOf('/');
				if (index < 0)
					name = parameter;
				else
					name = parameter.Substring(index + 1);

				uri = parameter;
			} 
			else
			{
				name = m.Groups["name"].Value;
				uri = m.Groups["uri"].Value;
			}

			ret.FileName = name;

			if (isInput)
			{
				ret.Source = new SourceTargetType();
				ret.Source.URI = uri;
			} 
			else
			{
				ret.Target = new SourceTargetType();
				ret.Target.URI = uri;
			}

			return ret;
		}
	}
}