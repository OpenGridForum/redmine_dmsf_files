using System;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ToolException : Exception
	{
		private ITool _tool;

		public ToolException(ITool tool, string msg)
			: base(msg)
		{
			_tool = tool;
		}
	}
}