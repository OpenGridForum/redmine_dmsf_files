using System;
using System.IO;

using GBG.OGSA.OGSACommon.Logging;
using GBG.OGSA.OGSACommon.Configuration;

namespace GBG.OGSA.OGSACommon.Client
{
	public abstract class AbstractTool : ITool
	{
		private string _toolName;
		private string _toolDescription;
		private string _toolHelp;

		protected AbstractTool(string toolName, string toolDescription, string toolHelp)
		{
			_toolName = toolName;
			_toolDescription = toolDescription;
			_toolHelp = toolHelp;
		}

		protected AbstractTool(string toolName, string toolHelp)
			: this(toolName, toolName, toolHelp)
		{
		}

		#region ITool Members

		public string ToolName
		{
			get
			{
				return _toolName;
			}
		}

		public string ToolDescription
		{
			get
			{
				return _toolDescription;
			}
		}

		public string ToolHelp
		{
			get
			{
				return _toolHelp;
			}
		}

		public virtual bool DebugDevice
		{
			get
			{
				return false;
			}
		}

		public abstract bool execute(ICommandLine commandLine,
			TextReader stdin, TextWriter stdout, TextWriter stderr, IClientSessionManager session);

		#endregion
	}
}