using System;

using System.IO;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;

using GBG.OGSA.OGSACommon.Logging;
using GBG.OGSA.OGSACommon.Configuration;

namespace GBG.OGSA.OGSACommon.Client
{
	public interface ITool
	{
		string ToolName { get; }
		string ToolDescription { get; }
		string ToolHelp { get; }
		bool DebugDevice { get; }

		bool execute(ICommandLine commandLine,
			TextReader stdin, TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr);
	}
}