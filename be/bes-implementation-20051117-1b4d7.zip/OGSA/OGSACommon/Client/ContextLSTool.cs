using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ContextLSTool : AbstractTool
	{
		private const string _LONG_OPTION1 = "long";
		private const string _LONG_OPTION2 = "l";
		private const string _ALL_OPTION1 = "all";
		private const string _ALL_OPTION2 = "a";
		private const string _DIR_OPTION1 = "directory";
		private const string _DIR_OPTION2 = "d";
		private const string _EPR_OPTION = "epr";

		private const string _TOOL_NAME = "ls";
		private const string _TOOL_DESCRIPTION = "Tool to list entries in context space.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + "[-" + _LONG_OPTION2 + " | --" + _LONG_OPTION1 + "] " +
			"[-" + _ALL_OPTION2 + " | --" + _ALL_OPTION1 + "] " +
			"[-" + _DIR_OPTION2 + " | --" + _DIR_OPTION1 + "] " +
			"[--epr] [<path1>, <path2>, ...]";

		public ContextLSTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			bool isLong = 
				(commandLine.Options.ContainsKey(_LONG_OPTION1) || 
				commandLine.Options.ContainsKey(_LONG_OPTION2));
			bool isAll = 
				(commandLine.Options.ContainsKey(_ALL_OPTION1) || 
				commandLine.Options.ContainsKey(_ALL_OPTION2));
			bool isDir = 
				(commandLine.Options.ContainsKey(_DIR_OPTION1) || 
				commandLine.Options.ContainsKey(_DIR_OPTION2));
			bool isEPR =
				commandLine.Options.ContainsKey(_EPR_OPTION);

			ArrayList paths = commandLine.Arguments;

			list(stdout, stderr, sessionMgr, paths, isLong, isAll, isDir, isEPR);
			return true;
		}

		private void list(TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr,
			ArrayList paths, bool isLong, bool isAll, bool isDir, bool isEPR)
		{
			Hashtable contents = new Hashtable();

			ContextPath current = sessionMgr.Session.CurrentPath;

			if (paths.Count == 0)
				paths.Add(".");

			foreach (string path in paths)
			{
				ContextPath []entries = current.lookup(path, true);

				if (entries.Length == 0)
				{
					stderr.WriteLine("Unable to locate path \"{0}\"!", path);
					continue;
				}

				foreach (ContextPath entry in entries)
				{
					if (!isAll && entry.Name.StartsWith("."))
						continue;

					OGSAObject oobj = new OGSAObject(entry.EPR);

					if (oobj.ImplementsDirectory)
					{
						if (isDir)
							contents[entry.Name] = new ConcreteLSEntry(entry);
						else
						{
							ArrayList subContents = new ArrayList();
							contents[entry.Name] = subContents;

							ContextPath []subEntries = entry.lookup("./*", true);
							foreach (ContextPath subEntry in subEntries)
							{
								if (!subEntry.Exists)
									continue;

								subContents.Add(new ConcreteLSEntry(subEntry));
							}
						}
					} 
					else
					{
						contents[entry.Name] = new ConcreteLSEntry(entry);
					}
				}
			}

			ICollection _keys = contents.Keys;
			string []keys = new string[_keys.Count];
			_keys.CopyTo(keys, 0);
			Array.Sort(keys);

			foreach (string key in keys)
			{
				object obj = contents[key];
				if (obj is ILSEntry)
					stdout.WriteLine("{0}", describeObject((ILSEntry)obj, isLong, isEPR));
				else
				{
					if (keys.Length > 1)
						stdout.WriteLine("{0}:", key);

					if (isAll)
					{
						stdout.WriteLine("{0}", describeObject(new VirtualLSEntry("Directory", "", "."),
							isLong, isEPR));
						stdout.WriteLine("{0}", describeObject(new VirtualLSEntry("Directory", "", ".."),
							isLong, isEPR));
					}

					ArrayList entries = (ArrayList)obj;
					foreach (ILSEntry entry in entries)
					{
						stdout.WriteLine("{0}", describeObject(entry, isLong, isEPR));
					}
				}

				if (keys.Length > 1)
					stdout.WriteLine();
			}
		}

		private string describeObject(ILSEntry entry, bool isLong, bool isEPR)
		{
			string typeDesc = isLong ? string.Format("[{0}]", entry.TypeDescription) : null;
			string sizeDesc = isLong ? entry.SizeDescription : null;
			string eprDesc = isEPR ? entry.EPRDescription : null;
			string formatString = "";

			if (isLong)
				formatString += "{0,-16}{1,16} ";
			formatString += "{2}";
			if (isEPR)
				formatString += " {3}";

			return string.Format(formatString, typeDesc, sizeDesc, entry.Name, eprDesc);
		}
	}
}