using System;
using System.Collections;

namespace GBG.OGSA.OGSACommon.Client
{
	public class DefaultCommandLine : ICommandLine
	{
		private Hashtable _options = new Hashtable();
		private ArrayList _arguments = new ArrayList();

		/// <summary>
		/// Parses a command line and stores the values for that command line.
		/// </summary>
		/// <param name="args">The various arguments to the command line.  These can either be long options (i.e.,
		/// --some-option-name[=val1[,val2[,val3[,...]]]]), or short options (i.e., -abc[=val1[,val2[,val3[,...]]]]),
		/// or simply arguments.</param>
		public DefaultCommandLine(string []args)
			: this(args, 0)
		{
		}

		public DefaultCommandLine(string []args, int startIndex)
		{
			for (int lcv = startIndex; lcv < args.Length; lcv++)
			{
				string arg = args[lcv];

				if (arg.StartsWith("--"))
					parseLongOption(arg.Substring(2));
				else if (arg.StartsWith("-"))
					parseShortOptions(arg.Substring(1));
				else
					_arguments.Add(arg);
			}
		}

		private void addOptionValue(string name, string []vals)
		{
			ArrayList values = (ArrayList)_options[name];
			if (values == null)
			{
				values = new ArrayList();
				_options[name] = values;
			}

			if (vals != null)
			{
				foreach (string s in vals)
					values.Add(s);
			}
		}

		private string[] getValues(string vals)
		{
			if (vals == null)
				return null;

			return vals.Split(',');
		}

		private void parseLongOption(string arg)
		{
			string name = null;
			string val = null;

			int index = arg.IndexOf('=');
			if (index > 0)
			{
				name = arg.Substring(0, index);
				val = arg.Substring(index + 1);
			} 
			else
			{
				name = arg;
			}

			addOptionValue(name, getValues(val));
		}

		private void parseShortOptions(string arg)
		{
			int index = arg.IndexOf('=');
			if (index <= 0)
			{
				foreach (char c in arg)
				{
					addOptionValue(new string(c, 1), null);
				}
			} 
			else
			{
				for (int lcv = 0; lcv < index - 1; lcv++)
					addOptionValue(arg.Substring(lcv, 1), null);
				addOptionValue(arg.Substring(index - 1, 1), getValues(arg.Substring(index + 1)));
			}
		}

		#region ICommandLine Members

		public Hashtable Options
		{
			get
			{
				return _options;
			}
		}

		public ArrayList Arguments
		{
			get
			{
				return _arguments;
			}
		}

		public string getSingleOption(string key)
		{
			ArrayList vals = (ArrayList)Options[key];
			if (vals == null || vals.Count < 1)
				return null;

			return (string)vals[0];
		}

		#endregion
	}
}