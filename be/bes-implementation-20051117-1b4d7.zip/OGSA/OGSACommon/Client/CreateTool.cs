using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Grid;

using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Factories;

namespace GBG.OGSA.OGSACommon.Client
{
	public class CreateTool : AbstractTool
	{
		private const string _TOOL_NAME = "create";
		private const string _TOOL_DESCRIPTION = "Tool to create new instances of factories.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <factory-path> <new-object-path>";

		public CreateTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			if (commandLine.Arguments.Count != 2)
				throw new ToolUsageException(this);

			string factoryPath = (string)commandLine.Arguments[0];
			string newInstancePath = (string)commandLine.Arguments[1];

			ContextPath []factories = sessionMgr.Session.CurrentPath.lookup(factoryPath, true);
			ContextPath []newPaths = sessionMgr.Session.CurrentPath.lookup(newInstancePath, false);

			if (factories.Length != 1 || newPaths.Length != 1)
				throw new ToolUsageException(this);

			if (newPaths[0].Exists)
			{
				stderr.WriteLine("Path \"{0}\" already exists.", newInstancePath);
				throw new ToolUsageException(this);
			}

			WSRFNetFactoryProxy factory = new WSRFNetFactoryProxy((EndpointReferenceType)factories[0]);
			instantiate i = new instantiate();
			instantiateResponse r = factory.instantiate(i);
			newPaths[0].ln(r.instance);

			return true;
		}
	}
}