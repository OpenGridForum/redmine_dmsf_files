using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class TreeTool : AbstractTool
	{
		private const string _TOOL_NAME = "tree";
		private const string _TOOL_DESCRIPTION = "Tool to tree a directory";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <path>";

		public TreeTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			foreach (string arg in commandLine.Arguments)
			{
				sessionMgr.Session.CurrentPath.recursiveTraversal(arg,
					new ContextPath.TraversedPathHandler(handler));
			}

			return true;
		}

		private bool handler(ContextPath entry, bool repeated)
		{
			Console.WriteLine("{0} [repeated={1}]", entry, repeated);
			return true;
		}
	}
}