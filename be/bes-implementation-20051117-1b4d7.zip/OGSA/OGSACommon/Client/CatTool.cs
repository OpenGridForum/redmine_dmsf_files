using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class CatTool : AbstractTool
	{
		private const int _DEFAULT_BUF_SIZE = 1024 * 4;
		private const string _TOOL_NAME = "cat";
		private const string _TOOL_DESCRIPTION = "Tool to cat out the contents of files.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <path>";

		public CatTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			int charsRead = 0;
			char []buffer = new char[_DEFAULT_BUF_SIZE];

			foreach (string spath in commandLine.Arguments)
			{
				ContextPath []entries = sessionMgr.Session.CurrentPath.lookup(spath, true);
				foreach (ContextPath entry in entries)
				{
					using (StreamReader reader = new StreamReader(new BufferedStream(new RandomByteIOStream(entry,
						FileMode.Open, FileAccess.Read))))
					{
						do
						{
							charsRead = reader.ReadBlock(buffer, 0, _DEFAULT_BUF_SIZE);
							if (charsRead > 0)
								stdout.Write(buffer, 0, charsRead);
						} while (charsRead > 0);
					}
				}
			}

			return true;
		}
	}
}