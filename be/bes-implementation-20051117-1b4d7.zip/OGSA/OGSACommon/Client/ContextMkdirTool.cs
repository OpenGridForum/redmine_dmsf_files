using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ContextMkdirTool : AbstractTool
	{
		private const string _PARENT_OPTION = "p";

		private const string _TOOL_NAME = "mkdir";
		private const string _TOOL_DESCRIPTION = "Tool to create context entries in context space.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + "-" + _PARENT_OPTION + " <path>";

		public ContextMkdirTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			bool isParent = commandLine.Options.ContainsKey(_PARENT_OPTION);

			ArrayList paths = commandLine.Arguments;

			if (paths.Count != 1)
				throw new ToolUsageException(this);

			try
			{
				sessionMgr.Session.CurrentPath.mkdir(paths[0] as string, isParent);
			}
			catch (ContextException ce)
			{
				stderr.WriteLine("{0}", ce.Message);
				return false;
			}

			return true;
		}
	}
}