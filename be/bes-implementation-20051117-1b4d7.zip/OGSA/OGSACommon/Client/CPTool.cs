using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Grid;

using GBG.OGSA.OGSACommon.ByteIO;

namespace GBG.OGSA.OGSACommon.Client
{
	public class CPTool : AbstractTool
	{
		private const string _TOOL_NAME = "cp";
		private const string _TOOL_DESCRIPTION = "Tool to copy files around.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " [--recursive | -r] [--localsrc] [--localdest]\n"
			+ "\t[--transfer-mechanism=<transfer-mech>] [--buffer-size=<buffer-size>] <sources> <target>";

		public CPTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			bool isRecursive = false;
			bool isLocalSrc = false;
			bool isLocalDest = false;
			string transferMechanismString = null;
			string bufferSizeString = null;
			int bufferSize = 0;
			XmlQualifiedName transferMechanism = null;

			isRecursive = commandLine.Options.ContainsKey("r") ||
				commandLine.Options.ContainsKey("recursive");
			isLocalSrc = commandLine.Options.ContainsKey("localsrc");
			isLocalDest = commandLine.Options.ContainsKey("localdest");

			transferMechanismString = commandLine.getSingleOption("transfer-mechanism");
			if (transferMechanismString != null)
			{
				int index = transferMechanismString.LastIndexOf(':');
				if (index > 0)
					transferMechanism = new XmlQualifiedName(transferMechanismString.Substring(index + 1),
						transferMechanismString.Substring(0, index));
			}

			bufferSizeString = commandLine.getSingleOption("buffer-size");
			if (bufferSizeString != null)
				bufferSize = Int32.Parse(bufferSizeString);

			ArrayList args = commandLine.Arguments;

			if (args.Count != 2)
				throw new ToolUsageException(this);

			Stream src = null;
			Stream dst = null;

			try
			{
				if (isLocalSrc)
					src = new FileStream(args[0] as string, FileMode.Open, FileAccess.Read);
				else
				{
					RandomByteIOStream rsrc = new RandomByteIOStream(
						lookup(sessionMgr.Session.CurrentPath, args[0] as string),
							FileMode.Open, FileAccess.Read);
					if (transferMechanism != null)
						rsrc.TransferMechanism = transferMechanism;
					if (bufferSizeString == null)
						bufferSize = 
							ByteIOConstants.TransferDescriptions[rsrc.TransferMechanism].PreferredBlockSize;;
					src = new BufferedStream(rsrc, bufferSize);
				}

				if (isLocalDest)
					dst = new FileStream(args[1] as string, FileMode.Create, FileAccess.Write);
				else
				{
					RandomByteIOStream rdst = new RandomByteIOStream(
						lookup(sessionMgr.Session.CurrentPath, args[1] as string),
							FileMode.Create, FileAccess.Write);
					if (transferMechanism != null)
						rdst.TransferMechanism = transferMechanism;
					if (bufferSizeString == null)
						bufferSize =
							ByteIOConstants.TransferDescriptions[rdst.TransferMechanism].PreferredBlockSize;
					dst = new BufferedStream(rdst, bufferSize);
				}

				byte []buffer = new byte[1024 * 1024];
				int r;

				while (true)
				{
					r = src.Read(buffer, 0, 1024 * 1024);
					if (r <= 0)
						break;
					dst.Write(buffer, 0, r);
				}
			}
			finally
			{
				if (src != null)
					src.Close();
				if (dst != null)
					dst.Close();
			}

			return true;
		}

		private ContextPath lookup(ContextPath current, string arg)
		{
			return (current.lookup(arg, false))[0];
		}				
	}
}