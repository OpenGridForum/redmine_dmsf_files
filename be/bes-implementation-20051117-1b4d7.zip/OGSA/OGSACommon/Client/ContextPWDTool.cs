using System;
using System.IO;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;

namespace GBG.OGSA.OGSACommon.Client
{
	public class ContextPWDTool : AbstractTool
	{
		private const string _TOOL_NAME = "pwd";
		private const string _TOOL_DESCRIPTION = "Tool to obtain the current working path.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME;

		public ContextPWDTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			stdout.WriteLine("{0}", sessionMgr.Session.CurrentPath);

			return true;
		}
	}
}