using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.ByteIO;
using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class RByteIODebugTool : AbstractTool
	{
		private const string _TOOL_NAME = "rbyteio-debug-tool";
		private const string _TOOL_DESCRIPTION = "Tool to debug random byteio.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " <path>";

		public RByteIODebugTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			if (commandLine.Arguments.Count != 1)
				throw new ToolUsageException(this);

			ContextPath []paths = sessionMgr.Session.CurrentPath.lookup(
				commandLine.Arguments[0] as string, true);
			if (paths.Length != 1)
				throw new ToolUsageException(this);

			doDebug(paths[0], ByteIOConstants.TRANSFER_SIMPLE);
			doDebug(paths[0], ByteIOConstants.TRANSFER_DIME);

			return true;
		}

		public override bool DebugDevice
		{
			get
			{
				return true;
			}
		}

		private void doDebug(ContextPath entry, XmlQualifiedName transMech)
		{
			byte []bytes = new byte[] { 65, 66, 67, 68 };

			RandomByteIOObject rObj = (RandomByteIOObject)OGSAObject.attach(
				entry, ByteIOConstants._RBYTEIO_QNAME);

			rObj.PreferredTransferMechanism = transMech;

			rObj.truncAppend(bytes, 0);
			rObj.truncAppend(bytes, 2);
			rObj.write(bytes, 6, 6, 0);
			rObj.append(bytes);
			rObj.read(0, 1, 1024, 0);
		}
	}
}