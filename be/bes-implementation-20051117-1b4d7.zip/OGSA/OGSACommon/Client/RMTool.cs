using System;
using System.IO;

using System.Xml;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Shared;

namespace GBG.OGSA.OGSACommon.Client
{
	public class RMTool : AbstractTool
	{
		private const string _TOOL_NAME = "rm";
		private const string _TOOL_DESCRIPTION = "Tool to remove context entries.";
		private const string _TOOL_HELP =
			"USAGE:  " + _TOOL_NAME + " [--destroy] [--force] <path>";

		public RMTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			bool force = commandLine.Options.ContainsKey("force");
			bool destroy = commandLine.Options.ContainsKey("destroy");

			ArrayList args = commandLine.Arguments;

			foreach (string spath in args)
			{
				ContextPath []entries = sessionMgr.Session.CurrentPath.lookup(spath, true);
				foreach (ContextPath entry in entries)
				{
					entry.remove(force, destroy);
				}
			}

			return true;
		}
	}
}