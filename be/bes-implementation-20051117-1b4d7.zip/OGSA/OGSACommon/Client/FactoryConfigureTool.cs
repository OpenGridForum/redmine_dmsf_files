using System;
using System.IO;

using System.Xml;
using System.Xml.Serialization;

using System.Collections;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Shared;

using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.ResourceProperties;

namespace GBG.OGSA.OGSACommon.Client
{
	public class FactoryConfigureTool : AbstractTool
	{
		private const string _ADD_SERVICE_OPTION = "add-service";
		private const string _LIST_SERVICES_OPTION = "list-services";
		private const string _ADD_FACTORY_OPTION = "add-factory";

		private const string _TOOL_NAME = "factory-configure";
		private const string _TOOL_DESCRIPTION = "Tool to configure factories.";
		private const string _TOOL_HELP =
			"USAGE:  factory-configure <factory-path> --add-service=<service-uri>\n\tOR\n"
			+ "        factory-configure <factory-path> --list-services\n\tOR\n"
			+ "        factory-configure <factory-path> --add-factory";

		public FactoryConfigureTool() : base(_TOOL_NAME, _TOOL_DESCRIPTION, _TOOL_HELP)
		{
		}

		public override bool execute(ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			ArrayList factories = commandLine.Arguments;
			if (factories == null || factories.Count < 1)
				throw new ToolUsageException(this);

			if (commandLine.Options.ContainsKey(_LIST_SERVICES_OPTION))
				return doList(factories, commandLine, stdin, stdout, stderr, sessionMgr);
			else if (commandLine.Options.ContainsKey(_ADD_FACTORY_OPTION))
				return doAddFactory(factories, commandLine, stdin, stdout, stderr, sessionMgr);
			else
				return doAddService(factories, commandLine, stdin, stdout, stderr, sessionMgr);
		}

		private bool doList(ArrayList factories, ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			foreach (string factory in factories)
			{
				ContextPath []paths = sessionMgr.Session.CurrentPath.lookup(factory, true);
				foreach (ContextPath path in paths)
				{
					stdout.WriteLine("Services for Factory \"{0}\".", path);

					FactoryObject fObj = OGSAObject.attach((EndpointReferenceType)path,
						FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;
					EndpointReferenceType []eprs = fObj.listServices();
					foreach (EndpointReferenceType epr in eprs)
					{
						stdout.WriteLine("\t{0}", epr.Address.Value);
					}
				}
			}

			return true;
		}

		private bool doAddFactory(ArrayList factories, ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			ContextPath []superPath = sessionMgr.Session.CurrentPath.lookup(
				"/Factories/SuperFactory", true);

			FactoryObject fObj = OGSAObject.attach(superPath[0].EPR,
				FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;

			foreach (string factory in factories)
			{
				ContextPath []paths = sessionMgr.Session.CurrentPath.lookup(factory, false);
				foreach (ContextPath path in paths)
				{
					if (path.Exists)
					{
						stderr.WriteLine("Path \"{0}\" alread exists.", path);
						continue;
					}

					path.ln(fObj.instantiate());
				}
			}

			return true;
		}
		
		private bool doAddService(ArrayList factories, ICommandLine commandLine, TextReader stdin, 
			TextWriter stdout, TextWriter stderr, IClientSessionManager sessionMgr)
		{
			foreach (string factory in factories)
			{
				ContextPath []paths = sessionMgr.Session.CurrentPath.lookup(factory, true);
				foreach (ContextPath path in paths)
				{
					FactoryObject fObj = OGSAObject.attach((EndpointReferenceType)path,
						FactoryConstants._FACT_PORTTYPE_QNAME) as FactoryObject;
						
					ArrayList aList = commandLine.Options[_ADD_SERVICE_OPTION] as ArrayList;
					EndpointReferenceType []eprs = new EndpointReferenceType[aList.Count];

					int lcv = 0;
					foreach (string serviceURL in aList)
					{
						eprs[lcv++] = new EndpointReferenceType(
							new AttributedURI(null, serviceURL),
							null, null, null, null, null);
					}

					fObj.addServices(eprs);
				}
			}

			return true;
		}
	}
}