using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using System.Text.RegularExpressions;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.Attributes;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Service.BaseTypes;
using UVa.GCG.WSRF.Service.Grid;
using UVa.GCG.WSRF.Service.ResourceLifetime;
using UVa.GCG.WSRF.Service.ResourceProperties;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Directories;
using GBG.OGSA.OGSACommon.OGSA;
using GBG.OGSA.OGSACommon.Shared;

namespace GBGWS.OGSA.FilesAndDirs
{
	[WsdlBaseName("Context", ContextConstants._DIR_NAMESPACE)]
	[WebService]
	[WebServiceBinding]
	[WSRFPortType(typeof(ImmediateResourceTerminationPortType))]
	[WSRFPortType(typeof(GCGResourceFactoryPortType))]
	[WSRFPortType(typeof(GetResourcePropertyPortType))]
	public class BasicContext : ServiceSkeleton
	{
		[Resource]
		private ContextEntryMap _map;

		[ResourceProperty(OGSAConstants.WSResourceInterfacesName,
			 OGSAConstants.WSResourceInterfacesNS, typeof(XmlQualifiedName), 
			 false, null, false, "1", "unbounded", 0)]
		private XmlQualifiedName[] WSResourceInterfaces
		{
			get
			{
				return new XmlQualifiedName[]
					{
						ContextConstants._DIR_PORTTYPE_QNAME
					};
			}
		}

		public BasicContext()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		[SoapDocumentMethod(ContextConstants._DIR_NAMESPACE + "/lookup")]
		[return: XmlElement("entry-map", Namespace=ContextConstants._DIR_NAMESPACE)]
		public ContextEntryMap lookup(
			[XmlElement("pattern", Namespace=ContextConstants._DIR_NAMESPACE)] string pattern)
		{
			PathPatternMatcher matcher = new PathPatternMatcher(pattern);
			return _map[matcher];
		}

		[WebMethod]
		[SoapDocumentMethod(ContextConstants._DIR_NAMESPACE + "/add")]
		[return: XmlElement("result", Namespace=ContextConstants._DIR_NAMESPACE)]
		public bool add([XmlElement("name", Namespace=ContextConstants._DIR_NAMESPACE)] string name,
			[XmlElement("epr", Namespace=ContextConstants._DIR_NAMESPACE)] EndpointReferenceType epr)
		{
			if (_map[name] != null)
				FaultGenerator.MakeFault(new ContextFault(
					string.Format("Entry \"{0}\" already exists.", name),
					ServiceBase.EPR));

			_map[name] = epr;
			return true;
		}

		[WebMethod]
		[SoapDocumentMethod(ContextConstants._DIR_NAMESPACE + "/remove")]
		[return: XmlElement("result", Namespace=ContextConstants._DIR_NAMESPACE)]
		public bool remove([XmlElement("name", Namespace=ContextConstants._DIR_NAMESPACE)] string name)
		{
			return _map.remove(name);
		}

		private FilesAndDirsConf DirectoryConfiguration
		{
			get
			{
				FilesAndDirsConf conf = (FilesAndDirsConf)ConfigurationSettings.GetConfig(
					ConfConstants._CONF_SECTION_NAME);

				return conf;
			}
		}

		public override void InitResource(Hashtable parameters)
		{
			_map = new ContextEntryMap();
		}
	}
}
