using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services2;

using UVa.GCG.WSRF.Common.Attributes;
using UVa.GCG.WSRF.Common.WS;
using UVa.GCG.WSRF.Common.WS.Addressing;
using UVa.GCG.WSRF.Common.WS.BaseFaults;
using UVa.GCG.WSRF.Common.WS.Grid;
using UVa.GCG.WSRF.Service.BaseTypes;
using UVa.GCG.WSRF.Service.Grid;
using UVa.GCG.WSRF.Service.ResourceLifetime;
using UVa.GCG.WSRF.Service.ResourceProperties;

using GBG.OGSA.OGSACommon.Configuration;
using GBG.OGSA.OGSACommon.Factories;
using GBG.OGSA.OGSACommon.Naming;
using GBG.OGSA.OGSACommon.OGSA;

namespace GBGWS.OGSA.FilesAndDirs
{
	[WsdlBaseName("WSRFNetFactory", FactoryConstants._FACT_NAMESPACE)]
	[WebService]
	[WebServiceBinding]
	[WSRFPortType(typeof(ImmediateResourceTerminationPortType))]
	[WSRFPortType(typeof(GCGResourceFactoryPortType))]
	[WSRFPortType(typeof(GetResourcePropertyPortType))]
	[WSRFPortType(typeof(ReferenceResolver))]
	public class WSRFNetFactory : ServiceSkeleton
	{
		private ArrayList __serviceEPRs = new ArrayList();
	
		[Resource]
		private EndpointReferenceType[] ___serviceEPRs
		{
			get
			{
				EndpointReferenceType []ret = new EndpointReferenceType[__serviceEPRs.Count];
				__serviceEPRs.CopyTo(ret);
				return ret;
			}

			set
			{
				__serviceEPRs = new ArrayList(value);
			}
		}

		[ResourceProperty(FactoryConstants._FACT_SERVICE_EPRS_RP_NAME, FactoryConstants._FACT_NAMESPACE,
			 typeof(EndpointReferenceType), false, null, false, "0", "unbounded", 0)]
		private ArrayList _serviceEPRs
		{
			get
			{
				return __serviceEPRs;
			}
		}

		[ResourceProperty(OGSAConstants.WSResourceInterfacesName,
			 OGSAConstants.WSResourceInterfacesNS,
			 typeof(XmlQualifiedName), false, null, false, "1", "unbounded", 0)]
		private XmlQualifiedName[] WSResourceInterfaces
		{
			get
			{
				return new XmlQualifiedName[]
					{
						FactoryConstants._FACT_PORTTYPE_QNAME
					};
			}
		}

		[Resource]
		private int _nextServiceEPR = 0;

		public WSRFNetFactory()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		public override void InitResource(Hashtable parameters)
		{
			_nextServiceEPR = 0;
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		[SoapDocumentMethod(FactoryConstants._FACT_NAMESPACE + "/instantiate")]
		[return: XmlElement("instance", Namespace=FactoryConstants._FACT_NAMESPACE)]
		public EndpointReferenceType instantiate()
		{
			if (_serviceEPRs == null || _serviceEPRs.Count == 0)
				throw FaultGenerator.MakeFault(new FactoryException("No service EPRs defined.", 
					ServiceBase.EPR));
				
			if (_nextServiceEPR >= _serviceEPRs.Count)
				_nextServiceEPR = 0;

			EndpointReferenceType nextServiceEPR = (EndpointReferenceType)_serviceEPRs[_nextServiceEPR++];

			GCGResourceFactoryBinding proxy = new GCGResourceFactoryBinding(nextServiceEPR.Address.Value);
			WSUtilities.setEPR(proxy, nextServiceEPR);

			CreateResponse resp = proxy.Create(new Create());

			if (	(resp.ResourceEndpoint.ReferenceProperties == null)			|| 
					(resp.ResourceEndpoint.ReferenceProperties.Any == null)		||
					(resp.ResourceEndpoint.ReferenceProperties.Any.Length != 1))
				throw FaultGenerator.MakeFault(
					new FactoryException("Factory couldn't create this type of object.", ServiceBase.EPR));

			string an = string.Format("urn:uva-guid:{0}",
				resp.ResourceEndpoint.ReferenceProperties.Any[0].InnerText);
			XmlDocument doc = new XmlDocument();
			XmlElement element = doc.CreateElement(null, "AbstractName", NamingConstants.NAMING_NS);
			element.InnerText = an;
			XmlRootAttribute rootAttribute = new XmlRootAttribute("ReferenceResolver");
			rootAttribute.Namespace = NamingConstants.NAMING_NS;

			resp.ResourceEndpoint.Any = new XmlElement[]
				{
					element,
					WSUtilities.Serialize(ServiceBase.EPR, rootAttribute)
				};

			return resp.ResourceEndpoint;
		}

		[WebMethod]
		[SoapDocumentMethod(FactoryConstants._FACT_NAMESPACE + "/addServices")]
		public void addServices(
			[XmlArray("services", Namespace=FactoryConstants._FACT_NAMESPACE)]
			[XmlArrayItem("service-epr", Namespace=FactoryConstants._FACT_NAMESPACE)]
			EndpointReferenceType []services)
		{
			__serviceEPRs.AddRange(services);
		}
	}
}
